VIEW_MODES = {
    'infoWall': {
        'skin.estuary': '54',
        'skin.confluence': '515',
        'skin.aeon.nox.5': '51'
    },
    'list': {
        'skin.estuary': '502',
        'skin.confluence': '51',
        'skin.aeon.nox.5': '50'
    },
    'wideList': {
        'skin.estuary': '55',
        'skin.confluence': '500',
        'skin.aeon.nox.5': '510'
    }
}
