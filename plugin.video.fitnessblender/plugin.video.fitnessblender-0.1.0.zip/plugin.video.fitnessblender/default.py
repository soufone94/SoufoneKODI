from resources.lib.fitnessblender.fitnessblender import FitnessBlender

fitnessBlender = FitnessBlender()
fitnessBlender.run()
