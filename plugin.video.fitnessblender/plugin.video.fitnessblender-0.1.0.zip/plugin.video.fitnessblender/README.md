A simple web scraping add-on for Kodi to pull videos from the fitness blender website
