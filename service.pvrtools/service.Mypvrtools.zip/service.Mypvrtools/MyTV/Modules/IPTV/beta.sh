#!/bin/bash
OUTPUT=${1:-'full_libretv.m3u'}

echo "#EXTM3U" > $OUTPUT
#URL_LIST=$(curl -s http://kodi.libretv.me/Complete_List.m3u | grep m3u | tr '\r' ',' | tr -d '\n')
#curl -s {$URL_LIST} | grep --no-group-separator -e ^http -e ^rtmp -e ^mms -B1 >> $OUTPUT 2>/dev/null
curl -w '\n' -s http://atlasweb.net/zaz2/arabe.m3u | grep m3u | tr -d '\r'  | xargs -i curl -w '\n' -s {} | grep --no-group-separator -e ^http -e ^rtmp -e ^mms -e ^rtsp -e ^acestream -e ^plugin -B1 >> $OUTPUT 2>/dev/null
