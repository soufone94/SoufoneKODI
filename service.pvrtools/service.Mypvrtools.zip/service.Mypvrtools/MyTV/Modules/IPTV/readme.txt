
copy rtmpdump.exe to python, and add c:\Python27; to path 
pip install gi
pip install livestreamer