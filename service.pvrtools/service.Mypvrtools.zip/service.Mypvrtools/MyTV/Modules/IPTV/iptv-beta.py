# more info on the M3U file format available here:
# http://n4k3d.com/the-m3u-file-format/

import os,sys, getopt, urllib, urllib2, glob
import datetime

import xml.etree.ElementTree as ET

import lib.MyApi as MyApi
import lib.radioma as radioma



class IPTV():
    def __init__(self, title,tvg,tvIcon,radio,group,xbmc, path, cname2,state,SiteINI,site_id):
        self.title = title
        self.tvg = tvg
        self.tvIcon = tvIcon
        self.radio = radio
        self.group = group
        self.xbmc = xbmc
        self.path = path
        self.cname2 = []
        self.state = state        
        self.SiteINI = SiteINI
        self.site_id = site_id


def getKey(IPTV):
    #filter by group
    return IPTV.group

def getKeyTvg(IPTV):
    #filter by tvgname
    return IPTV.title

def Playlist_Formating(playlist):
    print 'start Playlist_Formating:' 
    #logger.info("start Playlist_Formating: ")
    
    return sorted(playlist, key=getKey)


               
# Parse Channels.xml to get icon, tvguid and group names
def ParseChannelsXmlNew(database,playlist, Connected = True):

    # initialize dataB variables before reading file
    print " >>>>>>>>>>>> start ParseChannelsXml ... <<<<", datetime.datetime.now().time()
    #logger.info(" >>>>>>>>> start ParseChannelsXml ... <<<<<<<<<<<<<<<<<")
    IPTVFound = 0
    FlagIPTV = 0 # verifier si header est creer

    channel_id = ""
    channel_display_name = ""
    channel_icon = "----SeriesTV----.png"
    group = ""
    radio = ""


    playlistTrie = ''
    Cleanplaylist = ''
    CleanplaylistKO = ''
    IPTV_DATA = []
    IPTV_DATAKO = []
    data = open(database,'r')   
    dataCh = ET.parse(data)
    rootData = dataCh.getroot()


    DupLessPath = []
    for IPTV in playlist:
        IPTVFound = 0

        if IPTV.title != None: #Title not empty
            if IPTV.path not in DupLessPath: # first occurence
                DupLessPath.append(IPTV.path)
                #print ">>>>> IPTV.title", IPTV.title
                
                state, radio = MyApi.CheckLink(IPTV.path, IPTV.title, Connected) # Check if link alive and if radio or TV 
                if not state: #link is dead 
                    ##logger.info( "IPTV.title KO %s", IPTV.title)
                    IPTV.xbmc = "[COLOR red] " + IPTV.title + " [/COLOR]"
                    IPTV.tvIcon = IPTV.title.replace(" ","_")+".png"
                    IPTV.group = "zze KO " #+ IPTV.group
                    IPTV.state = "KO"
                    if IPTV.radio == '':                          
                        IPTV.radio = "false"                          
                            
                    channel_header = '#EXTINF:-1 tvg-id="%s" tvg-name="%s" tvg-logo="%s" radio="%s"  group-title="%s",%s\n' \
                                % (IPTV.title, IPTV.tvg , IPTV.tvIcon, IPTV.radio, IPTV.group.upper(), IPTV.xbmc)
                    CleanplaylistKO += channel_header
                    CleanplaylistKO += IPTV.path + '\n'+'\n'

                    IPTV_DATAKO.append(IPTV)

                else: # link alive
                    #print (IPTV.title, IPTV.tvg, IPTV.tvIcon, IPTV.radio, IPTV.group, IPTV.path)
                    for channel in rootData.findall('channel'):  
                        IPTV.state = "OK"                      
                        
                        # IPTV is valid and not yet founded
                        # parse database                
                        for cname in channel.findall('cname'):                    
                            LinkState = False 
                            
                            #print "radio state", cname.attribute('enabled')

                            if (MyApi.purge(str(IPTV.title)).lower() == MyApi.purge(str(cname.text)).lower()): 
                                IPTVFound = 1
                                IPTV.title = str(cname.text)
                                assignedcategory = channel.find('assignedcategory')
                                IPTV.group = assignedcategory.find('category').text.upper()                                
                                #print "IPTV found", channel_header
                                break

                        # si not found avec cname, search for second cname2 of channel
                        if IPTVFound != 1:
                            i = 0
                            for cname2 in channel.findall('cname2'): 
                                # create string to compar: sans " ","-","_"
                                if (MyApi.purge(str(IPTV.title)).lower() == MyApi.purge(str(cname2.text)).lower()): 
                                    IPTVFound = 1
                                    IPTV.title = str(cname.text)
                                    assignedcategory = channel.find('assignedcategory')
                                    IPTV.group = assignedcategory.find('category').text.upper()
                                    #IPTV.cname2 = cname2.text
                                    IPTV.cname2.append(cname2.text)
                                    print "IPTV.cname2[0]", IPTV.cname2
                                    break

                    # IPTV not founded in database => create playlist using IPTV info             
                    if IPTVFound == 0:
                        IPTVFound = 1
                        IPTV.title = IPTV.title.strip()
                        if IPTV.group  == '':
                            IPTV.group = "ze unknown"


                    # after all check and data creation
                    IPTV.tvg = IPTV.title
                    IPTV.xbmc = IPTV.title
                    IPTV.tvIcon = str(IPTV.title).replace(" ","_")+".png"
                    if IPTV.radio == '':
                        if radio == 'RADIO':
                            IPTV.radio = "true"
                        else:
                            IPTV.radio = "false"

                    channel_header = '#EXTINF:-1 tvg-id="%s" tvg-name="%s" tvg-logo="%s" radio="%s"  group-title="%s",%s\n' \
                                    % (IPTV.title, IPTV.tvg , IPTV.tvIcon, IPTV.radio, IPTV.group.upper(), IPTV.xbmc)
                    Cleanplaylist += channel_header
                    Cleanplaylist += IPTV.path + '\n'+'\n'
                    print "IPTV.cname2[1]", IPTV.cname2
                    IPTV_DATA.append(IPTV)

##    #return Cleanplaylist
    return IPTV_DATA, IPTV_DATAKO


# Read M3U list from file
def getList(liste):
    print ">> start getList:" , liste
    #logger.info("start getList:")

    playlist =[]

    if os.path.isfile(liste):
        print "it is a local file"
        inf = open(liste,'r')
    else:
        try:
            print "try"
            path, filename = os.path.split(liste)
            print "file name ",filename
            if not os.path.exists("stream/"):
                os.makedirs("stream/")
            urllib.urlretrieve(liste , "stream/"+filename)
            inf = open("stream/"+filename,'r')
        except IOError as e:
            print "ERROR1: getList: get file I/O error({0}): {1}".format(e.errno, e.strerror)
            #logger.info("ERROR: getList: get file : I/O error({0}): {1}".format(e.errno, e.strerror))
            raise
            return playlist
            

    try:
        for line in inf:
            line=line.strip()
            if not line.startswith('#') and line:
                print " not started with # ", line
                playlist += GetM3U_data(line)
    except IOError as e:
        print "ERROR2: getList: I/O error({0}): {1}".format(e.errno, e.strerror)
        #logger.info("ERROR: getList: I/O error({0}): {1}".format(e.errno, e.strerror))
        raise
    except:
        print "ERROR3: getList: unexpected error: liste=", liste 
        print "ERROR3: getList: unexpected error: line=", line
        #logger.info("ERROR: getList: unexpected error: liste = %s",liste)
        #logger.info("ERROR: getList: unexpected error: line = %s",line)
        raise

    inf.close()    

    return playlist

def GetM3U_data(M3UPlaylist):
    import re
    print ("start GetM3U_data: rplaylist: ",M3UPlaylist)
    #logger.info("start GetM3U_data:  playlist: %s ", M3UPlaylist)

    # initialize playlist variables before reading file
    playlist=[]

    if os.path.isfile(M3UPlaylist):
        inf = open(M3UPlaylist,'r')
    else:
        try:
            path, filename = os.path.split(M3UPlaylist)
            try:
                print "file name ",filename
                filename = filename.replace(" ","").replace("?","").replace("!","") + ".m3u"
                urllib.urlretrieve(M3UPlaylist , "stream/"+filename)
                inf = open("stream/"+filename,'r')
            except:            
                urllib.urlretrieve(M3UPlaylist , "M3UPlaylist.m3u.tmp")
                inf = open("M3UPlaylist.m3u.tmp",'r')
            
        except IOError as e:
            print "ERROR: M3UPlaylist: get file I/O error({0}): {1}".format(e.errno, e.strerror)
            #logger.info("ERROR: M3UPlaylist: get file : I/O error({0}): {1}".format(e.errno, e.strerror))
            return playlist 
 


    #title,tvg,tvIcon,radio,group,xbmc, path, cname2tab,state,SiteINI,site_id
    song=IPTV(None,None,None,None,None,None,None,None,None,None,None)

    for line in inf:
        line=line.strip()
        ##EXTINF:-1 tvg-id="2M" tvg-name="2M" tvg-logo="2M.png" group-title="Maroc"2M
        if line.startswith('#EXTINF:'):
          
            line = line.strip()
            try:                
                title = re.search(r'(?<=tvg-id=").*?(?=")', line).group(0)              
            except:               
                rest,title = line.rsplit(',',1)
        
            title = title.replace(',','').replace('-1','').replace('0','').replace(':-',' ').replace(':','')
            title = title.strip().upper()

            try: 
                tvg = re.search(r'(?<=tvg-name=").*?(?=")', line).group(0).strip()
            except:
                tvg =''
            try: 
                tvIcon = re.search(r'(?<=tvg-logo=").*?(?=")', line).group(0)
            except:
                tvIcon =''
            
            try: 
                radio = re.search(r'(?<=radio=").*?(?=")', line).group(0)
            except:
                radio =''
            
            try: 
                group = re.search(r'(?<=group-title=").*?(?=")', line).group(0)
            except:
                group =''

            song=IPTV(title,tvg,tvIcon,radio,group,None,None,None,None,None,None)

                
        elif MyApi.FormatLink(line):
            # pull song path from all other, non-blank lines
            song.path=line
            playlist.append(song)

            # reset the song variable so it doesn't use the same EXTINF more than once
            song=IPTV(None,None,None,None,None,None,None,None,None,None,None)

    inf.close()
##    for IPTVT in playlist:
##        print (IPTVT.title, IPTVT.tvg, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path)

    #####Clean up directory
    filelist = glob.glob("*.tmp")
    for f in filelist:
        os.remove(f)
        
    return playlist


def MiseEnForme(Playlist,Output):
    print ">>>>> start MiseEnForme", Output
    import operator 

    PlaylistForma = sorted(Playlist, key=getKeyTvg)
    PlaylistForma = sorted(PlaylistForma, key=getKey)
    
    Cleanplaylist = ''
    global_header = '#EXTM3U\n'
    Cleanplaylist += global_header

    DupLess = []
    DupLessPath = []
    for IPTVT in PlaylistForma:
        #print (IPTVT.title, IPTVT.tvg, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path)

        if IPTVT.path not in DupLessPath:
            DupLessPath.append(IPTVT.path)

            channel_header = '#EXTINF:-1 tvg-id="%s" tvg-name="%s" tvg-logo="%s" radio="%s"  group-title="%s",%s\n' \
                            % (IPTVT.title, IPTVT.tvg , IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.xbmc)
            Cleanplaylist += channel_header
            Cleanplaylist += IPTVT.path + '\n'+'\n'
##        else:
##            #print "already  in list IPTVT.path", IPTVT.path
            
    with open(Output, 'w+') as f:
        f.write(Cleanplaylist)
        f.close()
        
    return

def GetWebGrabber(PlaylistWithData,WebGrabber):

    IPTV_DATA = []

    data = open(WebGrabber,'r')   
    dataCh = ET.parse(data)
    rootData = dataCh.getroot()

    for IPTVT in PlaylistWithData:
        print "IPTVT.title ",IPTVT.title 
        IPTVT.SiteINI = None
        IPTVT.site_id = None
        for channel in rootData.findall('channel'):        
            if IPTVT.title == channel.text or IPTVT.cname2 == channel.text:
                #print "found ", channel.text, channel.attrib.get("site")
                IPTVT.SiteINI = channel.attrib.get("site")
                IPTVT.site_id = channel.attrib.get("site_id")


        song=IPTV(IPTVT.title,IPTVT.tvg,IPTVT.tvIcon,IPTVT.radio,IPTVT.group,IPTVT.xbmc, IPTVT.path,IPTVT.cname2,IPTVT.state,IPTVT.SiteINI,IPTVT.site_id)
        IPTV_DATA.append(song)
        #IPTV_DATA.append(song)


    channels = ET.Element('channels')
    print "IPTV_DATA"
    for IPTVT in IPTV_DATA:
    #     print (IPTVT.title, IPTVT.tvg, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path, IPTVT.cname2, IPTVT.state, IPTVT.SiteINI, IPTVT.site_id)        
            channel = ET.SubElement(channels, 'channel')
            title = ET.SubElement(channel, 'title')
            title.text = IPTVT.title
            cname2 = ET.SubElement(channel, 'cname2')
            cname2.text = IPTVT.cname2
            path = ET.SubElement(channel, 'path')
            path.text = IPTVT.path
    outFile = open('DB.xml', 'w')
    channels.write(outFile)
    
    return IPTV_DATA

# for now, just pull the IPTV info and print it onscreen
# get the M3U file path from the first command line argument
def main():
    
    print (" *****start M3U Playlist creating at: "), datetime.datetime.now().time()
    #logger.info(" ***** Hallo, start creating PlayPlist.m3u *****")
    workspace = "c:/Users/soufian/Dropbox/Public/XBMC/LIVE_TV"
    Connected = True
    #workspace=sys.argv[1]
    PlaylistWithData = ''
    PlaylistWithDataKO = ''
    playlist=[]

    output = workspace + '/output'
    LogoDir = output + '/logos/'
    Ressources = workspace + '/Ressources'

    ChannelDataBase = output + '/shahid/ChannelDB.xml'
    StreamList = Ressources + '/list.py'

    MyPlaylist = output + '/playlist-test.m3u'
    MyPlaylistKO = output + '/playlist-test-KO.m3u'

    #radioma    
    radioMA_xml_Remote = "http://radioma.ma/radiomaxbmc/radios.xml"
    radioMA_xml_local = output + '/radioma/radioma.xml'
    radioMaM3U = output + '/radioma/radioma.m3u'

    WebGrabber = "C:\Users\soufian\Dropbox\Public\XBMC\LIVE_TV\Ressources\WebGrab\WebGrab++.config-TOP.xml"
         

##### Setup workspace
    #MyApi.SetupWorkSpace()


   
##    if Connected == True:
##        ## get radio station from radio MA plugin
##        # def radioMA_Playlist(radioMA_xml_Remote,radiosXml, LogoDir, ouputfile, TestConnection)
##        radioma.radioMA_Playlist(radioMA_xml_Remote,radioMA_xml_local, LogoDir, radioMaM3U, Connected)

        

##### generate playlist from Web or local links       
    # get playlist fined in list.txt
    StreamList = 'https://dl.dropboxusercontent.com/u/80638885/XBMC/LIVE_TV/Ressources/list-test.py'
    playlist += getList(StreamList)

    # print "playlist:"
    # for IPTVT in playlist:        
    #     print (IPTVT.title, IPTVT.tvg, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path, IPTVT.cname2)

    # create m3u with logo, epg, groupe info
    PlaylistWithData, PlaylistWithDataKO  = ParseChannelsXmlNew(ChannelDataBase,playlist,Connected)


    # Mise en forme dans le fichier de sortie: trie ...
    MiseEnForme(PlaylistWithData,MyPlaylist)
    MiseEnForme(PlaylistWithDataKO,MyPlaylistKO)

    IPTV_DATA = GetWebGrabber(PlaylistWithData,WebGrabber)

    print "PlaylistWithData"
    for IPTVT in PlaylistWithData:
       print (IPTVT.title, IPTVT.cname2, IPTVT.tvg, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path,  IPTVT.state, IPTVT.SiteINI, IPTVT.site_id)

    
#####Clean up directory
    filelist = glob.glob("*.tmp")
    for f in filelist:
        os.remove(f)
        
    print "end M3U Playlist creating at: ", datetime.datetime.now().time()


if __name__ == '__main__':
    main()
