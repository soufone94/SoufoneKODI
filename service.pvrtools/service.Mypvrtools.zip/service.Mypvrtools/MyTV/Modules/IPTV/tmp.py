import re

title = re.sub(r"(\[^?^.\])", "", "[COLOR WHITE][I]MYZEN.TV 3D[/I][/COLOR]")
print "title",title

# import re
# x = 'Your number is <b>blab labla</b>'
# print re.search('(?<=Your number is )<b>(\s+)</b>',x)