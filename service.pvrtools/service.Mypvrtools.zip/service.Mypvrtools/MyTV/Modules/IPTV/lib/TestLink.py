# -*- coding: cp1252 -*-
# -*- coding: utf-8 -*-

import urllib2, logging, os

import sys
import xml.etree.ElementTree as ET
import os, re, shutil
import urllib, urllib2

import getpass
import datetime
import glob

workspace = os.getcwd()




global_header = '#EXTM3U\n'

# Global Variables
TestConnection = True



curentdir = os.getcwd()
ResourcesDir = workspace+'Ressources'
radioMaM3U = curentdir + "/output/radioma.m3u"
radioMA_xml_Remote = "http://radioma.ma/radiomaxbmc/radios.xml"
radioMA_xml_local = ResourcesDir+'/radios.xml'

ChannelDataBase = ResourcesDir+'/Channels.xml'

LogoDir = 'c:/Users/'+getpass.getuser()+'/Dropbox/Public/XBMC/LIVE_TV/logos/'

Shahid_channelsLink = "https://raw.githubusercontent.com/Shani-08/ShaniXBMCWork/master/plugin.video.shahidmbcnet/resources/community/Channels.xml"

MyPlaylist = curentdir + "/output/output-final.m3u"



def SetupWorkSpace():
    import shutil
    
    logfile = os.getcwd()+'\log.log'
    logfileback = os.getcwd()+'\log.log'+'.back'
    StreamDir = os.getcwd()+'\stream'
    StreamDirOld = os.getcwd()+'\stream_old'

    try:
        shutil.move(logfile, logfileback)
    except:
        print "log file doesn't exist, no need to backup", logfile
        print("ERROR: SetupWorkSpace: log file doesn't exist, no need to backup %s",logfile)
        raise
    
    source = os.listdir(StreamDir)
    
    for files in source:
        dst_file = StreamDirOld + '/'+files
        if os.path.exists(dst_file):
            os.remove(dst_file)
        try:
            shutil.move(StreamDir + '/' +files,dst_file)
        except:
            print "can't copy ", files
            print("ERROR: SetupWorkSpace: can't copy stream file ", files)
            raise

    return 

def purge(name):
    # remove all space, -, _ before comapr channel name
    purgedname = name.replace("-","").strip()
    purgedname = purgedname.upper()
    purgedname = purgedname.replace("_","")
    purgedname = purgedname.replace(" ","")
    purgedname = purgedname.replace("+","plus")
    purgedname = purgedname.replace("(","")
    purgedname = purgedname.replace(")","")
    purgedname = purgedname.replace("HD","")
    purgedname = purgedname.replace("SD","")
    purgedname = purgedname.replace("/","")
    return purgedname

def CheckLink(url, Title, TestConnection):
    #print "CheckLink: enter", url
    #return Status, RADIO or TV
    

    import socket
    from urllib2 import Request, urlopen, URLError
    
    if TestConnection == False:
        #print " force TestConnection sate to True"
        return True, "Connection OFF"

    if '$' in url: # or '?' in url:
        print("ERROR: CheckLink:  %s : / not supported Format %s",Title,url)
        return False, "not supported Format"

    if  url.startswith('http:'):
        import urllib2, urllib
        
        if "pvr" in url:
            return True, "TV"

        else:
       
            try:
                try:
                    res = urllib2.urlopen(url)
                    http_message = res.info()
                    full = http_message.type # 'text/plain'
                    main = http_message.maintype # 'text'
                    print "full result", full
                except URLError as e:

                    if hasattr(e, 'reason'):
                        print 'souf We failed to reach a server.'
                        print 'souf Reason: ', e.reason, 'souf Reasonend  '
                    if hasattr(e, 'code'):
                        print 'souf The server couldn\'t fulfill the request.'
                        print 'souf Error code: ', e.code

                    if e.reason == "Forbidden":
                        print "Forbidden"
                        full ="video"
                    if ":@" in url:
                        full ="video"
                    else:
                        full ="failed"





                if ("audio" in full):
                    return True, "RADIO"

                elif ("video" in full) or ("plain" in full) or ("mpeg" in full) or ("mpegurl" in full) or ("octet-stream" in full):  
                    return True, "TV"
                
                else:  
                    raise              
                    print("CheckLink: >>> %s : / URL: %s",Title, url)
                    print("CheckLink: >>> %s : / full: %s",Title, full)
                    print "CheckLink: >>> %s : / URL:",Title, url
                    print "CheckLink: >>> %s : / full:",Title, full
                    
                    return False, "Type Faild"
            except:
                raise
                print("ERROR CheckLink ligne 131: >>> %s : / except: URL: %s",Title, url)
                print "ERROR CheckLink: >>> except: URL:", url
                return False, "Type execption"
                raise

    elif url.startswith('rtmp:/'):        
        from livestreamer import Livestreamer, StreamError, PluginError, NoPluginError
        quality = 'best'

                # Create the Livestreamer session
        livestreamer = Livestreamer()

        # Enable logging
        livestreamer.set_loglevel("info")
        livestreamer.set_logoutput(sys.stdout)
        
                # Attempt to fetch streams
        try:
            streams = livestreamer.streams(url)
        except NoPluginError:
            raise
            print(" ERROR: CheckLink:  %s : / uLivestreamer is unable to handle the URL %s ",Title, url)
            print("Livestreamer is unable to handle the URL '{0}'".format(url))
            return False, "rtmp False 1"
        except PluginError as err:
            raise
            print(" ERROR: CheckLink:  %s : / Unknown issue URL %s ", Title,url)
            print("Unknown issue URL '{0}'".format(url))
            return False, "rtmp False 2"
        except:
            raise
            print(" ERROR: CheckLink:  %s : / Unknow issue URL %s ",Title, url)
            print ("Unknow issue".format(url))
            return False, "rtmp False 3"

        if not streams:
            print(" ERROR: CheckLink: %s : /  No streams found on  URL %s ",Title, url)
            print("No streams found on URL '{0}'".format(url))
            return False, "rtmp False 4"

        # Look for specified stream
        if quality not in streams:
            print(" ERROR: CheckLink: %s : /  Unable to find  stream on  URL %s ",Title, url)
            print("Unable to find '{0}' stream on URL '{1}'".format(quality, url))
            return False, "rtmp False 4"

        try:
            # We found the stream
            stream = streams[quality]
            fd = stream.open()
            data = fd.read(1024)
            fd.close()
            
            if data == '':
                return False, "rtmp False 5"
            else:
                return True, "rtmp true 6"
        except:
            raise
            print(" ERROR: CheckLink: %s : /  Unknow issue (2) URL %s ",Title, url)
            print ("Unknow issue (2) ".format(url))
            return False, "rtmp False 7"
            
        


    elif url.startswith('mms') or url.startswith('rtsp'):
        return False, "mms False"
    else:
        #print " unsupported protocol ", url
        print(" ERROR: CheckLink: %s : /  unsupported protocol %s ", Title,url)
        return False, "mms False"

    
def IsFavorite(group):
    if (group == "french") or (group == "maroc") or (group == "drama") or (group == "ent"):
               return True
    else:
               return True

# Retrun true if link is supported
def FormatLink(url):
    if url.startswith('rtmp') or url.startswith('http:') or url.startswith('mms') or url.startswith('rtsp:'):
        return True
    else:
        return False

# for now, just pull the IPTV info and print it onscreen
# get the M3U file path from the first command line argument
def main():
    
    print (" *****start M3U Playlist creating at: "), datetime.datetime.now().time()
    #print(" ***** Hallo, start creating PlayPlist.m3u *****")
    url = "http://4BA9EBDB07C05883:@5.159.96.170:8000/brazzers"
    Title = "D8"
    TestConnection = True
    print CheckLink(url, Title, TestConnection)
    
#####Clean up directory
    filelist = glob.glob("*.tmp")
    for f in filelist:
        os.remove(f)
        
    print "end M3U Playlist creating at: ", datetime.datetime.now().time()


if __name__ == '__main__':
    main()