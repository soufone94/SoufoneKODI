# -*- coding: cp1252 -*-
# -*- coding: utf-8 -*- 
import xml.etree.ElementTree as ET
import glob
import os
import datetime
import argparse
import urllib2
import getpass
import shutil
import urllib
import time

SETTINGS = {}

import logging
logger = logging.getLogger('myapp')
hdlr = logging.FileHandler(os.path.dirname(os.path.abspath(__file__))+'/Shahid.log')
formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
hdlr.setFormatter(formatter)
logger.addHandler(hdlr) 
logger.setLevel(logging.DEBUG)

Shahid_channelsLink = "https://raw.githubusercontent.com/Shani-08/ShaniXBMCWork/master/plugin.video.shahidmbcnet/resources/community/Channels.xml"
ChannelDB = "https://dl.dropboxusercontent.com/u/80638885/XBMC/LIVE_TV/Ressources/channels.xml"

def CreateIfNotExiste(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)
        
def cSort(inlist, minisort=True):
    sortlist = []
    newlist = []
    sortdict = {}
    for entry in inlist:
        try:
            lentry = entry.lower()
        except AttributeError:
            sortlist.append(lentry)
        else:
            try:
                sortdict[lentry].append(entry)
            except KeyError:
                sortdict[lentry] = [entry]
                sortlist.append(lentry)

    sortlist.sort()
    for entry in sortlist:
        try:
            thislist = sortdict[entry]
            if minisort: thislist.sort()
            newlist = newlist + thislist
        except KeyError:
            newlist.append(entry)
    return newlist

def Get_Shahid_files(OutputDir):
    import urllib2,re,os
    #import requests

    print " shahid.py: start Get_Shahid_files to::", OutputDir
    if not os.path.isdir(OutputDir): # Directory that I want to save the image to
        os.makedirs(OutputDir) # If no directory create it

    try:
        urllib.urlretrieve(Shahid_channelsLink , OutputDir + "channels-downloaded.xml")
        urllib.urlretrieve(ChannelDB , OutputDir + "ChannelDB.xml")
    except:
        print "error: Get_Ressource_files can't get: ", Shahid_channelsLink
        logger.info("error: Get_Ressource_files can't get: %s", Shahid_channelsLink)

def Icone_Extractor(WorkSpace,LogoDir,DataBase):

    print " generate-shahid.py:  start Icone_Extractor ... <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
    logger.info(" >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> start Icone_Extractor ... <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<")
    
    Src = open(DataBase,"r" )
    urlFlag = 'No'
    logoFlag = 'No'
    LinkFound = True
    

    tree = ET.parse(Src)
    root = tree.getroot()

    for streaminginfo in root.findall('channel'):
            cname = streaminginfo.find('cname').text
            imageurl = streaminginfo.find('imageurl').text

            if cname:
                logoname = cname.replace(" ","_")
                logoname = logoname + ".png"
                logonameFTV = cname + ".png"
                
            if not os.path.exists(LogoDir + logoname) or not os.path.exists(LogoDir + logonameFTV):
                try:
                    f = urllib2.urlopen(urllib2.Request(imageurl))
                    urllib.urlretrieve(imageurl, LogoDir + logoname)
                    shutil.copyfile(LogoDir + logoname, LogoDir + logonameFTV)
                    #print logoname
                except:
                    #print ">>>>  url ko", logoname, " site: ", imageurl
                    logger.info( ">>>>  url ko")
                    logger.info(logoname)
                    logger.info(imageurl)
                    logger.info( "\n")
                    #log.write(imageurl)
    Src.close()
                   
def INI_Extractor(WorkSpace,FTV_Out,DataBase):


    # Recup Channel Name
    #*a* *b* *c*=plugin://plugin.video.shahidmbcnet/?url=*a*+*b*+*c*&mode=16&name=*a*+*b*+*c*
    # Canal+ Sport= plugin://plugin.video.shahidmbcnet/?url=Canal%2B+Sport&amp;mode=16&amp;name=Canal%2B+Sport

    print " >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> start INI_Extractor ... <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
    logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> start INI_Extractor ... <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<")

    channel = DataBase
    print "channel", channel
    Src = open(channel,"r" )

    AddonIni = "..gen_" + time.strftime("%Y%m%d-%H%M%S") +  '=plugin://plugin.video.shahidmbcnet/?url=Dummy \n'
    webGraber = ''
    #AddonIni_header = '[plugin.video.shahidmbcnet]\n'
    #AddonIni += AddonIni_header

    tree = ET.parse(Src)
    root = tree.getroot()

    for streaminginfo in root.findall('channel'):
            cname = streaminginfo.find('cname').text

            if cname:
          
                cname_name = cname.replace(" ","_")

                cname_link = cname.strip() # remove space begin and end
                cname_link = cname_link.replace("+","%2B" )
                cname_link = cname_link.replace(" ","+" )

                link = 'plugin://plugin.video.shahidmbcnet/?url=' + cname_link + '&mode=16&name=' + cname_link
                ligne = cname + '=' + link

                AddonIni += ligne + '\n'

                LignwebGraber = '<channel update="i" site="dummy" site_id="' + cname +'" xmltv_id="'+ cname +'">' + cname + '</channel>' + '\n'
                #print webGraber
                webGraber += LignwebGraber
                

    output_name = "addons.tmp"
    webGraber_dummy = "webGraber_dummy.tmp"
    
    with open(output_name, 'w') as f:
        f.write(AddonIni)
        f.close()
        
    with open(webGraber_dummy, 'w') as f:
        f.write(webGraber)
        f.close()

      # Tri par ordre alphab addons.ini
    G_Liste = []
    G_HandlerFichier = open("addons.tmp","r" )
    outfile = open("addons.ini.tmp", "w")
     
    for line in G_HandlerFichier:
        G_Liste.append(line) # ajout de la ligne lue a la liste
     
    G_Liste_tmp = []
    G_Liste_tmp = cSort(G_Liste, minisort=True)
    for line in G_Liste_tmp:
        outfile.write(line)
     
    G_HandlerFichier.close()
    outfile.close()      
    Src.close()

    # Tri par ordre alphab webGraber_dummy
    G_Liste = []
    G_HandlerFichier = open("webGraber_dummy.tmp","r" )
    outfile = open("webGraber_dummy2.tmp", "w")
     
    for line in G_HandlerFichier:
        G_Liste.append(line) # ajout de la ligne lue a la liste
     
    G_Liste.sort(lambda a, b: cmp(a[0::], b[0::])) # le crit�re de tri est l'ordre alphab�tique croissant � partir du n-i�me caract�re)
    for line in G_Liste:
        outfile.write(line)
     
    G_HandlerFichier.close()
    outfile.close()      
    Src.close()

    #add generated addons.ini to ref one
    import fileinput
    Ressources_shahid = WorkSpace + '\Ressources\shahid/'
    Ressources_WebGrab = WorkSpace + '\Modules\WebGrab\Ressources'
    output_ini = WorkSpace + '/output/addons.ini'
    
    filenames = [Ressources_shahid + 'addons-Header.ini','addons.ini.tmp', Ressources_shahid + 'addons-ref.ini']
    
    with open(output_ini, 'w') as fout:
        for line in fileinput.input(filenames):
            fout.write(line)

    ini = WorkSpace + "/output/FTV/history/addon-"+  time.strftime("%Y%m%d-%H%M%S") + ".ini"
    CreateIfNotExiste(ini)
    shutil.copy(output_ini,ini)

    #add generated webGraber_dummy2 to ref one
    import fileinput
    filenames = [Ressources_WebGrab +'/WebGrab++.config-Header.xml','webGraber_dummy2.tmp', Ressources_WebGrab +'/WebGrab++.config-End.xml']
    output_Config = WorkSpace + '/output/WebGrab++.config-shahid.xml'
    with open(output_Config, 'w') as fout:
        for line in fileinput.input(filenames):
            fout.write(line)

def main(WorkSpace):

    print "start Shahid Extracor.... at ", datetime.datetime.now().time()
    logger.info("start Shahid Extracor....")
    parser = argparse.ArgumentParser()
    #parser.add_argument('-w', '--WorkSpace', help="set workspace", default= os.getcwd()) 
    parser.add_argument('-i', '--ini', help="Generate addons.ini", default='no')
    parser.add_argument('-c', '--icone', help="extract icon", default='yes')  

    args = parser.parse_args()

    
    SETTINGS['ini'] = args.ini
    SETTINGS['icone'] = args.icone

    # create output directory
    outdir = WorkSpace + '/output/shahid/'
    logosDir = WorkSpace + '/output/logos/'
    inifile = WorkSpace + '/output/addons.ini'
    

		
    if not os.path.exists(outdir):
        os.makedirs(outdir)
    else:
        print "Directory already exists:", outdir

    if not os.path.exists(logosDir):
        os.makedirs(logosDir)
    else:
        print "Directory already exists:", logosDir

    Get_Shahid_files(outdir)

    if SETTINGS['icone'] == "yes":
        Icone_Extractor(WorkSpace,logosDir,outdir +'ChannelDB.xml')
    if SETTINGS['ini'] == "yes":
        INI_Extractor(WorkSpace,inifile, outdir +'ChannelDB.xml')

    #Clean up directory
    filelist = glob.glob("*.tmp")
    for f in filelist:
        os.remove(f)

        
    logger.info("End Shahid Extracor....")

if __name__ == '__main__':
    main()
