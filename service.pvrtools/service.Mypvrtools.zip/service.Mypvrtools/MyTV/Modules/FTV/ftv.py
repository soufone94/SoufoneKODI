
import time, shutil
import os,sys, getopt, urllib, urllib2, glob
import datetime

import xml.etree.ElementTree as ET

def FTV_prepare(workspace):
    print "FTV_prepare: enter"
    FTV_Guides = workspace + '/Ressources/FTV/guides.ini'

    shutil.copyfile(FTV_Guides, workspace + '/output/guides.ini')
    
def pluginLink(cname):

    # Recup Channel Name
    #*a* *b* *c*=plugin://plugin.video.shahidmbcnet/?url=*a*+*b*+*c*&mode=16&name=*a*+*b*+*c*
    # Canal+ Sport= plugin://plugin.video.shahidmbcnet/?url=Canal%2B+Sport&amp;mode=16&amp;name=Canal%2B+Sport
    
    cname_link = cname.strip() # remove space begin and end
    cname_link = cname_link.replace("+","%2B" )
    cname_link = cname_link.replace(" ","+" )

    link = 'plugin://plugin.video.shahidmbcnet/?url=' + cname_link + '&mode=16&name=' + cname_link

    return link


def cSort(inlist, minisort=True):
    sortlist = []
    newlist = []
    sortdict = {}
    for entry in inlist:
        try:
            lentry = entry.lower()
        except AttributeError:
            sortlist.append(lentry)
        else:
            try:
                sortdict[lentry].append(entry)
            except KeyError:
                sortdict[lentry] = [entry]
                sortlist.append(lentry)

    sortlist.sort()
    for entry in sortlist:
        try:
            thislist = sortdict[entry]
            if minisort: thislist.sort()
            newlist = newlist + thislist
        except KeyError:
            newlist.append(entry)
    return newlist
                   
                   
def INI_Extractor(ShahidDB,output_file):
    CurrentPath = os.path.dirname(os.path.abspath(__file__))
        
   
    # Recup Channel Name
    #*a* *b* *c*=plugin://plugin.video.shahidmbcnet/?url=*a*+*b*+*c*&mode=16&name=*a*+*b*+*c*
    # Canal+ Sport= plugin://plugin.video.shahidmbcnet/?url=Canal%2B+Sport&amp;mode=16&amp;name=Canal%2B+Sport

    print " >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> start INI_Extractor ... <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"

    Src = open(ShahidDB,'r')

    AddonIni = "..gen_" + time.strftime("%Y%m%d-%H%M%S") +  '=plugin://plugin.video.shahidmbcnet/?url=Dummy \n'
    webGraber = ''
    #AddonIni_header = '[plugin.video.shahidmbcnet]\n'
    #AddonIni += AddonIni_header
    try:
        tree = ET.parse(Src)
    except:
        print "addonIni failed"
        return 
        

    root = tree.getroot()

    for streaminginfo in root.findall('channel'):
            cname = streaminginfo.find('cname').text

            if cname:          
                cname_name = cname.replace(" ","_")
                link = pluginLink(cname)
                ligne = cname + '=' + link

                AddonIni += ligne + '\n'

    output_name = "addons.tmp"
    
    with open(output_name, 'w') as f:
        f.write(AddonIni)
        f.close()


      # Tri par ordre alphab addons.ini
    ini_tmp = 'addons.ini.tmp'
    G_Liste = []
    G_HandlerFichier = open("addons.tmp","r" )
    outfile = open(ini_tmp, "w")
     
    for line in G_HandlerFichier:
        G_Liste.append(line) # ajout de la ligne lue a la liste
     
    G_Liste_tmp = []
    G_Liste_tmp = cSort(G_Liste, minisort=True)
    for line in G_Liste_tmp:
        outfile.write(line)
     
    G_HandlerFichier.close()
    outfile.close()      
    Src.close()

    #add generated addons.ini to ref one
    import fileinput
    filenames = [CurrentPath + '/Ressources/addons-Header.ini',ini_tmp, CurrentPath + '/Ressources/addons-ref.ini']
     
    with open(output_file, 'w') as fout:
        for line in fileinput.input( filenames):
            fout.write(line)

    ini = "output/FTV/addon-"+  time.strftime("%Y%m%d-%H%M%S") + ".ini"
    shutil.copy(output_file,ini)


