#-*- coding: utf-8 -*-
import urllib2
import re, os, json
import xbmc, xbmcgui, xbmcplugin 

from bs4 import BeautifulSoup

from resources.lib import globalvar    
# from resources.lib import MyTmdb 

title=['series']
img=['series']
readyForUse=True

JsonSeries="https://www.dropbox.com/s/pix242ia31oahq8/series.json?dl=1"


if not os.path.exists(globalvar.CACHE_DIR):
    os.makedirs(globalvar.CACHE_DIR, mode=0777)
OutStreamDir=globalvar.CACHE_DIR
playlistlocal = os.path.join(globalvar.CACHE_DIR, "playlist-tmp.m3u")
Jsonlocal=os.path.join(globalvar.CACHE_DIR, "result.json")





def list_shows(channel,folder,pageNumber=""):
    print "souf1: list_shows: ",channel,folder,pageNumber
    shows=[]
    playlist=[]
    
            

    urlShow=JsonSeries  
    title="Arabic"
    import urllib
    print "urlShow, Jsonlocal",urlShow, Jsonlocal+".tmp"
    urllib.urlretrieve (urlShow, Jsonlocal)  


    with open(Jsonlocal) as data_file:   
        data = json.load(data_file)

    for i in data: 
        for j in i["series"]:
            Seriename=j["PlaylistName"].encode("utf-8")
            LinkSerie=j["PlaylistCode"]
            print "///LinkSerie", LinkSerie
            SerieImage=j["PlaylistIcon"].encode("utf-8")
           
            shows.append( [
                channel,
                LinkSerie, 
                Seriename , 
                SerieImage,
                'shows'] )

            # shows.append([
            #     channel,
            #     folder,
            #     title,
            #     '',
            #     'shows'])

    return shows

def list_videos(channel,folder):
    print "souf1: list_videos",channel,folder
    videos=[] 
    playlist=[]


    name=''
    image_url=''
    date=''
    duration=''
    views=''
    desc=''
    rating=''
    url=''
    countries=''



    import json
    from pprint import pprint

    with open(Jsonlocal) as data_file:   
        data = json.load(data_file)

    for i in data: 
        for j in i["series"]:            
            if folder==j["PlaylistCode"]:
                print "*****", j["AllVideos"]
                for episode in j["AllVideos"]:
                    name=episode["SerieName"].encode('utf-8')
                    VideoLink=episode['serieCode']
                    image_url=episode['SerieIcon']

                    infoLabels={ "trailers":"trailers","Title": name,"countries":"countries", "Plot": "desc","Aired":"date","Duration": "duration", "Year":"date"}   

                    videos.append( [channel, VideoLink, name, image_url,infoLabels,'play'] )

    return videos

def getVideoURL ( channel,url ): # imort from PlayShowLink ( url )
    print "souf1:PlayShowLink ",url 
    url='plugin://plugin.video.youtube/?action=play_video&videoid=%s' % url
    return url

