# -*- coding: utf-8 -*-
class IPTV():
    def __init__(self, title,tvg,tvIcon,radio,group,xbmc, path,calias,state,SiteEPG,site_id):
        self.title = title
        self.tvg = tvg
        self.tvIcon = tvIcon
        self.radio = radio
        self.group = group
        self.xbmc = xbmc
        self.path = path
        self.calias = calias
        self.state = state        
        self.SiteEPG = SiteEPG
        self.site_id = site_id



def install(package):
    print "PIP install:",package
    import pip
    pip.main(['install', package])

# https://pypi.python.org/pypi/tmdb3/

# try:
#     import tmdb3
# except:
#     install("tmdb3")
#     import tmdb3
# import themoviedb
import tmdb
import tmdb3



def nameformat(VODname):
    try:
        print "VODname", VODname.decode('utf-8')
        langue="EN"
    except:
        print " ==> can't print VODname"
        s=""
        for c in VODname:
            s=s+hex(ord(c)).replace("0x","%")
        VODname=s
        print VODname
    VODname=str(VODname).replace(" ","%20") #.encode('utf-8')

    return VODname



KEY = 'd2e44b2a5548806311f950bd87e15e7f'
VODname="Inception"
VODname="الرسالة"

# VODname=nameformat(VODname)

from tmdb3 import set_key
set_key(KEY)

from tmdb3 import set_cache
set_cache('null')
# set_cache(filename='/full/path/to/cache') # the 'file' engine is assumed
# set_cache(filename='tmdb3.cache') # relative paths are put in /tmp
# set_cache(engine='file', filename='~/.tmdb3cache')

def GetInfo(VODname):

    from tmdb3 import searchMovie
    infoLabels={ "Title": "","Plot":"desc","Aired":"date","Duration": "duration", "Year":"date"}   


    res = searchMovie(VODname)
    VODid=res[0].id

    # print "VODname", VODname
    # print "overview", res[0].overview 
    # print "releasedate  ", res[0].releasedate   
    # print "poster   ", res[0].poster.geturl()   
    # print "genres   ", res[0].genres    
    # print "studios   ", res[0].studios   
    # print "languages    ", res[0].languages     
    # print "countries    ", res[0].countries     

    # from tmdb3 import Movie
    # movie = Movie(VODid)
    # try: 
    #     print "youtube_trailers", movie.youtube_trailers[0].geturl()
    # except:
    #     print "youtube_trailers: can't get traillers"


    infoLabels={ "Title": VODname,"Plot":"desc","Aired":"date","Duration": "duration", "Year":res[0].releasedate }   

    return infoLabels, res[0].poster.geturl()  

# from tmdb3 import searchMovieWithYear
# # list(searchMovieWithYear('Star Wars (1977)'))
# print (searchMovieWithYear(VODname))

# from tmdb3 import Movie
# p = Movie(VODid).poster

# print "Title", Movie(VODid).originaltitle
# print "Pster", p.geturl()



# print movie.apple_trailers[0].geturl()

print "end"