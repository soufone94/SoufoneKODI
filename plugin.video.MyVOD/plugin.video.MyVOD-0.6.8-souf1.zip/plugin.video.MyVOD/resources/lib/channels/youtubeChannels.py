#-*- coding: utf-8 -*-
import urllib2, urllib
import re	 
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import json


readyForUse=True

# Channels: (Title, code user)
channles={'series':('مسلسلات',''),
		'ontveg':('ONtveg','ONtveg'),
		 'cbcegyptdrama':('CBC Drama',"CBCEgyptDrama"),
		 'AlNaharDramaEG':("AlNahar Drama",'AlNaharDramaEG'),
		 'seriesmarocaines':('مسلسلات مغربية','UCG1c-F2wGhMW_h8-VF3nGhQ')		
	}


title=[]
img=[]
usernames=[]

#https://console.cloud.google.com/apis/library/youtube.googleapis.com/?project=myvod-1506522700530
googleUrl="https://www.googleapis.com/youtube/v3/"
apikey='AIzaSyCl5mHLlE0mwsyG4uvNHu5k1Ej1LQ_3RO4'
apikey="AIzaSyAenB-f8Fq3C7qjhfwb0rZw1Qff5AQ2X6U"

__addon__       = xbmcaddon.Addon(id='plugin.video.MyVOD')
__addondir__    = xbmc.translatePath( __addon__.getAddonInfo('path') )
channelLogoDir = __addondir__ + "/resources/media/"

# >>>>>>>>>> list_shows 
def getChannelIdByUserName(username):
	try:
		u_url='https://www.googleapis.com/youtube/v3/channels?part=id&forUsername=%s&key=%s'%(username,apikey)
		print 'u_url', u_url

		channelData=getJson(u_url)
		print "souf1 getChannelIdByUserName:",u_url, channelData
		try:
		  return channelData['items'][0]['id']
		except:
			return username
	except: 
		raise
		return "IDNOTFOUND"

def getYouTubePlayList(channelId):
	if not channelId.startswith('https://www.googleapis'):
		u_url='https://www.googleapis.com/youtube/v3/playlists?part=snippet&channelId=%s&maxResults=25&key=%s'%(channelId,apikey)
	else:
		u_url=channelId
	doc=getJson(u_url)
	ret=[]
	for playlist_item in doc['items']:
		
		title = playlist_item["snippet"]["title"]
		id = playlist_item["id"]
		if not title=='Private video':
			imgurl=''
			try:
				imgurl= playlist_item["snippet"]["thumbnails"]["high"]["url"]
			except: pass
			if imgurl=='':
				try:
					imgurl= playlist_item["snippet"]["thumbnails"]["default"]["url"]
				except: pass
			ret.append([title,id,imgurl])
	nextItem=None
	if 'nextPageToken' in doc:
		nextItem=doc["nextPageToken"]
	else:
		nextItem=None
		
	nextUrl=None
	if nextItem:
		if not '&pageToken' in u_url:
			nextUrl=u_url+'&pageToken='+nextItem
		else:
			nextUrl=u_url.split('&pageToken=')[0]+'&pageToken='+nextItem
		
	return ret,nextUrl,imgurl;

def getChannelLogo(channelId):
	if not channelId.startswith('https://www.googleapis'):
		u_url='https://www.googleapis.com/youtube/v3/channels?part=snippet&id=%s&key=%s'%(channelId,apikey)
	else:
		u_url=channelId
	doc=getJson(u_url)
	print "****WWW u_url", u_url,doc
	for playlist_item in doc['items']:
		imgurl= playlist_item["snippet"]["thumbnails"]["high"]["url"]
	print "****WWW logo", imgurl
	
	return imgurl;

def IsSerie(channel,title):
	
	if ("serie".upper() in title.upper()) or ("مسلسل" in title):
		return True
	
	return False


# >>>>>>>>>> list_videos
def Mylist_videos():
	return

def getYoutubeVideosByPlaylist(playlistId,channel):
	print "soufdebug playlistId", playlistId
	emptyVideos=[]
	if playlistId:
		if playlistId.startswith('https://www'):
			#nextpage
			u_url=playlistId
		else:
			u_url='https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=5&playlistId=%s&key=%s'%(playlistId,apikey)
		videos=getJson(u_url)
		
		return prepareYoutubeVideoItems(videos,u_url,channel)
	else:
		return emptyVideos, None 

def prepareYoutubeVideoItems(videos,urlUsed,channel):
	print "souf1: prepareYoutubeVideoItems",videos,urlUsed
	global content_type,overridemode
	content_type='episodes'
	overridemode=50
	#print 'urlUsed',urlUsed
	if 'nextPageToken' in videos:
		nextItem=videos["nextPageToken"]
	else:
		nextItem=None
	videoids=[]
	for playlist_item in videos["items"]:
		if not 'search?part=snippet' in urlUsed:
			video_id = playlist_item["snippet"]["resourceId"]["videoId"]
		else:
			video_id =playlist_item["id"]["videoId"]   
		videoids+=[video_id]
	vinfo=getVideoDetails(','.join(videoids))
	yt_items = vinfo.get('items', [])
	_video_data={}
	for yt_item in yt_items:
		video_id = unicode(yt_item['id'])
		_video_data[video_id] = yt_item
		
	#print _video_data
	ret=[]
	for playlist_item in videos["items"]:
		title = playlist_item["snippet"]["title"].encode("utf-8")


		#print 'urlUsed',urlUsed
		if not 'search?part=snippet' in urlUsed:
			video_id = playlist_item["snippet"]["resourceId"]["videoId"]
		else:
			video_id =playlist_item["id"]["videoId"]
		duration=None
		try:
			_dur= _video_data[video_id]['contentDetails']['duration']
			duration= int(parseYoutubDateTime(_dur).seconds - 1)
		except: pass
		date=None
		try:

			date= parseYoutubDateTime(playlist_item["snippet"]['publishedAt'])
			print date
		except: pass
		description=None
		try:
			description=strip_html_from_text( playlist_item["snippet"]['description'])
		except: pass
		#print description.encode("utf-8")
		if not title=='Private video':
			imgurl=''
			try:
				imgurl= playlist_item["snippet"]["thumbnails"]["high"]["url"]
			except: pass
			if imgurl=='':
				try:
					imgurl= playlist_item["snippet"]["thumbnails"]["default"]["url"]
				except: pass
		#print "%s (%s)" % (title, video_id)
			#ret.append([title,video_id,imgurl,duration,description,date])
			ret.append( [channel, video_id, title, imgurl,description,'play'] )
	nextUrl=None
	if nextItem:
		if not '&pageToken' in urlUsed:
			nextUrl=urlUsed+'&pageToken='+nextItem
		else:
			nextUrl=urlUsed.split('&pageToken=')[0]+'&pageToken='+nextItem
	return ret,nextUrl;

def getVideoDetails(video_id):
	if isinstance(video_id, list):
		video_id = ','.join(video_id)
		pass

	params = {'part': 'snippet,contentDetails',
			  'id': video_id,
			  'key':apikey}
	u_url='https://www.googleapis.com/youtube/v3/videos?%s'%(urllib.urlencode(params))
	videos=getJson(u_url)
	return videos

# >>>>>>>>>>> getVideoURL
# nothing


# >>>>>>>>>>>  global 
def getJson(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.154 Safari/537.36')
	response = urllib2.urlopen(req)
	#link=response.read()
	#response.close()
	decoded = json.load(response)
	return decoded


# >>>>>>>>>>>>>>>>>>>>>>>>> main function <<<<<<<<<<<<<<<<<<<<<
for c in channles:
	title.append(channles[c][0])
	img.append(c)
	usernames.append(channles[c][1])
	# get channel logo
	username=channles[c][1]
	if username:
		channelId=getChannelIdByUserName(username)
		imgurl=getChannelLogo(channelId)
		print "*** image", c, imgurl
	
		logo = urllib.URLopener()
		imagefile=channelLogoDir+c+".png"
		logo.retrieve(imgurl, imagefile)
	

def list_shows(channel,folder):
	print "souf1: list_shows: ",channel,folder
	shows=[]
	
	username=channles[channel][1]
	# username=usernames[channel]
	print "username",username
	
			 
	if "series"==channel:	
		print "i*************************************** s series" 
		for c in channles:	
			username=channles[c][1]
			# username=usernames[channel]
			print "c, username",c, username
			if username:
				channelId=getChannelIdByUserName(username)
				playlists,nextUrl,imgurl=getYouTubePlayList(channelId)

				for playList in playlists:	
					print playList[0].encode('utf-8') 
					if IsSerie(c,playList[0].encode('utf-8') ):
						if "مقاطع" in playList[0].encode('utf-8') or  "Scenes" in playList[0].encode('utf-8'):
							print "soufdebug: extrait ****", playList[1].encode('utf-8')
						else:
							shows.append( [channel,playList[1].encode('utf-8'), playList[0].encode('utf-8') , playList[2].encode('utf-8'),'shows'] )
	else:    
		channelId=getChannelIdByUserName(username)
		playlists,nextUrl,imgurl=getYouTubePlayList(channelId)
		print "souf1 playlists",playlists
		for playList in playlists:	
			if "مقاطع" in playList[0].encode('utf-8') or  "Scenes" in playList[0].encode('utf-8'):
				print "soufdebug: extrait ****", playList[1].encode('utf-8')
			else:
				shows.append( [channel,playList[1].encode('utf-8'), playList[0].encode('utf-8') , playList[2].encode('utf-8'),'shows'] )
	
	return shows


def list_videos(channel,show_URL):
	print "souf1: list_videos",channel,show_URL
	videos=[] 
	AllVideos=[]
	
	videos,next_page=getYoutubeVideosByPlaylist(show_URL,channel)
	for v in videos:
		AllVideos.append(v)
	
	NotComplete=True
	while NotComplete:
		if next_page:
			videos2,next_page=getYoutubeVideosByPlaylist(next_page,channel)
			for v in videos2:
				AllVideos.append(v)
		else:
			NotComplete=False
	
	
	print "soufdebug AllVideos ",AllVideos

	return AllVideos

def getVideoURL(channel,video_URL):	
	youtubecode=video_URL
	uurl = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % youtubecode
	print "souf1: getVideoURL: uurl ",uurl
	#xbmc.executebuiltin("xbmc.PlayMedia("+uurl+")")
	return uurl

