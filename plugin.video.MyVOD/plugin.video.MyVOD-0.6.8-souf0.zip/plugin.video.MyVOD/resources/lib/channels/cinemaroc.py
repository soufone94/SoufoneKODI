#-*- coding: utf-8 -*-
import urllib2
import re     
import xbmc, xbmcgui, xbmcplugin 

from bs4 import BeautifulSoup

title=['cinemaroc']
img=['cinemaroc']
readyForUse=True

urlFilm="http://www.cinetrafic.fr/liste-film/7920/"

def film(url):
    print "souf1: film", (url)

    req = urllib2.Request(url)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()
    soup = BeautifulSoup(html, 'html.parser')

    divs=soup.find_all('div')

    for div in divs:
        # print "str(div.get('class'))",str(div.get('class'))
        if div.get('id'):
            if str(div.get('id'))=="pochette_film":
                print ">div"
                try:
                    SerieImage="http://www.cinetrafic.fr"+div.find("img").get("src").encode('utf-8')                    
                except:                    
                    pass

                try:
                    Seriename=div.find("img").get("alt").encode('utf-8')                    
                except:                    
                    pass

            if str(div.get('id'))=="description_content":
                try:
                    description=str(div.contents).replace("[u'\n', <strong class=","").replace('no_s"> -"','')                    
                except:
                    # raise                  
                    pass

    print ">Seriename ", Seriename 
    print ">SerieImage",  SerieImage
    print ">description",  description

    return description, Seriename , SerieImage

def list_film_ori(channel,url):
    print "souf1: list_film",(url)
    shows=[]

    for i in range(1):           
        urlShow=url+str(i)+"/les-meilleurs-films-marocains"
       
        print "urlShow_",urlShow
        req = urllib2.Request(urlShow)
        req.add_header('User-agent', 'Mozilla 5.10')
        html=urllib2.urlopen(req).read()

        
        soup = BeautifulSoup(html, 'html.parser')
        foo = open('c:\Users\soufian\AppData\Roaming\Kodi/addons\plugin.video.MyVOD/resources\lib\channels\soup.htm', 'w')
        foo.write(soup.get_text().encode('utf-8'))
        foo.close()
        # print"soup.get_text()",(soup.get_text().encode('utf-8'))

        divs=soup.find_all('div')

        foo = open('c:\Users\soufian\AppData\Roaming\Kodi/addons\plugin.video.MyVOD/resources\lib\channels\divs.htm', 'w')
        foo.write(str(divs))
        foo.close()

        for div in divs:
            # print "str(div.get('class'))",str(div.get('class'))
            if div.get('id'):
                try:
                    if div.get('id'):
                        # print "str(div.get('id'))", str(div.get('id'))
                        if str(div.get('id'))=="liste_film":
                            divjs=div.find_all('div')   
                            for j in divjs: 
                                if j.get('id'):          
                                    if str(j.get('id')).startswith("liste_film_"):
                                        liste_film_s=j.find_all('div')
                                        for l in liste_film_s:
                                            name=str(l.get('class')).replace("[u'","").replace("']","").replace("',","").replace("u'","").strip()
                                            if "droid135bold" in name:
                                                try:
                                                    LinkSerie="http://www.cinetrafic.fr/"+str(l.find('a').get("href"))
                                                    # titre=l.find('strong').contents[0].encode('utf-8')   

                                                    plot, titre , image = film(LinkSerie)

                                                    titre=titre.replace('Affiche du film','')

                                                    infoLabels = {
                                                    "Title": titre,
                                                    "Plot": plot,
                                                    # "Aired": date.split(' ')[0],
                                                    # "Duration": duration,
                                                    "Year": "date[6:10]"}

                                                    # shows.append([
                                                    #     channel,
                                                    #     LinkSerie,
                                                    #     titre,
                                                    #     image,
                                                    #     # infoLabels,
                                                    #     'play'])
                                                    
                                                    LinkSerie=titre
                                                    shows.append([
                                                        channel,
                                                        LinkSerie,
                                                        titre,
                                                        image,
                                                        # infoLabels,
                                                        'play'])
                                                                                              
                                                                  
                                                    # shows.append( [year,channel,LinkSerie, Seriename , SerieImage,'play'] )
                                                except:
                                                    # print "except name",div
                                                    raise
                                                    pass

                except:
                    raise
                    pass  


    return shows

def list_film(channel,url):
    print "souf1: list_film",(url)
    shows=[]

    for i in range(8):           
        urlShow=url+str(i)+"/les-meilleurs-films-marocains"
       
        print "urlShow_",urlShow
        req = urllib2.Request(urlShow)
        req.add_header('User-agent', 'Mozilla 5.10')
        html=urllib2.urlopen(req).read()

        
        soup = BeautifulSoup(html, 'html.parser')
        # foo = open('c:\Users\soufian\AppData\Roaming\Kodi/addons\plugin.video.MyVOD/resources\lib\channels\soup.htm', 'w')
        # foo.write(soup.get_text().encode('utf-8'))
        # foo.close()
        # # print"soup.get_text()",(soup.get_text().encode('utf-8'))

        divs=soup.find_all('div')


        for div in divs:
            # print "str(div.get('class'))",str(div.get('class'))

	        if str(div.get('id')).startswith("liste_film_top"):
	            liste_film_s=div.find_all('div')
	            for l in liste_film_s:
	            	print ">l", l
	                name=str(l.get('class')).replace("[u'","").replace("']","").replace("',","").replace("u'","").strip()
	                if "droid135bold" in name:
	                    try:
	                        LinkSerie="http://www.cinetrafic.fr/"+str(l.find('a').get("href"))
	                        # titre=l.find('strong').contents[0].encode('utf-8')   

	                        plot, titre , image = film(LinkSerie)

	                        titre=titre.replace('Affiche du film','')
	                        print ">titre", titre

	                        infoLabels = {
	                        "Title": titre,
	                        "Plot": plot,
	                        # "Aired": date.split(' ')[0],
	                        # "Duration": duration,
	                        "Year": "date[6:10]"}
	                        
	                        LinkSerie=titre
	                        shows.append([
	                            channel,
	                            LinkSerie,
	                            titre,
	                            image,
	                            # infoLabels,
	                            'play'])
	                                                                  
	                    except:
	                        # print "except name",div
	                        raise
	                        pass


    return shows


def list_episode(channel,url):
    print "souf1: list_episode    ",(url)
    shows=[]

    page=""
    for i in range(10):
        if i>0:
            page="/page/"+str(i)
            
        urlShow=url+page
       
        print "urlShow_",urlShow
        req = urllib2.Request(urlShow)
        req.add_header('User-agent', 'Mozilla 5.10')
        html=urllib2.urlopen(req).read()

        
        soup = BeautifulSoup(html, 'html.parser')
        # print"soup.get_text()",(soup.get_text().encode('utf-8'))

        divs=soup.find_all('div')


        for div in divs:
            try:
                for i in div.get('class'):
                    if i=="moviefilm":
                        print "moviefilm", div
                        
                        SerieImage=str(div.find("img").get("src").encode('utf-8'))   
                        LinkSerie=str(div.find('a').get("href"))  
                        divjs=div.find_all('div')        
                        for j in divjs:               
                            for p in j.get('class'):
                                movief=p
                                if movief=="movief":
                                    print ">>> moviefJ",j
                                    try:
                                        for n in j.find('a').contents:
                                            Seriename=str(n.encode('utf-8'))
                                            l=LinkSerie

                                            l=re.sub("[^0-9]", "", l)

                                            year=l[-4:]
                                            print "LinkSerie,year,Seriename", LinkSerie,year,Seriename                                                               
                                                      
                                            # shows.append( [channel,LinkSerie, Seriename , SerieImage,'shows'] )
                                            shows.append( [channel,Seriename, Seriename , SerieImage,'shows'] )
                                    except:
                                        print "except name",div
                                        raise
                                        pass

            except:
                # raise
                pass  

    # shows.sort(key=lambda tup: tup[2],reverse=True) 
    print "AllShows",  shows 

    return shows

######################################
def list_shows(channel,folder,pageNumber=""):
    print "souf1: list_shows: ",channel,folder,pageNumber
    shows=[]
    
            
    if folder=='none':
            # shows.append( [channel,'Series', 'Series','http://iip.lu/wp-content/uploads/sites/156/2016/04/15700070751_88d83d38fd_o.png','folder'] )
            shows.append( [channel,'Film', 'Film','http://i.huffpost.com/gen/1516995/images/o-CINEMA-ARABE-facebook.jpg','folder'] )
            # shows.append( [channel,'Show', 'Show','http://www.musicnation.me/musicnation-uploads//2014/02/Music-Nation-Bassem-Youssef-El-Bernameg-4.jpg','folder'] )
    else:
        print "souf1 folder,name", folder,pageNumber

        if folder=='Series':
                url=urlSerie
                shows=list_episode(channel,url)
        if folder=='Film':
                url=urlFilm
                shows=list_film(channel,url)
        if folder=='Show':
                url=urlProgram
                shows=list_episode(channel,url)

        
    return shows

def list_videos(channel,show_URL):
    print "souf1: list_videos",channel,show_URL
    videos=[] 

    req = urllib2.Request(show_URL)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()
    
    name=''
    image_url=''
    date=''
    duration=''
    views=''
    desc=''
    rating=''
    url=''

    req = urllib2.Request(show_URL)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()

    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, 'html.parser')

    links=soup.find_all("div", {"class": "moviefilm"})
    try:
        for link in links:
            episodename="Play"
            
            VideoLink=link.find('a').get("href").encode('utf-8')
            image_url=link.find('img').get("src").encode('utf-8')
            divjs=link.find_all('div')        
            for j in divjs:               
                for p in j.get('class'):
                    if p=="movief":
                        print ">>> moviefJ",j
                        try:
                            for n in j.find('a').contents:
                                episodename=str(n.encode('utf-8')) 
                        except:
                            pass

            print "souf1 VideoLink",VideoLink,image_url
            print "shahid4u videos",channel, VideoLink, episodename, image_url

            infoLabels={ "Title": episodename,"Plot":desc,"Aired":date,"Duration": duration, "Year":date}   
            videos.append( [channel, VideoLink, episodename, image_url,infoLabels,'play'] )
    except:
        raise
        print "souf1 exception" 

    # titles=soup.find_all("div", {"class": "titleMovie"})

    # try:
    #     print "souf1 titles",titles
    #     for title in titles:

    #         episodename=title.find("h2", {"class": "titleMovie"}).contents.encode('utf-8')
    # except:
    #     raise


    
    


 

    return videos

def getVideoURL ( channel,url ): # imort from PlayShowLink ( url )
    print "souf1:PlayShowLink ",url 

    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.youtube/kodion/search/query/?q='+url+'&quot;,return)')

   

    return url



