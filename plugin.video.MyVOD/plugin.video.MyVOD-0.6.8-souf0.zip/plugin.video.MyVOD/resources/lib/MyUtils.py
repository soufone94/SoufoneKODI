# -*- coding: utf-8 -*-
#!/usr/bin/python

from apiclient.discovery import build
from apiclient.errors import HttpError
# from oauth2client.tools import argparser


# Set DEVELOPER_KEY to the API key value from the APIs & auth > Registered apps
# tab of
#   https://cloud.google.com/console
# Please ensure that you have enabled the YouTube Data API for your project.

#https://console.cloud.google.com/apis/library/youtube.googleapis.com/?project=myvod-1506522700530
# DEVELOPER_KEY = "AIzaSyAkPSpNvUwTILkOXe6V9QxsqkVHWCoThls" # soufian
DEVELOPER_KEY = "AIzaSyAenB-f8Fq3C7qjhfwb0rZw1Qff5AQ2X6U" #soufmedia
YOUTUBE_API_SERVICE_NAME = "youtube"
YOUTUBE_API_VERSION = "v3"

def youtube_search(options):
  youtube = build(YOUTUBE_API_SERVICE_NAME, YOUTUBE_API_VERSION,
    developerKey=DEVELOPER_KEY)

  # Call the search.list method to retrieve results matching the specified
  # query term.
  search_response = youtube.search().list(
    q=options.q,
    part="id,snippet",
    maxResults=options.max_results
  ).execute()

  videos = []
  channels = []
  playlists = []

  # Add each result to the appropriate list, and then display the lists of
  # matching videos, channels, and playlists.
  for search_result in search_response.get("items", []):
    if search_result["id"]["kind"] == "youtube#video":
      videos.append("%s (%s)" % (search_result["snippet"]["title"],
                                 search_result["id"]["videoId"]))

    elif search_result["id"]["kind"] == "youtube#channel":
      channels.append("%s (%s)" % (search_result["snippet"]["title"],
                                   search_result["id"]["channelId"]))
    elif search_result["id"]["kind"] == "youtube#playlist":
      playlists.append("%s (%s)" % (search_result["snippet"]["title"],
                                    search_result["id"]["playlistId"]))

  print "Videos:\n", "\n".join(videos).encode('utf-8'), "\n"
  print "Channels:\n", "\n".join(channels), "\n"
  print "Playlists:\n", "\n".join(playlists), "\n"

def youtube_GetVideoID(vod,max_results):
  # print "youtube_GetVideoID ",vod
  videos=[]

  try:
    youtube = build(YOUTUBE_API_SERVICE_NAME, YOUTUBE_API_VERSION,
      developerKey=DEVELOPER_KEY)

    # Call the search.list method to retrieve results matching the specified
    # query term.
    search_response = youtube.search().list(
      q=vod,
      part="id,snippet",
      maxResults=max_results
    ).execute()

    videos = []
    channels = []
    playlists = []

    # Add each result to the appropriate list, and then display the lists of
    # matching videos, channels, and playlists.
    for search_result in search_response.get("items", []):
      if search_result["id"]["kind"] == "youtube#video":

        videos.append((search_result["id"]["videoId"],search_result["snippet"]["title"]))

  except:
    print " >> ERROR: youtube_GetVideoID"
    raise
    pass


  return videos

def GetVideoDuration(videoId):
  # print "GetVideoDuration ", videoId

  url="https://www.googleapis.com/youtube/v3/videos?part=contentDetails&id="+videoId+"&key="+DEVELOPER_KEY
  import urllib, json
  response = urllib.urlopen(url)
  data = json.loads(response.read())


  duration=data['items'][0]['contentDetails']['duration']
  definition=data['items'][0]['contentDetails']['definition']
  # print "duration", duration
  
  if "H" in duration:
    regexQuery='PT([0-9]*)H([0-9]*)M([0-9]*)S'  
    H, M, S=re.findall(regexQuery, duration)[0]
  elif "M" in duration:
      regexQuery='PT([0-9]*)M([0-9]*)S'  
      M, S=re.findall(regexQuery, duration)[0]
      H=0
  else:
      regexQuery='PT([0-9]*)S'  
      S=re.findall(regexQuery, duration)[0]
      H=0
      M=0


  duration=int(H)*60*60+int(M)*60+int(S)
  

  return duration, definition


def youtube_searchFilm(vod,max_results):
  youtube = build(YOUTUBE_API_SERVICE_NAME, YOUTUBE_API_VERSION,
    developerKey=DEVELOPER_KEY)

  # Call the search.list method to retrieve results matching the specified
  # query term.
  search_response = youtube.search().list(
    q=vod,
    part="id,snippet",
    maxResults=max_results,
    videoDuration="short" 
  ).execute()

  videos = []
  channels = []
  playlists = []

  print search_response
  return 

  # Add each result to the appropriate list, and then display the lists of
  # matching videos, channels, and playlists.
  for search_result in search_response.get("items", []):
    if search_result["id"]["kind"] == "youtube#video":
      videos.append("%s (%s)" % (search_result["snippet"]["title"],
                                 search_result["id"]["videoId"]))

    elif search_result["id"]["kind"] == "youtube#channel":
      channels.append("%s (%s)" % (search_result["snippet"]["title"],
                                   search_result["id"]["channelId"]))
    elif search_result["id"]["kind"] == "youtube#playlist":
      playlists.append("%s (%s)" % (search_result["snippet"]["title"],
                                    search_result["id"]["playlistId"]))

  print "Videos:\n", "\n".join(videos).encode('utf-8'), "\n"
  print "Channels:\n", "\n".join(channels), "\n"
  print "Playlists:\n", "\n".join(playlists), "\n"

def youtube_GetVideoIDByFiltre(vod,max_results=5,durationMax=4*60*60,durationMin=30, definition="HD"):

    # url="https://www.googleapis.com/youtube/v3/videos?part=contentDetails&id="+videoId+"&key="+DEVELOPER_KEY
    # import urllib, json
    # response = urllib.urlopen(url)
    # data = json.loads(response.read())

    videoId=""
    try:
      youtube = build(YOUTUBE_API_SERVICE_NAME, YOUTUBE_API_VERSION,
        developerKey=DEVELOPER_KEY)

      # Call the search.list method to retrieve results matching the specified
      # query term.
      search_response = youtube.search().list(
        q=vod,
        part="id,snippet",
        maxResults=max_results
      ).execute()

 

      # Add each result to the appropriate list, and then display the lists of
      # matching videos, channels, and playlists.
      for search_result in search_response.get("items", []):
        if search_result["id"]["kind"] == "youtube#video":
          videoId=search_result["id"]["videoId"]
          videoTitle=search_result["snippet"]["title"]
          dur, defi= GetVideoDuration(videoId)
          if defi.upper()==definition and dur<durationMax and dur>durationMin:
            print (videoTitle,videoId,"duration= "+str(dur)+ " definition= "+defi)
            return videoId

    except:
      print " >> ERROR: youtube_GetVideoID"
      raise
      pass

    return "NotFound"
  
def youtube_GetVideoSIDByFiltre(channel,vod,max_results=5,durationMax=4*60*60,durationMin=30, definition="HD"):
    videoId=""
    videos=[]
 
    youtube = build(YOUTUBE_API_SERVICE_NAME, YOUTUBE_API_VERSION,
    developerKey=DEVELOPER_KEY)

    # Call the search.list method to retrieve results matching the specified
    # query term.
    search_response = youtube.search().list(
    q=vod,
    part="id,snippet",
    maxResults=max_results
    ).execute()



    # Add each result to the appropriate list, and then display the lists of
    # matching videos, channels, and playlists.
    for search_result in search_response.get("items", []):
        if search_result["id"]["kind"] == "youtube#video":
          videoId=search_result["id"]["videoId"]
          videoTitle=search_result["snippet"]["title"]
          dur, defi= GetVideoDuration(videoId)
          if defi.upper()==definition and dur<durationMax and dur>durationMin:
            print (videoTitle,videoId,"duration= "+str(dur)+ " definition= "+defi)
            VideoLink="https://youtu.be/"+videoId    


            infoLabels={ "Title": videoTitle,"Aired":"date","Duration": str(dur), "Year":"date"}   

            videos.append( [channel, VideoLink, videoTitle, "image_url",infoLabels,'play'] )

    return videos

if __name__ == "__main__":

  vod="film SECURITY_2017_FR"
  # vod="أخضر يابس"
  max_results=50

  # argparser.add_argument("--q", help="Search term", default=vod)
  # argparser.add_argument("--max-results", help="Max results", default=1)
  # args = argparser.parse_args()

  try:
    # youtube_search(args)
    # videos=youtube_GetVideoID(vod,max_results)
    # print "youtube_GetVideoID(vod,max_results)", videos[0]
    durationMax=4*60
    durationMin=30
    definition="HD"
    print youtube_GetVideoIDByFiltre(vod,max_results,durationMax,durationMin, definition)

    # print youtube_searchFilm(vod,max_results)
    # print "https://youtu.be/"+youtube_GetVideoID(vod,max_results)[0]
  except HttpError, e:
    print "An HTTP error %d occurred:\n%s" % (e.resp.status, e.content)
# https://youtu.be/X5I4IcxTNkU