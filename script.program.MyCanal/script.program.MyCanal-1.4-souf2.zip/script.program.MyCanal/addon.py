import xbmc
import xbmcgui
import os

appname="MyCanal"
packagename1="com.canal.android.canal"


def launcher():
	packagepath1 = os.popen('pm path %s' % packagename1).read()
	if packagepath1:
		xbmc.executebuiltin('XBMC.StartAndroidActivity("%s")' % packagename1)
	else:
		xbmcgui.Dialog().ok('App Not Installed', 'This is only a shortcut.  Please install the "%s" app (%s or %s) and try again.' % (appname, packagename1, packagename2))

launcher()
