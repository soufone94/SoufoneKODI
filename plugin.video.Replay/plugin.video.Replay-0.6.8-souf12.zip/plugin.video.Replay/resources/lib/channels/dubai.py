#-*- coding: utf-8 -*-
import urllib2
import re     
import xbmc, xbmcgui, xbmcplugin 

from bs4 import BeautifulSoup

title=['dubai']
img=['dubai']
readyForUse=True
urlSerie="http://awaan.ae/relatedshows/30348/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA"
urlProgram="http://awaan.ae/show/allprograms"



def list_shows(channel,folder,pageNumber=""):
    print "souf1: list_shows: ",channel,folder,pageNumber
    shows=[]
    
            
    if folder=='none':
            shows.append( [channel,'Series', 'Series','http://iip.lu/wp-content/uploads/sites/156/2016/04/15700070751_88d83d38fd_o.png','folder'] )
            shows.append( [channel,'Show', 'Show','http://www.musicnation.me/musicnation-uploads//2014/02/Music-Nation-Bassem-Youssef-El-Bernameg-4.jpg','folder'] )
    else:
        print "souf1 folder,name", folder,pageNumber

        if folder=='Series':
                urlShow=urlSerie
        if folder=='Show':
                urlShow=urlProgram

        req = urllib2.Request(urlShow)
        req.add_header('User-agent', 'Mozilla 5.10')
        html=urllib2.urlopen(req).read()

        
        soup = BeautifulSoup(html, 'html.parser')
        # print(soup.get_text().encode('utf-8'))

        divs=soup.find_all('div')
        for div in divs:
            try:
                for i in div.get('class'):
                    if i=="drama-box":
                        try:
                            LinkSerie=str(div.find('a').get("href"))
                            SerieImage=str(div.find("img").get("data-src"))
                            for n in div.find('div').find('a').contents:
                                Seriename=str(n.encode('utf-8'))                 
                          
                            shows.append( [channel,LinkSerie, Seriename , SerieImage,'shows'] )
                        except:
                            print "except name",div
                            pass

            except:
                pass    
    return shows

def list_videos(channel,show_URL):
    print "souf1: list_videos",channel,show_URL
    videos=[] 

    req = urllib2.Request(show_URL)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()
    
    name=''
    image_url=''
    date=''
    duration=''
    views=''
    desc=''
    rating=''
    url=''

    req = urllib2.Request(show_URL)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()

    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, 'html.parser')

    episodes=soup.find_all("div", {"class": "episode-img"})
    try:
        for episode in episodes:
            print "souf1 episode",episode
            VideoLink=episode.find('a').get("href").encode('utf-8')
            image_url=episode.find("img", {"class": "load-onscroll img-responsive"}).get("data-src")
            episodename=episode.find("a", {"class": "episode-hover"}).get("title").encode('utf-8')


            infoLabels={ "Title": episodename,"Plot":desc,"Aired":date,"Duration": duration, "Year":date}   
            videos.append( [channel, VideoLink, episodename, image_url,infoLabels,'play'] )

    except:
        print "souf1 exception" 
        # raise       

    return videos

def getVideoURL ( channel,url ): # imort from PlayShowLink ( url )
    print "souf1:PlayShowLink ",url 
    VideoLink=url

    req = urllib2.Request(url)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()
    soup = BeautifulSoup(html, 'html.parser')

    # episode=soup.find("ifram", {"class": "embed-responsive-item"})
    episode=soup.find("div", {"class": "embed-responsive embed-responsive-16by9"})
    VideoSrc=episode.find("iframe").get("src")
    print "souf1 VideoLink",VideoSrc

    req = urllib2.Request(VideoSrc)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()
    soup = BeautifulSoup(html, 'html.parser')

    # print "souf1 html",html

    regx='file.*?.m3u'
    VideoLink=re.search(regx, html).group(0).replace('file: "','')+"8"
    # VideoLink="http://dmivll.mangomolo.com/vod/_definst_/smil:2016-09-27/studioPYTFJ.smil/playlist.m3u8"
    
    print "souf1 VideoLink",VideoLink 

    return VideoLink



