#-*- coding: utf-8 -*-
import urllib2
import re     
import xbmc, xbmcgui, xbmcplugin 
import sys

title=['SHAHID']
img=['shahid']
readyForUse=True


############################################################

def list_shows(channel,folder,pageNumber=""):
    print "souf1: list_shows: ",channel,folder,pageNumber
    shows=[]

    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.shahidmbcnet/?mode=3&amp;name=MBC4&amp;url=https%3a%2f%2fshahid.mbc.net%2far%2fchannel%2f7891%2fMBC4.html")')
    
    return shows

def getVideoURL ( channel,url ): # imort from PlayShowLink ( url )
    print "souf1:PlayShowLink ",url 
   
    return url

def list_videos(channel,show_URL):
    print "souf1: list_videos",channel,show_URL
    videos=[] 

      
    return videos

