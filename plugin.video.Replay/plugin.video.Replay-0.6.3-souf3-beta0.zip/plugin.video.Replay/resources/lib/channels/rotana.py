#-*- coding: utf-8 -*-
import urllib2
import re     
import xbmc, xbmcgui, xbmcplugin 

from bs4 import BeautifulSoup

title=['rotana']
img=['rotana']
readyForUse=True 
urlSerie="http://shoof.rotana.net/vod/index.php/programs"
# urlProgram="http://awaan.ae/show/allprograms"
# urlCatg="http://awaan.ae/categories"


def list_shows(channel,folder,pageNumber=""):
    print "souf1: list_shows: ",channel,folder,pageNumber
    shows=[]
    
            
    if folder=='none':
            shows.append( [channel,'Series', 'Series','http://iip.lu/wp-content/uploads/sites/156/2016/04/15700070751_88d83d38fd_o.png','folder'] )
            # shows.append( [channel,'Show', 'Show','http://www.musicnation.me/musicnation-uploads//2014/02/Music-Nation-Bassem-Youssef-El-Bernameg-4.jpg','folder'] )
            # shows.append( [channel,'CategMain', 'categories','https://pbs.twimg.com/media/ClFzy8UWgAAdFVi.jpg','folder'] )
    else:

        if folder=='Series':
                urlShow=urlSerie
        elif folder=='رمضان ٢٠١٦':
                urlShow=urlSerie
        elif folder=='CategMain':
                urlShow=urlCatg
        else:
                urlShow=folder


        

        req = urllib2.Request(urlShow)
        req.add_header('User-agent', 'Mozilla 5.10')
        html=urllib2.urlopen(req).read()

        
        soup = BeautifulSoup(html, 'html.parser')
        # print(soup.get_text().encode('utf-8'))

        print "souf1 urlShow",urlShow

        pages=soup.find_all("div", {"class": "insidepage-filter"})

        # print "souf1 urlShow",urlShow,soup
        # print "souf1 pages",pages
        try:
            for page in pages:
                # print "souf1 page",page

                if folder=='رمضان ٢٠١٦':
                    for i in page.find("div", {"class": "right title"}).contents:
                        # print "souf1 i",i
                        if folder== i.encode('utf-8'):
                            series=page.find_all("li")
                            for serie in series:
                                linkSerie=serie.find("a").get("href").encode('utf-8')
                                print "souf1 linkSerie",linkSerie
                                for i in serie.find("p", {"class": "slidetitle"}).contents:  
                                    SerieName=i.encode('utf-8')                              
                                print "souf1 SerieName",SerieName
                                SerieImage=serie.find("div", {"class": "img_zoom"}).get("src")
                                print "souf1 SerieImage",SerieImage

                                shows.append( [channel,linkSerie, SerieName , SerieImage,'shows'] )


                            


                else:

                    for i in page.find("div", {"class": "right title"}).contents:
                        # print "souf1 i",i
                        GroupName= i.encode('utf-8')

                    print "souf1 GroupName",GroupName

                    # LinkSerie=page.find('a').get("href").encode('utf-8')
                    SerieImage="https://pbs.twimg.com/media/ClFzy8UWgAAdFVi.jpg"


                    print "souf1 LinkSerie, Seriename , SerieImage", GroupName , SerieImage

                    if folder=='Series':
                        shows.append( [channel,GroupName, GroupName ,SerieImage,'folder'] )
                    else:
                        shows.append( [channel,LinkSerie, Seriename , SerieImage,'shows'] )


        except:
            print "except name",page
            raise     

       
    return shows

def list_videos(channel,show_URL):
    print "souf1: list_videos",channel,show_URL
    videos=[] 

    req = urllib2.Request(show_URL)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()
    
    name=''
    image_url=''
    date=''
    duration=''
    views=''
    desc=''
    rating=''
    url=''

    req = urllib2.Request(show_URL)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()

    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, 'html.parser')

    

    #last episode
    episodes=soup.find_all("div", {"class": "big-cont col-lg-9 col-md-12"})
    for v in episodes:
        print "v",v
        VideoLink=v.find("iframe").get("src").encode('utf-8')
        print "souf1 VideoLink",VideoLink
        image_url=""          
        episodename=v.find("h2", {"class": "title-tooltip"}).get("title").encode('utf-8')
        print "souf1 last list_videos: VideoLink, episodename, image_url",VideoLink, episodename, image_url

        infoLabels={ "Title": episodename,"Plot":desc,"Aired":date,"Duration": duration, "Year":date}   
        videos.append( [channel, VideoLink, episodename, image_url,infoLabels,'play'] )

    # episodes=soup.find_all("div", {"class": "post vid-holder col-lg-4 col-md-4 col-s-6"})
    # episodes=soup.find_all("div", {"class": "post vid-holder col-lg-12 col-md-6 col-sm-12"})
    
    try:
        for episode in soup.find_all("div", {"class": "post vid-holder col-lg-12 col-md-6 col-sm-12"}):
            print "souf1 episode",episode
            VideoLink=episode.find('a').get("href").encode('utf-8')
            image_url=episode.find("img", {"alt": "video"}).get("src").encode('utf-8')
          
            episodename=episode.find("h2", {"class": "title-tooltip"}).get("title").encode('utf-8')

            print "souf1 list_videos: VideoLink, episodename, image_url",VideoLink, episodename, image_url


            infoLabels={ "Title": episodename,"Plot":desc,"Aired":date,"Duration": duration, "Year":date}   
            videos.append( [channel, VideoLink, episodename, image_url,infoLabels,'play'] )

        for episode in soup.find_all("div", {"class": "post vid-holder col-lg-4 col-md-4 col-s-6"}):
            print "souf1 episode",episode
            VideoLink=episode.find('a').get("href").encode('utf-8')
            image_url=episode.find("img", {"alt": "video"}).get("src").encode('utf-8')
          
            episodename=episode.find("h2", {"class": "title-tooltip"}).get("title").encode('utf-8')

            print "souf1 list_videos: VideoLink, episodename, image_url",VideoLink, episodename, image_url


            infoLabels={ "Title": episodename,"Plot":desc,"Aired":date,"Duration": duration, "Year":date}   
            videos.append( [channel, VideoLink, episodename, image_url,infoLabels,'play'] )

    except:
        print "souf1 exception" 
        raise       

    return videos

def getVideoURL ( channel,url ): # imort from PlayShowLink ( url )
    print "souf1:PlayShowLink ",url 
    VideoLink=url

    # req = urllib2.Request(url)
    # req.add_header('User-agent', 'Mozilla 5.10')
    # html=urllib2.urlopen(req).read()
    # soup = BeautifulSoup(html, 'html.parser')

    # # episode=soup.find("ifram", {"class": "embed-responsive-item"})
    # episode=soup.find("div", {"class": "embed-responsive embed-responsive-16by9"})
    # VideoSrc=episode.find("iframe").get("src")
    # print "souf1 VideoLink",VideoSrc

    req = urllib2.Request(url)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()
    soup = BeautifulSoup(html, 'html.parser')

    # print "souf1 html",html

    regx='hls: ".*?.m3u8'

    VideoLink=str(re.search(regx, html).group(0).replace('hls: "',''))

    # # VideoLink="http://www.vod-platform.net/embed/p1rIhS2E2Ix6YYRjoLbFg?&RelVideos=1&autohide=1&width=225&height=115&border=0&egm=0&showinfo=0&showsearch=0&autoplay=1"
    # VideoLink="http://svs.itworkscdn.net/rotanavod/smil:itwfcdn/rotanavod/155708.smil/playlist.m3u8"
    # VideoLink="plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;amp;url=http://svs.itworkscdn.net/rotanavod/smil:itwfcdn/rotanavod/155708.smil/playlist.m3u8"
    # VideoLink="plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;amp;url=rtmp://fms.105.net:1935/live/105Test1s"
    # VideoLink="http://svs.itworkscdn.net/rotanavod/smil:itwfcdn/rotanavod/160698.smil/playlist.m3u8"
    print "souf1 VideoLink",VideoLink 

    return VideoLink



