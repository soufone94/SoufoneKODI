#-*- coding: utf-8 -*-
import urllib2
import re     
import xbmc, xbmcgui, xbmcplugin 

from resources.lib import utils
import simplejson as json

from bs4 import BeautifulSoup

title=['rotana']
img=['rotana']
readyForUse=True 
urlSerie="http://rotana.net/vod-series/?vod-element=53660","http://rotana.net/vod-series/?paged1=2&vod-element=53660"



#urlSerie="http://network.cbc-eg.com/series?channelName=drama"
# urlProgram="http://awaan.ae/show/allprograms"
# urlCatg="http://awaan.ae/categories"

def list_shows(channel,folder,pageNumber=""):
    print "souf1: list_shows: ",channel,folder,pageNumber
    shows=[]
    
            
    if folder=='none':
            shows.append( [channel,'Series', 'Series','http://iip.lu/wp-content/uploads/sites/156/2016/04/15700070751_88d83d38fd_o.png','folder'] )
            shows.append( [channel,'Show', 'Show','http://www.musicnation.me/musicnation-uploads//2014/02/Music-Nation-Bassem-Youssef-El-Bernameg-4.jpg','folder'] )
    else:
        if folder=='Series':
                urlShow=urlSerie
        if folder=='Show':
                urlShow=urlProgram

        for url in urlShow:
            req = urllib2.Request(url)
            req.add_header('User-agent', 'Mozilla 5.10')
            html=urllib2.urlopen(req).read()

            
            soup = BeautifulSoup(html, 'html.parser')
            # print("souf1 rotana", soup.get_text().encode('utf-8'))

            articles=soup.find_all('article')
            for article in articles:
                if article.find('img').get('alt')=="VOD Series":
                    LinkSerie=article.get('data-url')
                    SerieImage=article.find('img').get('src')
                    Seriename=LinkSerie.replace("http://rotana.net/vod-series/","").replace("http://rotana.net/vod-series-eps/","").replace("/","")
                    Seriename=""            
                
                    shows.append( [channel,LinkSerie, Seriename , SerieImage,'shows'] )
         
    return shows

def list_videos(channel,show_URL):
    print "souf1: list_videos",channel,show_URL
    videos=[] 

    req = urllib2.Request(show_URL)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()
    
    name=''
    image_url=''
    date=''
    duration=''
    views=''
    desc=''
    rating=''
    url=''

    #get page with all episodes
    req = urllib2.Request(show_URL)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()

    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, 'html.parser')


    lis=soup.find_all('li')
    LinkEp=""
    for li in lis:
        LinkEps=li.get('data-link')
        if LinkEps:
            if "#all_episodes" in LinkEps:
                break
    LinkEps="http://rotana.net"+LinkEps

    #get all videos
    req = urllib2.Request(LinkEps)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()

    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, 'html.parser')


    articles=soup.find_all('article')
    for article in articles:
        VideoLink=article.get('data-url')
        image_url=article.find('img').get('src')
        episodename=article.find('img').get('alt').encode('utf-8') 

        infoLabels={ "Title": episodename,"Plot":desc,"Aired":date,"Duration": duration, "Year":date}   
        videos.append( [channel, VideoLink, episodename, image_url,infoLabels,'play'] )

    return videos

def getVideoURL ( channel,url ): 
    print "souf1:PlayShowLink ",url 
    VideoLink=url

    req = urllib2.Request(url)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()
    soup = BeautifulSoup(html, 'html.parser')

        # episode=soup.find("ifram", {"class": "embed-responsive-item"})
    episode=soup.find("div", {"class": "video-holder"})
    VideoSrc=episode.find("iframe").get("src")
    VideoLink=VideoSrc

    print "souf1 VideoLink",VideoLink 

    return VideoLink




