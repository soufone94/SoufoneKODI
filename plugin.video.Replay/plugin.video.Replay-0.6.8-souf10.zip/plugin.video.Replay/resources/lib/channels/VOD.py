#-*- coding: utf-8 -*-
import urllib2
import re, os    
import xbmc, xbmcgui, xbmcplugin 

from bs4 import BeautifulSoup

from resources.lib import globalvar    

title=['VOD']
img=['VOD']
readyForUse=True

# urlVOD  ="https://www.dropbox.com/s/8bop85mg37i0tex/test.m3u?dl=1"
urlVOD  ="http://bit.ly/2qanRlH"
urlShow=urlVOD  

if not os.path.exists(globalvar.CACHE_DIR):
    os.makedirs(globalvar.CACHE_DIR, mode=0777)
OutStreamDir=globalvar.CACHE_DIR
playlistlocal = os.path.join(globalvar.CACHE_DIR, "playlist-tmp.m3u")


# # OutStreamDir="c:\Users\soufian\AppData\Roaming\Kodi/"
# OutStreamDir="c:/Users/soufian/AppData/Roaming/Kodi/userdata/addon_data/plugin.video.Replay"
# playlistlocal=OutStreamDir + "/playlist-tmp.m3u"


class IPTV():
    def __init__(self, title,tvg,tvIcon,radio,group,xbmc, path,calias,state,SiteEPG,site_id):
        self.title = title
        self.tvg = tvg
        self.tvIcon = tvIcon
        self.radio = radio
        self.group = group
        self.xbmc = xbmc
        self.path = path
        self.calias = calias
        self.state = state        
        self.SiteEPG = SiteEPG
        self.site_id = site_id





def list_shows(channel,folder,pageNumber=""):
    print "souf1: list_shows: ",channel,folder,pageNumber
    shows=[]
    playlist=[]
    
            
    if folder=='none':
            shows.append( [channel,'VOD Arabe', 'VOD Arabe','https://superrepo.org/static/images/icons/original/xplugin.video.Arabic-VOD2.png.pagespeed.ic.sxREEIXw6u.png','shows'] )
            # shows.append( [channel,'Show', 'Show','http://www.musicnation.me/musicnation-uploads//2014/02/Music-Nation-Bassem-Youssef-El-Bernameg-4.jpg','folder'] )
    else:
        print "souf1 folder,name", folder,pageNumber

        # if folder=='Series':
        #         urlShow=urlVOD  
        # if folder=='Show':
        #         urlShow=urlProgram


        # import urllib
        # urllib.urlretrieve (urlShow, playlistlocal)

        # playlist+= GetM3U_data(playlistlocal)

        # for IPTVT in playlist:
        #     # print "MYIPTV", (IPTVT.title, IPTVT.tvg, IPTVT.SiteEPG, IPTVT.site_id, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path)
        #     # print "MYIPTV", (IPTVT.path)
        #     # shows.append( [channel,LinkSerie, Seriename , SerieImage,'shows'] )
        #     shows.append( [channel,IPTVT.path, IPTVT.title , IPTVT.tvIcon,'shows'] )


        #     # infoLabels={ "Title": episodename,"Plot":desc,"Aired":date,"Duration": duration, "Year":date}   
        #     # videos.append( [channel, VideoLink, episodename, image_url,infoLabels,'play'] )
  
    return shows

def list_videos(channel,show_URL):
    print "souf1: list_videos",channel,show_URL
    videos=[] 
    playlist=[]

    
    name=''
    image_url=''
    date=''
    duration=''
    views=''
    desc=''
    rating=''
    url=''

    import urllib
    urllib.urlretrieve (urlShow, playlistlocal)

    playlist+= GetM3U_data(playlistlocal)

    for IPTVT in playlist:
        # print "MYIPTV", (IPTVT.title, IPTVT.tvg, IPTVT.SiteEPG, IPTVT.site_id, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path)
        # shows.append( [channel,IPTVT.path, IPTVT.title , IPTVT.tvIcon,'shows'] )
        if IPTVT.group=="VOD AR":

            infoLabels={ "Title": IPTVT.title,"Plot":desc,"Aired":date,"Duration": duration, "Year":date}   
            videos.append( [channel, IPTVT.path, IPTVT.title, IPTVT.tvIcon,infoLabels,'play'] )
  

    return videos

def getVideoURL ( channel,url ): # imort from PlayShowLink ( url )
    print "souf1:PlayShowLink ",url 
    VideoLink=url
    # VideoLink="http://dmivll.mangomolo.com/vod/_definst_/smil:2016-09-27/studioPYTFJ.smil/playlist.m3u8"
    
    print "souf1 VideoLink",VideoLink 

    return VideoLink

##############################################################################
def supprime_accent(ligne):
    ligne = ligne.lower()
    accent = ['é','É', 'è', 'ê', 'à', 'ù', 'û', 'ç', 'ô','Ô' 'î', 'ï', 'â']
    sans_accent = ['e', 'e','e', 'e', 'a', 'u', 'u', 'c', 'o', 'o', 'i', 'i', 'a']
     
    for c, s in zip(accent, sans_accent):
        ligne = ligne.replace(c, s)

 
    return ligne


def GetM3U_data(M3UPlaylist):
    import re, os, urllib
    print ("start GetM3U_data: playlist: ",M3UPlaylist)
    #logger.info("start GetM3U_data:  playlist: %s ", M3UPlaylist)

    # initialize playlist variables before reading file
    playlist=[]
    if not os.path.exists(OutStreamDir):
                os.makedirs(OutStreamDir)

    if os.path.isfile(M3UPlaylist):
        inf = open(M3UPlaylist,'r')
    else:
        try:
            path, filename = os.path.split(M3UPlaylist)
            try:                
                filename = filename.upper().replace(" ","").replace("?","").replace("!","").replace(".M3U","") + ".m3u"
                urllib.urlretrieve(M3UPlaylist , OutStreamDir+filename)
                inf = open(OutStreamDir+filename,'r')
                print "file name ",filename
            except:   
                raise         
                urllib.urlretrieve(M3UPlaylist , "M3UPlaylist.m3u.tmp")
                inf = open("M3UPlaylist.m3u.tmp",'r')

            
        except IOError as e:
            print "ERROR: M3UPlaylist: get file I/O error({0}): {1}".format(e.errno, e.strerror)
            #logger.info("ERROR: M3UPlaylist: get file : I/O error({0}): {1}".format(e.errno, e.strerror))
            return playlist 
 


    #title,tvg,tvIcon,radio,group, xbmc, path)
    song=IPTV(None,None,None,None,None,None,None,None,None,None,None)

    for line in inf:
        # print "===>>> line",line
        line=line.strip()
        if line and not line.startswith('#EXTM3U'):
            
            ##EXTINF:-1 tvg-id="2M" tvg-name="2M" tvg-logo="2M.png" group-title="Maroc"2M
            if line.startswith('#EXTINF:'):
            
                # line = str(line.strip())            
                line=supprime_accent(line)
                
                try:
                    rest,title = line.rsplit(',',1)              
                    #title = re.search(r'(?<=tvg-id=").*?(?=")', line).group(0)              
                except:
                    try:                                  
                        rest,title = line.rsplit(',',1)
                    except:
                        try:
                            rest,title = line.rsplit('#EXTINF:-1',1)
                        except:
                            title=line.replace("#extinf:-1",'').split()
                                
                # title= str(title)
                # title = title.replace(',','').replace('-1','').replace('0','').replace(':-',' ')
                # print "== title",str(title)
                title = re.sub(r"\[.+?\]", "", title)
                title = title.upper().strip()

            

                try: 
                    tvg = re.search(r'(?<=tvg-name=").*?(?=")', line).group(0).strip()
                except:
                    tvg =''
                try: 
                    tvIcon = re.search(r'(?<=tvg-logo=").*?(?=")', line).group(0)
                except:
                    tvIcon =''
                
                try: 
                    radio = re.search(r'(?<=radio=").*?(?=")', line).group(0)
                except:
                    radio =''
                
                try: 
                    group = re.search(r'(?<=group-title=").*?(?=")', line).group(0)
                except:
                    group =''

                xbmc=title.replace("HD","").strip()

                song=IPTV(title,tvg,tvIcon,radio,group.upper(),xbmc,None,None,None,None,None)
                #print "title group",title, group.upper()

            else:
                song.path=line
                playlist.append(song)
                # reset the song variable so it doesn't use the same EXTINF more than once
                song=IPTV(None,None,None,None,None,None,None,None,None,None,None)

    inf.close()
    #for IPTVT in playlist:
     #    print (IPTVT.title, IPTVT.tvg, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path)
      
    return playlist

