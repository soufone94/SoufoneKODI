#-*- coding: utf-8 -*-
import urllib2
import re     
# import xbmc, xbmcgui, xbmcplugin 

from bs4 import BeautifulSoup

title=['mesfilm']
img=['mesfilm']
readyForUse=False

filmTitle="007 spectre"
url="https://www.google.fr/search?q="+filmTitle.replace(" ","+")
url="http://www.elcinema.com/ar/search/?q=WHO%20AM%20I"


def list_film(channel,url):
    print "list_film",(url)
    shows=[]

    page=""
    for i in range(1):
        if i>0:
            page="/page/"+str(i)
            
        urlShow=url
       
        print "urlShow_",urlShow
        req = urllib2.Request(urlShow)
        req.add_header('User-agent', 'Mozilla 5.10')
        html=urllib2.urlopen(req).read()

        
        soup = BeautifulSoup(html, 'html.parser')
        # print"soup.get_text()",(soup.get_text().encode('utf-8'))


        divs=soup.find_all('div')
        for div in divs:
            # print "****", div
            if div.get('class')=="row":
                miniDivs=div.findall('div')
                for miniDiv in miniDivs:
                    if miniDiv.get('class')=="padded-half":

                        lis=div.findall('li')

                        print "lis",lis

                        for li in lis:
                            print "li", li

            # try:
            #     print "****"
            # #     if div.get('class')=="padded-half":
            # #         print "moviefilm", div
            # #         raise


            #             # divjs=div.find_all('div')
            #             # SerieImage=str(div.find("img").get("src").encode('utf-8'))            
            #             # for j in divjs:               
            #             #     for p in j.get('class'):
            #             #         movief=p
            #             #         if movief=="movief":
            #             #             print ">>> moviefJ",j
            #             #             try:
            #             #                 LinkSerie=str(j.find('a').get("href"))
            #             #                 for n in j.find('a').contents:
            #             #                     Seriename=str(n.encode('utf-8'))   
            #             #                     l=LinkSerie

            #             #                     l=re.sub("[^0-9]", "", l)

            #             #                     year=l[-4:]
            #             #                     print "LinkSerie,year,Seriename", LinkSerie,year,Seriename                                                               
                                                      
            #             #                     shows.append( [year,channel,LinkSerie, Seriename , SerieImage,'play'] )
            #             #             except:
            #             #                 print "except name",div
            #             #                 raise
            #             #                 pass

            # except:
            #     raise
            #     pass  

        shows.sort(key=lambda tup: tup[0],reverse=True) 

    #remove year in show list
    shows = [[x[1],x[2],x[3],x[4],x[5]] for x in shows]

    return shows

def list_episode(channel,url):
    print "list_episode    ",(url)
    shows=[]

    page=""
    for i in range(10):
        if i>0:
            page="/page/"+str(i)
            
        urlShow=url+page
       
        print "urlShow_",urlShow
        req = urllib2.Request(urlShow)
        req.add_header('User-agent', 'Mozilla 5.10')
        html=urllib2.urlopen(req).read()

        
        soup = BeautifulSoup(html, 'html.parser')
        # print"soup.get_text()",(soup.get_text().encode('utf-8'))

        divs=soup.find_all('div')


        for div in divs:
            try:
                for i in div.get('class'):
                    if i=="moviefilm":
                        print "moviefilm", div
                        
                        SerieImage=str(div.find("img").get("src").encode('utf-8'))   
                        LinkSerie=str(div.find('a').get("href"))  
                        divjs=div.find_all('div')        
                        for j in divjs:               
                            for p in j.get('class'):
                                movief=p
                                if movief=="movief":
                                    print ">>> moviefJ",j
                                    try:
                                        for n in j.find('a').contents:
                                            Seriename=str(n.encode('utf-8'))   
                                            l=LinkSerie

                                            l=re.sub("[^0-9]", "", l)

                                            year=l[-4:]
                                            print "LinkSerie,year,Seriename", LinkSerie,year,Seriename                                                               
                                                      
                                            shows.append( [channel,LinkSerie, Seriename , SerieImage,'shows'] )
                                    except:
                                        print "except name",div
                                        raise
                                        pass

            except:
                # raise
                pass  

    # shows.sort(key=lambda tup: tup[2],reverse=True) 
    print "AllShows",  shows 

    return shows


def list_shows(channel,folder,pageNumber=""):
    print "souf1: list_shows: ",channel,folder,pageNumber
    shows=[]
    
            
    if folder=='none':
            shows.append( [channel,'Film', 'Film','http://i.huffpost.com/gen/1516995/images/o-CINEMA-ARABE-facebook.jpg','folder'] )
            
    else:
        print "souf1 folder,name", folder,pageNumber


        if folder=='Film':
                url
                shows=list_videos(channel,url)

        
    return shows

def list_videos(channel,show_URL):
    import re  
    print "souf1: list_videos",channel,show_URL
    videos=[] 

    req = urllib2.Request(show_URL)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()
    
    name=''
    image_url=''
    date=''
    duration=''
    views=''
    desc=''
    rating=''
    url=''

    req = urllib2.Request(show_URL)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()

    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, 'html.parser')

    divs=soup.find_all("div", {"class": "thumbnail-wrapper"})

    print str(divs[0].find("img").get("src").encode('utf-8'))  
    # print divs[0]

    for i in divs[0]:
        # print "i", i
        if "href" in str(i):
            try:
                print "bingo", str(i)
                regx='<a href="*?"><img alt="" src="*?"/></a>'
                print re.search(regx, str(i))

                # img,fiche=re.search(regx, i)
                # print img,fiche
            except:
                pass


   
    
    # As=divs.findall('a',{"href"})
    # for a in As:
    #     print a
        # print a.get("href").encode('utf-8')) 
    
    # for div in divs:
    #     print str(div.find("a").get("href").encode('utf-8'))    
        # if div.get('class')[0]==u"padded-half":
        #     print "div", div[2]
        #     ds=div.get('class').findall('li')
        #     for d in ds: 
        #         print "\n d: ",d
        #         raise


    # try:
    #     for link in links:
    #         episodename="Play"
            
    #         VideoLink=link.find('a').get("href").encode('utf-8')
    #         image_url=link.find('img').get("src").encode('utf-8')
    #         divjs=link.find_all('div')        
    #         for j in divjs:               
    #             for p in j.get('class'):
    #                 if p=="movief":
    #                     print ">>> moviefJ",j
    #                     try:
    #                         for n in j.find('a').contents:
    #                             episodename=str(n.encode('utf-8')) 
    #                     except:
    #                         pass

    #         print "souf1 VideoLink",VideoLink,image_url
    #         print "shahid4u videos",channel, VideoLink, episodename, image_url

    #         infoLabels={ "Title": episodename,"Plot":desc,"Aired":date,"Duration": duration, "Year":date}   
    #         videos.append( [channel, VideoLink, episodename, image_url,infoLabels,'play'] )

    # except:
    #     raise
    #     print "souf1 exception" 

    # # titles=soup.find_all("div", {"class": "titleMovie"})

    # # try:
    # #     print "souf1 titles",titles
    # #     for title in titles:

    # #         episodename=title.find("h2", {"class": "titleMovie"}).contents.encode('utf-8')
    # # except:
    # #     raise


    
    


 

    return videos

def getVideoURL ( channel,url ): # imort from PlayShowLink ( url )
    print "souf1:PlayShowLink ",url 

    req = urllib2.Request(url)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()

    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, 'html.parser')

    links=soup.find_all("div", {"class": "singleSide"})
    try:
        for link in links:
            
            VideoLink=link.find('a').get("href").encode('utf-8')
            print "souf1 VideoLink",VideoLink
    except:
        raise
        print "souf1 exception" 
    

    req = urllib2.Request(VideoLink)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.117 Safari/537.36')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()

    # playURL= match =re.findall('id  : "(.*?)",\s*pricingPlanId  : "(.*?)"', link)
    print "shahid40_link",link 
    soup = BeautifulSoup(link, 'html.parser')
    # print(soup.get_text().encode('utf-8'))

    divs=soup.find_all('div')
    # print "soup",soup


    for div in divs:
        try:
            print "div.get('id')",div.get('id')
            if len(div.get('id')):
                LinkCode=str(div.find("iframe").get("src").encode('utf-8'))  
        except:
            # raise
            pass
    print "LinkCode",LinkCode
    # src="https://openload.co/embed/yskurKT7O7Y"
    # src="http://estream.to/embed-ijswtlkib3qx.html"

    VideoId=LinkCode.replace("https://openload.co/embed/","").replace("http://estream.to/embed-","").replace(".html","")

    # #////////


    # VideoId=re.findall('src="http://estream.to/embed-(.*?).html"', link)
    # VideoId=str(VideoId).replace("['","").replace("']","").replace("]","").replace("[","")

    # if len(VideoId)==0:    
    #     # src="https://estream.to/embed-pjtykeatb7aj.html"    
    #     VideoId=re.findall('src="https://estream.to/embed-(.*?).html"', link)
    #     VideoId=str(VideoId).replace("['","").replace("']","")
    # #/////
     

    print "VideoId", VideoId

    #///////////////////
    videoPath="https://estream.to/embed-"+VideoId+".html"

    url=LinkCode
    print "url",url

    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.117 Safari/537.36')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()

    # playURL= match =re.findall('id  : "(.*?)",\s*pricingPlanId  : "(.*?)"', link)
    # print "shahid40_link",link 
    link=link.replace('"',"'")

    # VideoMP4,res=re.findall("<source src='(.*?)' type='video/mp4' label='854x480' res='(.*?)'", link)
    VideoMP4=re.findall("<source src='(.*?)' type='application/x-mpegURL'", link)
    VideoLink=str(VideoMP4).replace("['","").replace("']","")
    # VideoLink="https://s46.escdn.co/jg6nt6dwiftu7m7cyy2vm4qwsmtw4ulvq3czjf7hiixlwxr445ilrbyphyga/v.mp4"





    # VideoLink="http://dmivll.mangomolo.com/vod/_definst_/smil:2016-09-27/studioPYTFJ.smil/playlist.m3u8"
    
    print "souf1 VideoLink",VideoLink 

    return VideoLink


list_videos("channel",url)
