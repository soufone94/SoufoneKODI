#-*- coding: utf-8 -*-
import urllib2
import re     
import xbmc, xbmcgui, xbmcplugin 

from bs4 import BeautifulSoup

title=['shahid4u']
img=['shahid4u']
readyForUse=True
urlSerie="http://shahid4u.com/category/ramadan/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA-%D8%B1%D9%85%D8%B6%D8%A7%D9%86-2017"
urlProgram="http://awaan.ae/show/allprograms"
urlFilm="http://shahid4u.com/category/movies/%D8%A7%D9%81%D9%84%D8%A7%D9%85-%D8%B9%D8%B1%D8%A8%D9%89"



def list_shows(channel,folder,pageNumber=""):
    print "souf1: list_shows: ",channel,folder,pageNumber
    shows=[]
    
            
    if folder=='none':
            # shows.append( [channel,'Series', 'Series','http://iip.lu/wp-content/uploads/sites/156/2016/04/15700070751_88d83d38fd_o.png','folder'] )
            shows.append( [channel,'Film', 'Film','http://i.huffpost.com/gen/1516995/images/o-CINEMA-ARABE-facebook.jpg','folder'] )
            #shows.append( [channel,'Show', 'Show','http://www.musicnation.me/musicnation-uploads//2014/02/Music-Nation-Bassem-Youssef-El-Bernameg-4.jpg','folder'] )
    else:
        print "souf1 folder,name", folder,pageNumber

        if folder=='Series':
                url=urlSerie
        if folder=='Film':
                url=urlFilm
        if folder=='Show':
                url=urlProgram

        page=""
        for i in range(10):
            if i>0:
                page="/page/"+str(i)
            
            urlShow=url+page


            #///// par page 
            print "urlShow",urlShow
            req = urllib2.Request(urlShow)
            req.add_header('User-agent', 'Mozilla 5.10')
            html=urllib2.urlopen(req).read()

            
            soup = BeautifulSoup(html, 'html.parser')
            # print(soup.get_text().encode('utf-8'))

            divs=soup.find_all('div')


            for div in divs:
                try:
                    for i in div.get('class'):

                        if i=="moviefilm":
                            # print "moviefilm", div
                            divjs=div.find_all('div')
                            SerieImage=str(div.find("img").get("src").encode('utf-8'))                        
                            for j in divjs:                           
                                for p in j.get('class'):
                                    movief=p
                                if movief=="movief":
                                    print ">>> moviefJ",j
                                    try:
                                        
                                        
                                        LinkSerie=str(j.find('a').get("href"))
                                        for n in j.find('a').contents:
                                            Seriename=str(n.encode('utf-8'))   

                                                     # print "shahid4u:list_shows: LinkSerie",  LinkSerie
                                        # print "shahid4u:list_shows: Seriename",  Seriename
                                        # print "shahid4u:list_shows: SerieImage",  SerieImage
                                        l=LinkSerie

                                        l=re.sub("[^0-9]", "", l)

                                        year=l[-4:]
                                        print "LinkSerie,year,Seriename", LinkSerie,year,Seriename


                                                                               
                                      
                                        shows.append( [channel,LinkSerie, year+"<>"+Seriename , SerieImage,'play'] )
                                    except:
                                        print "except name",div
                                        # raise
                                        pass

                except:
                    # raise
                    pass  
    shows.sort(key=lambda tup: tup[2],reverse=True) 
    print "AllShows",  shows 
    return shows

def list_videos(channel,show_URL):
    print "souf1: list_videos",channel,show_URL
    videos=[] 

    req = urllib2.Request(show_URL)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()
    
    name=''
    image_url=''
    date=''
    duration=''
    views=''
    desc=''
    rating=''
    url=''

    req = urllib2.Request(show_URL)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()

    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, 'html.parser')

    links=soup.find_all("div", {"class": "singleSide"})
    try:
        for link in links:
            
            VideoLink=link.find('a').get("href").encode('utf-8')
            print "souf1 VideoLink",VideoLink
    except:
        raise
        print "souf1 exception" 

    episodename=""

    titles=soup.find_all("div", {"class": "titleMovie"})

    try:
        print "souf1 titles",titles
        for title in titles:

            episodename=title.find("h2", {"class": "titleMovie"}).contents.encode('utf-8')
    except:
        raise


    image_url=""
    episodename="Play"

    print "shahid4u videos",channel, VideoLink, episodename, image_url

    infoLabels={ "Title": episodename,"Plot":desc,"Aired":date,"Duration": duration, "Year":date}   
    videos.append( [channel, VideoLink, episodename, image_url,infoLabels,'play'] )


        # raise       

    return videos

def getVideoURL ( channel,url ): # imort from PlayShowLink ( url )
    print "souf1:PlayShowLink ",url 

    req = urllib2.Request(url)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()

    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, 'html.parser')

    links=soup.find_all("div", {"class": "singleSide"})
    try:
        for link in links:
            
            VideoLink=link.find('a').get("href").encode('utf-8')
            print "souf1 VideoLink",VideoLink
    except:
        raise
        print "souf1 exception" 
    

    req = urllib2.Request(VideoLink)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.117 Safari/537.36')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()

    # playURL= match =re.findall('id  : "(.*?)",\s*pricingPlanId  : "(.*?)"', link)
    print "shahid40_link",link 
    soup = BeautifulSoup(link, 'html.parser')
    # print(soup.get_text().encode('utf-8'))

    divs=soup.find_all('div')
    # print "soup",soup


    for div in divs:
        try:
            print "div.get('id')",div.get('id')
            if len(div.get('id')):
                LinkCode=str(div.find("iframe").get("src").encode('utf-8'))  
        except:
            # raise
            pass
    print "LinkCode",LinkCode
    # src="https://openload.co/embed/yskurKT7O7Y"
    # src="http://estream.to/embed-ijswtlkib3qx.html"

    VideoId=LinkCode.replace("https://openload.co/embed/","").replace("http://estream.to/embed-","").replace(".html","")

    # #////////


    # VideoId=re.findall('src="http://estream.to/embed-(.*?).html"', link)
    # VideoId=str(VideoId).replace("['","").replace("']","").replace("]","").replace("[","")

    # if len(VideoId)==0:    
    #     # src="https://estream.to/embed-pjtykeatb7aj.html"    
    #     VideoId=re.findall('src="https://estream.to/embed-(.*?).html"', link)
    #     VideoId=str(VideoId).replace("['","").replace("']","")
    # #/////
     

    print "VideoId", VideoId

    #///////////////////
    videoPath="https://estream.to/embed-"+VideoId+".html"

    url=LinkCode
    print "url",url

    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.117 Safari/537.36')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()

    # playURL= match =re.findall('id  : "(.*?)",\s*pricingPlanId  : "(.*?)"', link)
    # print "shahid40_link",link 
    link=link.replace('"',"'")

    # VideoMP4,res=re.findall("<source src='(.*?)' type='video/mp4' label='854x480' res='(.*?)'", link)
    VideoMP4=re.findall("<source src='(.*?)' type='application/x-mpegURL'", link)
    VideoLink=str(VideoMP4).replace("['","").replace("']","")
    # VideoLink="https://s46.escdn.co/jg6nt6dwiftu7m7cyy2vm4qwsmtw4ulvq3czjf7hiixlwxr445ilrbyphyga/v.mp4"





    # VideoLink="http://dmivll.mangomolo.com/vod/_definst_/smil:2016-09-27/studioPYTFJ.smil/playlist.m3u8"
    
    print "souf1 VideoLink",VideoLink 

    return VideoLink



