#-*- coding: utf-8 -*-
import urllib2
import re     
import xbmc, xbmcgui, xbmcplugin 
import json

title=['youtube']
img=['youtube']
readyForUse=True

username="2MTV"

googleUrl="https://www.googleapis.com/youtube/v3/"
apikey='AIzaSyCl5mHLlE0mwsyG4uvNHu5k1Ej1LQ_3RO4'


def getJson(url):
    print "souf1 getJson:",url
    req = urllib2.Request(url)
    req.add_header('User-Agent','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.154 Safari/537.36')
    response = urllib2.urlopen(req)
    #link=response.read()
    #response.close()
    decoded = json.load(response)
    return decoded

def getChannelIdByUserName(username):
    try:
        u_url='https://www.googleapis.com/youtube/v3/channels?part=id&forUsername=%s&key=%s'%(username,apikey)

        channelData=getJson(u_url)
        print "souf1 getChannelIdByUserName:",u_url, channelData
        return channelData['items'][0]['id']
    except: 
        raise
        return "IDNOTFOUND"

def getYouTubePlayList(channelId):
    if not channelId.startswith('https://www.googleapis'):
        u_url='https://www.googleapis.com/youtube/v3/playlists?part=snippet&channelId=%s&maxResults=5&key=%s'%(channelId,apikey)
    else:
        u_url=channelId
    print "souf1: getYouTubePlayList:", channelId, u_url
    doc=getJson(u_url)
    ret=[]
    for playlist_item in doc['items']:
        
        title = playlist_item["snippet"]["title"]
        id = playlist_item["id"]
        if not title=='Private video':
            imgurl=''
            try:
                imgurl= playlist_item["snippet"]["thumbnails"]["high"]["url"]
            except: pass
            if imgurl=='':
                try:
                    imgurl= playlist_item["snippet"]["thumbnails"]["default"]["url"]
                except: pass
            ret.append([title,id,imgurl])
    nextItem=None
    if 'nextPageToken' in doc:
        nextItem=doc["nextPageToken"]
    else:
        nextItem=None
        
    nextUrl=None
    if nextItem:
        if not '&pageToken' in u_url:
            nextUrl=u_url+'&pageToken='+nextItem
        else:
            nextUrl=u_url.split('&pageToken=')[0]+'&pageToken='+nextItem
    print "souf1 getYouTubePlayList:",ret,nextUrl
        
    return ret,nextUrl;

              
def getYoutubeVideosByPlaylist(playlistId):
    if playlistId.startswith('https://www'):
        #nextpage
        u_url=playlistId
    else:
        u_url='https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=5&playlistId=%s&key=%s'%(playlistId,apikey)
    videos=getJson(u_url)
    
    print "souf1: getYoutubeVideosByPlaylist:", playlistId, videos
    return prepareYoutubeVideoItems(videos,u_url)

    
def prepareYoutubeVideoItems(videos,urlUsed):
    print "souf1: prepareYoutubeVideoItems",videos,urlUsed
    global content_type,overridemode
    content_type='episodes'
    overridemode=50
    #print 'urlUsed',urlUsed
    if 'nextPageToken' in videos:
        nextItem=videos["nextPageToken"]
    else:
        nextItem=None
    videoids=[]
    for playlist_item in videos["items"]:
        if not 'search?part=snippet' in urlUsed:
            video_id = playlist_item["snippet"]["resourceId"]["videoId"]
        else:
            video_id =playlist_item["id"]["videoId"]   
        videoids+=[video_id]
    vinfo=getVideoDetails(','.join(videoids))
    yt_items = vinfo.get('items', [])
    _video_data={}
    for yt_item in yt_items:
        video_id = unicode(yt_item['id'])
        _video_data[video_id] = yt_item
        
    #print _video_data
    ret=[]
    for playlist_item in videos["items"]:
        title = playlist_item["snippet"]["title"]


        #print 'urlUsed',urlUsed
        if not 'search?part=snippet' in urlUsed:
            video_id = playlist_item["snippet"]["resourceId"]["videoId"]
        else:
            video_id =playlist_item["id"]["videoId"]
        duration=None
        try:
            _dur= _video_data[video_id]['contentDetails']['duration']
            duration= int(parseYoutubDateTime(_dur).seconds - 1)
        except: pass
        date=None
        try:

            date= parseYoutubDateTime(playlist_item["snippet"]['publishedAt'])
            print date
        except: pass
        description=None
        try:
            description=strip_html_from_text( playlist_item["snippet"]['description'])
        except: pass
        #print description.encode("utf-8")
        if not title=='Private video':
            imgurl=''
            try:
                imgurl= playlist_item["snippet"]["thumbnails"]["high"]["url"]
            except: pass
            if imgurl=='':
                try:
                    imgurl= playlist_item["snippet"]["thumbnails"]["default"]["url"]
                except: pass
        #print "%s (%s)" % (title, video_id)
            ret.append([title,video_id,imgurl,duration,description,date])
    nextUrl=None
    if nextItem:
        if not '&pageToken' in urlUsed:
            nextUrl=urlUsed+'&pageToken='+nextItem
        else:
            nextUrl=urlUsed.split('&pageToken=')[0]+'&pageToken='+nextItem
    return ret,nextUrl;








def list_shows(channel,folder):
    print "souf1: list_shows: ",channel,folder
    shows=[]

    channelId=getChannelIdByUserName(username)
    playlists,nextUrl=getYouTubePlayList(channelId)

    print "souf1 playlists",playlists
    for playList in playlists:
        shows.append( [channel,playList[1].encode('utf-8'), playList[0].encode('utf-8') , playList[2].encode('utf-8'),'folder'] )
    
    return shows

def getVideoURL(channel,video_URL):
    print "souf1: getVideoURL: ",channel,video_URL
    req = urllib2.Request(video_URL+'/5')
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()
    match=re.compile('<IFRAME SRC="(.*?)" FRAMEBORDER',re.DOTALL).findall(html)
    youwatchurl=match[0]
    
    req = urllib2.Request(youwatchurl)
    html=urllib2.urlopen(req).read()
    html=html.replace('|','/')
    
    stream=re.compile('/mp4/video/(.+?)/(.+?)/(.+?)/setup',re.DOTALL).findall(html)
    for videoid,socket,server in stream:
        continue
    stream_url='http://'+server+'.youwatch.org:'+socket+'/'+videoid+'/video.mp4?start=0'
    return stream_url

def list_videos(channel,show_URL):
    print "souf1: list_videos",channel,show_URL
    videos=[] 

    req = urllib2.Request(show_URL)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()
    
    name=''
    image_url=''
    date=''
    duration=''
    views=''
    desc=''
    rating=''
    url=''

    req = urllib2.Request(show_URL)
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()

    
    regstring='<a href="(\/ar\/episode.*?)">\s.*\s.*\s.*\s.*\s.*\s.*<img .*?alt="(.*?)" src="(.*?)".*\s.*.*\s.*.*\s.*.*\s.*.*\s.*.*\s.*\s*.*?>(.*?)<\/div>\s*.*?>(.*?)<\/div>'
    # regstring='<a href="(\/ar\/episode/*?)">\s.*\s.*\s.*src="(.*?)"'
    # regstring='<a href="(\/ar\/episode/*?)">\s.*\s*.*\s.*'
    match =re.findall(regstring, html)

    # dialog = xbmcgui.Dialog()
    # ok = dialog.ok('match', str(match))

    print "souf1 show match:", match

    if match:
        for link,serie,image_url,name,date in match:
    
            infoLabels={ "Title": name,"Plot":desc,"Aired":date,"Duration": duration, "Year":date}   
            videos.append( [channel, urlBase+link, name, image_url,infoLabels,'play'] )
            print "souf1: resume",channel, urlBase+link, name, image_url
    
    return videos