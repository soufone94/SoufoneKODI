# plugin.video.Replay
Replay : an XBMC addon

Addon for Kodi that retrieves the replay info from different french channels
