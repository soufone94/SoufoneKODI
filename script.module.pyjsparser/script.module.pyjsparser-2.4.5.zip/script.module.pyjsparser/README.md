script.module.pyjsparser
======================

Python pyjsparser library packed for Kodi.

See https://github.com/PiotrDabkowski/pyjsparser
