# -*- coding: utf-8 -*-

def DownloadFile(OtmanIPTV , OtmanIPTVfile):
    import time, urllib
    import cfscrape

    scraper = cfscrape.create_scraper()  # returns a CloudflareScraper instance
    # Or: scraper = cfscrape.CloudflareScraper()  # CloudflareScraper inherits from requests.Session
    Cleanplaylist=scraper.get(OtmanIPTV).content  # => "<!DOCTYPE html><html><head>..."

    f = open(OtmanIPTVfile, "w")
    f.write(Cleanplaylist.strip())
    f.close()


    # try: # some connection issue
    #     urllib.urlretrieve(OtmanIPTV , OtmanIPTVfile)
    # except:
    #     # print "\nconnection issue, retray in 2S ... "
    #     time.sleep(2)
    #     urllib.urlretrieve(OtmanIPTV , OtmanIPTVfile)
        
    return 

OtmanIPTV="http://electrowazan9.com:80/get.php?username=soufone2&password=R3px9OfXWs&type=m3u_plus&output=ts"
OtmanIPTVfile="c:\Users\soufian\AppData\Roaming\Kodi\cache/tmp.m3u"
import datetime

print str(datetime.datetime.now()).replace(":","")