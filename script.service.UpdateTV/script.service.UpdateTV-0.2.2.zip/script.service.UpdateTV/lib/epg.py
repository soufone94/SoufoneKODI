# -*- coding: utf-8 -*-

from MyApi import *
import MyFile
import globalvar


class Channel():
	def __init__(self, title,tvgSmart,tvgIPTV,tvIcon,radio,group,xbmc, path,calias,state,SiteEPG,site_id,lang):
		self.title = title
		self.tvgSmart = tvgSmart
		self.tvgIPTV = tvgIPTV
		self.tvIcon = tvIcon
		self.radio = radio
		self.group = ""
		self.xbmc = xbmc
		self.path = path
		self.calias = ""
		self.state = state		
		self.SiteEPG = SiteEPG
		self.site_id = site_id
		self.lang = lang


API_KEY="eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6ImVhYzQ0NDExNTJjNjdlZDlmZWY1NDBhYWYwOGY3YzZkMWNlNGJlNTBjMDJlYWQ5Mjg0NDQxMzk3YWY0N2ZhNGExNDFlNTk4MmQ2YjE2NjUwIn0.eyJhdWQiOiIxIiwianRpIjoiZWFjNDQ0MTE1MmM2N2VkOWZlZjU0MGFhZjA4ZjdjNmQxY2U0YmU1MGMwMmVhZDkyODQ0NDEzOTdhZjQ3ZmE0YTE0MWU1OTgyZDZiMTY2NTAiLCJpYXQiOjE1MDc5OTg2NjMsIm5iZiI6MTUwNzk5ODY2MywiZXhwIjoxNTM5NTM0NjYzLCJzdWIiOiIzNDUzIiwic2NvcGVzIjpbXX0.DI4oLT0NkqDfYVkBJ1QamtZyQ4TVS_PZuuVymwYwTKFkB0FLjpypU8hItUrWbREOqeS37seopN2f7SOppDeAVaWKPbq2IdSSLrIxrzVBVMMPjII0U1yo-wW-rw48tsEYaHPFXTHEGrhb6zzHOvxygP3awRPZNeGDVznuCh0HTNBWR1XK4O9fFz6Hi45OQZ2NHWgRZ1vkTasJCqz4_4ewPwuGnweRwSpenfTV5IJhrL2N8FlRlb0BFhwulmjc9Kgt6xu31KqMG7hnw43JZ5sxNlZj8QfjWw8NENgqw2WR3AFFr6Q71SBaggns7M9Wgb0kHS52FMvSPFIXnRVqbqIqGLtgeDy_9MVCF8bVLCknkPA9lC9iUsytkpCuNQ6CxWu072fNMxbFBYAtPIoXRncpAcwE44cUw-dP-uQSm8yNF9ZZ1B0SJMsVNCVCPvJbXfdTvoX1tBZagmMX6uIHpxMX22nGB1U2LiaCZQPlHNMYLsYMi4z-d13ps7bbjuaDdmJtXr06OS3ihyIOU1qybP3SxQHmkffbdTY9KxTgWtRQqWZ_WKu_k1nZuZda1mLNh3zEXkTPWtknk9JuRvFMn2gGWogTdVi3yPN7dbwfP0O51K_DfefzeFu5onsddxCHOWteQkgpxGII2o7OhizYxRmDj7TIlxF0jCdInbmqN0G8Qps"
# Authorization: Bearer <API_KEY>
channelURL="https://www.iptv-epg.com/api/channels"
EPGurl="http://iptv-epg.com/d7d-mq2i3s.xml"
# EPGurl="https://www.dropbox.com/s/6rwvfv37egf6xyg/iptv-epg.xmltv?dl=1"
ChannelFile=globalvar.OutDir+"/iptv-channels.json"

SMARTIPTV_FR="https://www.dropbox.com/s/9mhe62dhmz7wwfo/EPG-samrtIPTV-FR.csv?dl="
SMARTIPTV_OSN="https://www.dropbox.com/s/7w8tdykezuxkxv0/EPG-samrtIPTV-OSN.csv?dl=1"

FavoriteCountry=["ae","fr","sa","eg","ma","iq","qa","lb","be"]

def IsFavoriteCountry(country):
	for c in FavoriteCountry:
		if c.upper()==country.upper():
			return True
	return False

def UpdateDB_FromIPTVEPG(Jsondatabase):
	print "> UpdateDB_FromIPTVEPG"
	# import libxmltv.xmltv as xmltv
	from pprint import pprint

	import urllib2

	DOWNLOAD_URL = 'http://www.nasdaq.com/screening/companies-by-name.aspx?&render=download'
	DOWNLOAD_URL = "http://iptv-epg.com/d7d-mq2i3s.xml"

	hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11'}
	req = urllib2.Request(EPGurl, headers=hdr)
	page = urllib2.urlopen(req)

	local_guide=globalvar.OutDir+"/guide.xmltv"

	with open(local_guide, "wb") as local_file:
		local_file.write(page.read())

	# urllib.urlretrieve(EPGurl , local_guide)
	# urllib.urlretrieve(channelURL ,ChannelFile )

	guide=open(globalvar.OutDir+"/guide.xmltv", 'r')
	for l in guide:
		if l.startswith("<tv><channel id="):
			c=l.replace('<tv><channel id="',"").replace('">',"")
		
			found=False
			# # print c
			# tvg_id=c['display-name'][0][0]
			# name,lang=c['id'].rsplit(".",1)
			name=c
			# print "\n ======="
			# print "xmltv channel name ", name

			for chaine in Jsondatabase:
				for i in chaine["calias"]:	
					# print "alias in JsonDB", i.encode('utf-8')			
					if MyFile.purge(name,"")==MyFile.purge(i,""):
						try:
							chaine["tvgIPTV"]=tvg_id.replace(" ","_").encode('utf-8')
							# print '>>> chaine["tvgIPTV"]=',chaine["tvgIPTV"]
						except:
							raise
							chaine["tvgIPTV"]=name
							print ">>>> UpdateDB_FromIPTVEPG: change epg name", chaine["tvgIPTV"]
							# raise
						found=True
						break
				
				if found==True:
					# print 'chaine["tvgIPTV"]', chaine["tvgIPTV"]
					break
			

	SortedJsondatabase = sorted(Jsondatabase, key=lambda k: k['Title'], reverse=False) 
	# print SortedJsondatabase
	print "< UpdateDB_FromIPTVEPG"
	return SortedJsondatabase

def UpdateDB_FromSMARTIPTV():

	database=[]
	epg=[]


	SMARTIPTV_OSN_local=TmpDir+"/SMARTIPTV_OSN.csv"
	urllib.urlretrieve(SMARTIPTV_OSN , SMARTIPTV_OSN_local)
	SMARTIPTV_FR_local=TmpDir+"/SMARTIPTV_FR.csv"
	urllib.urlretrieve(SMARTIPTV_FR , SMARTIPTV_FR_local)
	
	rootData = ET.parse(ChannelDataBase, parser=ET.XMLParser(encoding="utf-8" ))
	rootChannels=rootData.find('channels')

	import csv
	dictReader = csv.DictReader(open(SMARTIPTV_OSN_local, 'rb'), fieldnames = ['Channel Name', 'EPG Code', 'Popularity'], delimiter = ';', quotechar = '"')
	for row in dictReader:
		epg.append(row)



	# print ">>>", row['Channel Name']
	for channel in rootChannels.findall('channel'):  
		chaine=Channel(None,None,None,None,None,None,None,None,[],None,None,None,None)
		

		chaine.title=channel.find('cname').text.encode('utf-8')
		# print channel.find('cname').text.encode('utf-8')
		for calias in channel.findall('calias'):
			if calias.text != None:
				chaine.calias.append(calias.text.encode('utf-8'))

				for i in epg:

					if MyFile.purge(i['Channel Name'],"")==MyFile.purge(calias.text.encode('utf-8'),""):						
						chaine.tvgSmart=i['EPG Code']
						name,chaine.lang=chaine.tvgSmart.rsplit(".",1)
						# raise
						break
	
		database.append(chaine)						

	print "\n*************************************\n"
	# for i in epg:
	# 	print "\n>> ",i['Channel Name']
	# 	print i['EPG Code']

	for d in database:
		print "========"	
		print (d.title,  d.tvgSmart,  d.tvgIPTV,  d.tvIcon,  d.radio,  d.group,  d.xbmc,  d.calias,  d.state,  d.SiteEPG,  d.site_id,  d.lang)

def GetChannelData(channel):

	tvIcon=""
	group=[]
	alias=[]
	cname=channel.find('cname').text.encode('utf-8')

	try:
		tvIcon=channel.find('imageurl').text.encode('utf-8')
	except:
		# tvIcon=Image.GetImage(cname)
		tvIcon=""

		print "\n", cname
		print tvIcon
		pass

	for calias in channel.findall('calias'):
		if calias.text != None:
			alias.append(calias.text.encode('utf-8'))

	assignedcategory = channel.find('assignedcategory')
	categorys=assignedcategory.findall('category')
	for category in categorys:
		group.append(category.text.encode('utf-8'))


	Chaine={ 
		"Title": cname,
		"xbmc":channel.find('cname').text.encode('utf-8'),
		"calias":alias,
		"group": group,
		"tvIcon":tvIcon,
		"path":"", 
		"tvgSmart":"",
		"tvgIPTV":"", 
		"state":"",
		"SiteEPG":"", 
		"site_id":"",
		"state":"",
		"radio":"FALSE",
		"lang":""
		} 

	# print "\n////", Chaine



	return Chaine

def Json_BD(ChannelDataBase):

	database=[]
	chaine={ 
		"Title": "",
		"xbmc":"",
		"calias":"",
		"group": "",
		"tvIcon":"",
		"trailers":"", 
		"path":"", 
		"tvgSmart":"",
		"tvgIPTV":"", 
		"state":"",
		"SiteEPG":"", 
		"site_id":"",
		"state":"",
		"radio":"FALSE",
		"lang":""
		} 



	rootData = ET.parse(ChannelDataBase, parser=ET.XMLParser(encoding="utf-8" ))
	rootChannels=rootData.find('channels')

	for channel in rootChannels:
		chaine=GetChannelData(channel)
		database.append(chaine)		

	SortedDatabase = sorted(database, key=lambda k: k['Title'], reverse=False) 

	return SortedDatabase 

import os
from urllib2 import urlopen, URLError, HTTPError


def dlfile(url):
    # Open the url
    try:
        f = urlopen(url)
        print "downloading " + url

        # Open our local file for writing
        with open(os.path.basename(url), "wb") as local_file:
            local_file.write(f.read())

    #handle errors
    except HTTPError, e:
        print "HTTP Error:", e.code, url
    except URLError, e:
        print "URL Error:", e.reason, url

def main():
	import MyApi 
	import json
	database=[]

	print ("\n *****start EPG Traitment at: \n"), 

	import urllib2

	starttime=datetime.datetime.now()

	if not os.path.exists(DBJson):
		# Create JSON DB if needed
		database=Json_BD(ChannelDataBase)

		with open(DBJson, 'w') as fout:
			json.dump(database, fout, encoding="utf-8" ,indent=4)
	else:
		with open(DBJson) as data_file:	
			database = json.load(data_file, encoding="utf-8")

	database=UpdateDB_FromIPTVEPG(database)

	with open(DBJson, 'w') as fout:
		json.dump(database, fout, indent=4)


	endtime=datetime.datetime.now()

	# print "*** >>>>>>>>>> end EPG Traitment  in: <<<<<<<<<<<< ** *", endtime-starttime
	


if __name__ == '__main__':
	main()

