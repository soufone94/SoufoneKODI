#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys  

reload(sys)  
sys.setdefaultencoding('utf8')

import lib.globalvar as globalvar
import lib.iptv as iptv

from lib.iptv import Updater
updater = Updater()

import json
import xml.etree.ElementTree as ET

from lib.reset_exclusions import *
from lib.utils import *
from lib.viewer import *

import os
from shutil import copyfile
os.chdir(os.getcwd())

# from lib.MyApi import *
# import lib.MyFile as MyFile
# import lib.iptv as iptv
# # import lib.MyDropbox as MyDropbox

# import json

if not os.path.exists(globalvar.CACHE_DIR):
    os.makedirs(globalvar.CACHE_DIR, mode=0777)



# VODurl  ="https://www.dropbox.com/s/cjb9uc8wgfmp4xf/VOD.m3u?dl=1"

OtmanIPTV="https://www.dropbox.com/s/8bop85mg37i0tex/test.m3u?dl=1"

user=globalvar.ADDON.getSetting('user')
passe=globalvar.ADDON.getSetting('pass')
create_iptv=globalvar.ADDON.getSetting('create_iptv')
create_vod=globalvar.ADDON.getSetting('create_vod')

# OtmanIPTV="http://Electrowazan7.com:7777/get.php?username=%s&password=%s&type=m3u_plus&output=ts"%(user,passe)
OtmanIPTV="http://Electrowazan9.com:80/get.php?username=%s&password=%s&type=m3u_plus&output=ts"%(user,passe)

def Job():
    updater = Updater()
    updater.notify("start ")


    if not os.path.isfile(globalvar.AdvancedXML):          
        copyfile(globalvar.MyAdvanceXML, globalvar.AdvancedXML)



    if create_iptv:
        NewPlaylist=iptv.main(OtmanIPTV,globalvar.PlaylistFile)  

        updater.UpdateSimpleIPTVSettings(globalvar.PlaylistFile)


    if create_vod:
        # if os.path.isfile(globalvar.VODFile):        
        #     copyfile(globalvar.VODFile, globalvar.VODFile+'.back')
            
        updater.UpdateVOD()
        
        updater.UpdateSourceFile(globalvar.SourcesXML, "RemoteFilmAR",globalvar.OutDir+'/films/ar/')
        updater.UpdateSourceFile(globalvar.SourcesXML, "RemoteFilmFR",globalvar.OutDir+'/films/fr/')
        updater.UpdateSourceFile(globalvar.SourcesXML, "RemoteFilmEN",globalvar.OutDir+'/films/en/')

        updater.notify("update lib ")
        xbmc.executebuiltin("xbmc.UpdateLibrary(video)")

    updater.notify("end ")

    return 

if __name__ == "__main__":
    
    Job()





    




