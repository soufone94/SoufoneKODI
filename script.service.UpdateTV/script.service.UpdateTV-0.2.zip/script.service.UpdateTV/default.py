#!/usr/bin/python
# -*- coding: utf-8 -*-
import globalvar

import json
import sys

from reset_exclusions import *
from utils import *
from viewer import *

import os
os.chdir(os.getcwd())

from lib.MyApi import *
import lib.MyFile as MyFile
import lib.iptv as iptv
# import lib.MyDropbox as MyDropbox

# import json

if not os.path.exists(globalvar.CACHE_DIR):
    os.makedirs(globalvar.CACHE_DIR, mode=0777)

OutDir=globalvar.CACHE_DIR
VODFile=os.path.join(globalvar.CACHE_DIR, "vod.m3u")
VODurl  ="https://www.dropbox.com/s/cjb9uc8wgfmp4xf/VOD.m3u?dl=1"

class Updater(object):


    STATUS_SUCCESS = 1
    STATUS_FAILURE = 2
    STATUS_ABORTED = 3  

    progress = xbmcgui.DialogProgress()
    monitor = xbmc.Monitor()
    silent = True
    exit_status = STATUS_SUCCESS

    def __init__(self):
        print "init"
        # debug("{0!s} version {1!s} loaded.".format(ADDON.getAddonInfo("name").decode("utf-8"),
        #                                            ADDON.getAddonInfo("version").decode("utf-8")))




    def notify(self,text):
        time = 3000  #in miliseconds 
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('MyVOD',text, time, os.path.join( globalvar.ADDON_DIR, "icon.png")))

    def CreateIfNotExiste(self,directory):
        if not os.path.exists(directory):
            os.makedirs(directory)


    def CopyVODToLocal(self,VODurl,OutDir):
        
        if sys.platform.startswith('win'):
            # notify("file function with unicodes")
            notify("Win start Copy Remote VOD to ")
        else:
            # notify("file function with utf-8 encoded strings")
            notify("Android start Copy Remote VOD to ")
        notify(OutDir)

        

        import os
        import urllib

        import os.path
        from shutil import copyfile
        import filecmp

        if os.path.isfile(VODFile):
            copyfile(VODFile, VODFile+'.back')

        urllib.urlretrieve (VODurl, VODFile)

        if os.path.isfile(VODFile+'.back'):
            Changed=not(filecmp.cmp(VODFile, VODFile+'.back'))
        else:
            Changed=True

        if Changed==True:

            inf =open(VODFile,'r')  

         
            title=""
            path=""
            for line in inf:
                moviefile=""
                # print "===>>> line",line
                
                try:
                    line=line.strip()
                    if sys.platform.startswith('win'):
                        line=line.decode("utf-8")

                    # print "line", line
                    if line.upper().startswith("HTTP"):
                        path=line
                    elif line and not line.startswith('#EXTM3U'):
                        try: 
                            title = re.search(r'(?<=tvg-id=").*?(?=")', line).group(0).strip()                  
                        except:                    
                            rest,title = line.rsplit(',',1)  

                    # print "\ntitle", title.encode("utf-8")
                    # print "path", path

                    

                    if (title !="") and (path!=""):
                        lang=""
                        moviefile=""
                        # notify(title.encode('utf-8'))
                        # if title.upper().endswith('_FR'):
                        #         title=title.upper().replace("_FR","")
                        #         lang="FR" 
                        # else:
                        #     try:
                        #         print "vod englis: ",title.decode("utf-8")
                        #     except:
                        #         lang="AR" 
                        #         # title=title.decode("utf-8") 

                        # if lang=="AR" or lang=="FR":
                        print "title", title.encode("utf-8")
                        if title.upper().endswith('_FR'):
                            moviefile=OutDir+"/films/fr/"+title.upper().replace("_FR","")+".strm"
                        # elif title.upper().endswith('_AR'):
                        elif "_AR" in title.upper():                            
                            moviefile=OutDir+"/films/ar/"+title.upper().replace("_AR","")+".strm"

                        # print "title",title
                        # print "moviefile", moviefile
                        if moviefile is not "":
                            foo = open(moviefile, 'w')
                            foo.write(path)
                            foo.close()

                            # with open(moviefile,'w') as f:
                            #     f.write(path)
                        title=""
                        path=""
                
                except:
                    # raise
                    pass

            notify("END Copy ")
        else: #not changed 
            notify("No DB update needed ")

        return 



    def Job(self):
        notify("Start updater ... ")

        self.CreateIfNotExiste(OutDir)
        self.CreateIfNotExiste(OutDir+'/films/fr/')
        self.CreateIfNotExiste(OutDir+'/films/ar/')


        self.CopyVODToLocal(VODurl,OutDir)


        notify("END updater ... ")


        return 



if __name__ == "__main__":

    updater = Updater()

    updater.Job()




    




