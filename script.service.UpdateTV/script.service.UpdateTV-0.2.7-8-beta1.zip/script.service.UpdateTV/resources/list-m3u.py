# mon guide: http://bit.ly/2uz3TR1
# mon quide .gz: http://bit.ly/2hFCZ7t

# playlist: http://bit.ly/2qanRlH	#soufone2
# playlist Tiznit: http://bit.ly/2q8T2v1	#soufone ae:a7:0b:71:01:06
# Playlist khattab: http://bit.ly/2qhnKRU	#soufone1 24:4b:03:4c:6f:e4
# playlist unknown: http://bit.ly/2oBSPSu

#bourzi bc:14:85:65:f1:e3

#mac m8: 2c:8a:72:b4:e3:71
#mac bee: 1a:f5:36:66:67:da

#=> plugin.video.live.streamspro:
# http://racacaxtv.ga/allfrtv/allfrtvkodi.php?cat=VG91dGVz&amp;country=France&amp;epg=
# http://tinyurl.com/zzj2bg3

#### TEST ########
# https://www.dropbox.com/s/0a78603iqu43wvv/test.m3u?dl=1
https://www.dropbox.com/s/8bop85mg37i0tex/test.m3u?dl=1
#http://otmanshowiptv.com:7777/get.php?username=soufone2&password=R3px9OfXWs&type=m3u&output=ts 		
