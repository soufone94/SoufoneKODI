# -*- coding: utf-8 -*-

import xml.etree.ElementTree as ET
from MyApi import *
import MyFile, epg
import globalvar

if XBMC==False:
    try:
        import cchardet
    except:
        install("cchardet")
        import cchardet


try:
    import xbmcgui
    import lib.utils as utils
    from reset_exclusions import *
    # from utils import *
    from viewer import *
except:
    pass 

OtmanIPTV="http://Electrowazan7.com:7777/get.php?username=soufone2&password=R3px9OfXWs&type=m3u&output=ts"
TestLink="https://www.dropbox.com/s/6x34j0u2pnkwkin/test.m3u?dl=1"

import sys  



reload(sys)  
sys.setdefaultencoding('utf8')

def IsSerie(string):
    import re

    string=string.upper()
    episode=""
    
    regexEpesode1='([0-9a-zA-Z]?[0-9]X[0-9]?.)'
    regexEpesode2='S[0-9].*EP[0-9].*'
    regexEpesode3='S[0-9].*E[0-9].*'

    try:
        episode=re.findall(regexEpesode1, string)[0]
    except IndexError:
        try:
            # string=string.replace(' ','')
            episode=re.findall(regexEpesode2, string)[0]
        except IndexError:
            try:
                episode=re.findall(regexEpesode3, string)[0]
            except:
                pass
    except:
        episode=""


    return  episode

if XBMC==True:
    class Updater(object):


        STATUS_SUCCESS = 1
        STATUS_FAILURE = 2
        STATUS_ABORTED = 3  

        progress = xbmcgui.DialogProgress()
        monitor = xbmc.Monitor()
        silent = True
        exit_status = STATUS_SUCCESS
        user=globalvar.ADDON.getSetting('user')
        password=globalvar.ADDON.getSetting('pass')

        def __init__(self):
            print "init"
            # debug("{0!s} version {1!s} loaded.".format(ADDON.getAddonInfo("name").decode("utf-8"),
            #                                            ADDON.getAddonInfo("version").decode("utf-8")))


        # def notify(self,text,time = 3000):
        #     # time = 3000  #in miliseconds 
        #     xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('TV Updater',text, time, os.path.join( globalvar.ADDON_DIR, "icon.png")))

        def CreateIfNotExiste(self,directory):
            if not os.path.exists(directory):
                os.makedirs(directory)

        def CopyVODToLocal(self,OutDir):
            
            # if sys.platform.startswith('win'):
            #     # utils.notify("file function with unicodes")
            #     utils.notify("Win start Copy Remote VOD to ")
            # else:
            #     # utils.notify("file function with utf-8 encoded strings")
            #     utils.notify("Android start Copy Remote VOD to ")
            # utils.notify(OutDir)

            

            import os
            import urllib

            import os.path
            import filecmp
            from shutil import copyfile

            

            # urllib.urlretrieve (VODurl, VODFile)

            if os.path.isfile(globalvar.VODFile+'.back'):
                utils.notify("back exist update vod if changed")
                Changed=not(filecmp.cmp(globalvar.VODFile, globalvar.VODFile+'.back'))
            else:
                Changed=True

            if Changed==True:
                utils.notify("changed")

                import glob, os, os.path
                filelist = glob.glob(os.path.join(globalvar.OutDir, u"*/*/*.strm"))       
                for f in filelist:
                    # utils.notify("remove "+f)
                    os.remove(f)

                # inf =open(globalvar.VODFile,'r')  

                VODs=GetM3U_data(globalvar.VODFile)

                for v in VODs:
                    moviefile=""
                    title=""
  
                    if "iptvpro" in v.path:

                        if "FILMS ARABES"==v.group.upper().strip():
                            moviefile=OutDir+"/films/ar/iptvpro/"+v.title.upper()+".strm"

                        elif "FILM" in v.group.upper() or (v.group=="" and IsSerie(v.title)==""): # film
                            try:
                                tmp,title=v.title.split("/")
                            except:
                                title=v.title
                                title=title.replace("AC.","").replace("CM.","").replace("DR.","").replace("EF.","").replace("HR.","").replace("RA.","")

                            moviefile=OutDir+"/films/fr/iptvpro/"+title.upper().replace(".FR","")+".strm"


                        else: #serie
                            if v.group.strip()=="":
                                v.group=v.title.upper().replace(IsSerie(v.title),"")

                            if ("VOLUMffff" in v.title.upper()):                    
                                title=title.replace("_",".").replace(" EP","E")
                                SerDir=OutDir+"/series/iptvpro/"+v.group.strip().upper().strip()
                                self.CreateIfNotExiste(SerDir)
                                moviefile=SerDir+"/"+v.group.upper()+title.upper()+".strm".replace("VOLUME"," ")
                            else:
                                title=v.title.replace(" EP","E").replace("/"," ")
                                SerDir=OutDir+"/series/iptvpro/"+v.group.replace(":"," ")
                                self.CreateIfNotExiste(SerDir)

                            moviefile=SerDir+"/"+title.upper().replace(".FR","")+".strm"

                    else:
                        # utils.notify(v.group.strip())
                        if v.group.strip().upper()=="ARABIC MOVIES":                             
                            title=v.title.decode('utf8').replace("_",".")                         
                            moviefile=OutDir+"/films/ar/electro/"+v.title.upper().replace(".AR","")+".strm"
                        elif v.group.strip().upper()=="FRANCE MOVIES":   
                            title=v.title.replace("_",".")
                            moviefile=OutDir+"/films/fr/electro/"+v.title.upper().replace(".FR","")+".strm"
                        elif v.group.strip().upper()=="ENGLISH MOVIES":   
                            title=v.title.replace("_",".")
                            moviefile=OutDir+"/films/en/electro/"+v.title.upper().replace(".FR","")+".strm"
                  

                    if moviefile is not "":   
                        with open(moviefile,'w') as f: 
                            f.write(v.path)                       



                copyfile(globalvar.VODFile, globalvar.VODFile+'.back')
                utils.notify("END Copy ")
            else: #not changed
                print "TVUpdate: No DB update needed " 
                # utils.notify("No DB update needed ")

            return 

        def UpdateVOD(self):
            # utils.notify("Start updater ... ")



            self.CreateIfNotExiste(globalvar.OutDir)
            self.CreateIfNotExiste(globalvar.OutDir+'/films/fr/electro/')
            self.CreateIfNotExiste(globalvar.OutDir+'/films/fr/iptvpro/')
            self.CreateIfNotExiste(globalvar.OutDir+'/films/ar/electro/')
            self.CreateIfNotExiste(globalvar.OutDir+'/films/ar/iptvpro/')
            self.CreateIfNotExiste(globalvar.OutDir+'/films/en/electro/')
            self.CreateIfNotExiste(globalvar.OutDir+'/films/en/iptvpro/')
            self.CreateIfNotExiste(globalvar.OutDir+'/series/iptvpro/')

            self.CopyVODToLocal(globalvar.OutDir)



            # utils.notify("END updater ... ")


            return 

        def AddSource(self, video,name,path):

            source = ET.SubElement(video, 'source')

            childPath = ET.Element("path", pathversion="1")
            childPath.text=path

            childName = ET.Element("name")
            childName.text=name

            childAllowsharing = ET.Element("allowsharing")
            childAllowsharing.text="true"

            source.append(childName)
            source.append(childPath)
            source.append(childAllowsharing)


            return 

        def UpdateSourceFile(self,sourcespath,name,path):  
            from shutil import copyfile

            AleadyExist=False

            if not os.path.isfile(sourcespath):
                copyfile(sourcesRef,sourcespath)



            sourcesDATA = ET.parse(sourcespath, parser=ET.XMLParser(encoding="utf-8" ))


            rootVideos=sourcesDATA.find('video')

            for source in rootVideos.findall("source"):
                    if source.find('path').text==path:
                        AleadyExist=True

            if AleadyExist==False:
                self.AddSource(rootVideos,name,path)
                sourcesDATA.write(sourcespath)

                utils.notify("src added "+name)                
                # ok = xbmcgui.Dialog().ok("TVUP UpdateSourceFile","Please restart KODI")

            return

        def UpdateSimpleIPTVSettings(self,m3ufile):  
            from shutil import copyfile

            Settingspath = xbmc.translatePath("special://profile/addon_data/pvr.iptvsimple\settings.xml")

            if not os.path.isfile(Settingspath):  
                self.CreateIfNotExiste(xbmc.translatePath("special://profile/addon_data/pvr.iptvsimple/")) 
                copyfile(SettingsRef,Settingspath)


            SettingsDATA = ET.parse(Settingspath, parser=ET.XMLParser(encoding="utf-8" ))


            rootsettings=SettingsDATA.findall('setting')
            change=False
            for s in rootsettings:
                if s.get('id')=="m3uPath" and s.attrib['value']!=m3ufile:
                    s.attrib['value']=m3ufile
                    change=True
                   

                if s.get('id')=="m3uPathType" and s.attrib['value']!="0":
                    s.attrib['value']="0"
                    change=True
                    
                if s.get('id')=="m3uPathType" and s.attrib['value']!="0":
                    s.attrib['value']="0"
                    change=True
                    
                if s.get('id')=="epgPathType" and s.attrib['value']!="1":
                    s.attrib['value']="1"
                    change=True
                    
                if s.get('id')=="epgUrl" and s.attrib['value']!="http://iptv-epg.com/d7d-mq2i3s.xml":
                    s.attrib['value']="http://iptv-epg.com/d7d-mq2i3s.xml"
                    change=True


            if change==True:
                ok = xbmcgui.Dialog().ok("TVUP UpdateSimpleIPTVSettings","Please restart KODI")
                SettingsDATA.write(Settingspath)

            return

        def clean_all(self):
            """
            Clean up any watched videos in the Kodi library, satisfying any conditions set via the addon settings.

            :rtype: (str, int)
            :return: A single-line (localized) summary of the cleaning results to be used for a notification, plus a status.
            """
            debug("Starting cleaning routine.")

            if get_setting(clean_when_idle) and xbmc.Player().isPlaying():

                debug("Kodi is currently playing a file. Skipping cleaning.", LOGWARNING)
                return None, self.exit_status

            results = {}
            cleaning_results, cleaned_files = [], []
            if not get_setting(clean_when_low_disk_space) or (get_setting(clean_when_low_disk_space) and disk_space_low()):
                if not self.silent:
                    self.progress.create(ADDON_NAME, *map(translate, (32619, 32615, 32615)))
                    self.progress.update(0)
                    self.monitor.waitForAbort(2)
                for video_type in [self.MOVIES, self.MUSIC_VIDEOS, self.TVSHOWS]:
                    if not self.__is_canceled():
                        cleaned_files, count, status = self.clean(video_type)
                        if count > 0:
                            cleaning_results.extend(cleaned_files)
                            results[video_type] = count
                if not self.silent:
                    self.progress.close()

            # Check if we need to perform any post-cleaning operations
            if cleaning_results:
                # Write cleaned file names to the log
                Log().prepend(cleaning_results)

                # Finally clean the library to account for any deleted videos.
                if get_setting(clean_kodi_library):
                    self.monitor.waitForAbort(2)  # Sleep 2 seconds to make sure file I/O is done.

                    if xbmc.getCondVisibility("Library.IsScanningVideo"):
                        debug("The video library is being updated. Skipping library cleanup.", LOGWARNING)
                    else:
                        xbmc.executebuiltin("XBMC.CleanLibrary(video, false)")

            return self.summarize(results), self.exit_status


class IPTV():
    def __init__(self, title,tvg,tvg_shift,tvIcon,radio,group,xbmc, path,calias,state,SiteEPG,site_id,lang,favorite):
        self.title = title
        self.tvg = tvg
        self.tvg_shift = tvg_shift
        self.tvIcon = tvIcon
        self.radio = radio
        self.group = group
        self.xbmc = xbmc
        self.path = path
        self.calias = calias
        self.state = state        
        self.SiteEPG = SiteEPG
        self.site_id = site_id
        self.lang = lang
        self.favorite = favorite

if XBMC==True:
    updater = Updater()

    from lib.utils import Log
    log = Log()

def DownloadFile(OtmanIPTV , OtmanIPTVfile):
    import time, urllib
    import cfscrape

    scraper = cfscrape.create_scraper()  # returns a CloudflareScraper instance
    # Or: scraper = cfscrape.CloudflareScraper()  # CloudflareScraper inherits from requests.Session
    Cleanplaylist=scraper.get(OtmanIPTV).content  # => "<!DOCTYPE html><html><head>..."

    f = open(OtmanIPTVfile, "w")
    f.write(Cleanplaylist.strip())
    f.close()

    return


def getKey(IPTV):
    #filter by group
    return IPTV.group

def getKeyTvg(IPTV):
    #filter by tvgname
    return IPTV.tvg
    # return IPTV.tvg

def CreateUsersPlaylist(patern,users):


    for user in users:
        PlaylistUser=PlaylistFile.replace(".m3u","_"+user+".m3u")  

        infile = open(PlaylistFile).read()
        out = open(PlaylistUser, 'w')
        infile = infile.replace(patern[0], users[user][0])
        infile = infile.replace(patern[1], users[user][1])
        out.write(infile)
        out.close
    return

def RenameChannelName(IPTV):
    # print "\n > RenameChannelName: ",IPTV.xbmc
    # print "*",IPTV.title,  MyFile.purge(IPTV.title,IPTV.lang)
    
    IPTV.xbmc=IPTV.xbmc.upper().replace("|"+IPTV.lang.upper()+"|","")

    if IPTV.title.upper().replace("|"+IPTV.lang.upper()+"|","").startswith("MY"):
        IPTV.xbmc=IPTV.xbmc +" (MY)"
    # try:
    #     IPTV.xbmc=IPTV.xbmc.encode('utf8').replace("|"+IPTV.lang.upper()+"|","")
    # except:
    #     IPTV.xbmc=IPTV.xbmc.decode('cp1252').replace("|"+IPTV.lang.upper()+"|","")


    if ("/UDP/" in IPTV.path.upper()):
        IPTV.xbmc = "[COLOR red] " + IPTV.xbmc + " [/COLOR]" + " UDP"



    if IPTV.title.upper().startswith("VIP-"):
        IPTV.xbmc = IPTV.xbmc + " VIP"
    if "*4k*6MB" in IPTV.title.upper():
        IPTV.xbmc = IPTV.xbmc + " 4K"
    if ("HD" in IPTV.title.upper()) and ("HD" not in IPTV.xbmc.upper()) :
        IPTV.xbmc = IPTV.xbmc + " HD"

    if ("SD" in IPTV.title.upper()) and ("SD" not in IPTV.xbmc.upper()) :
        IPTV.xbmc = IPTV.xbmc + " SD"
    if IPTV.title.upper().endswith("-low"):
        IPTV.xbmc = IPTV.xbmc + " LOW"

    if IPTV.title.upper().endswith(" 1H"):
        IPTV.xbmc = IPTV.xbmc.replace(" 1H","") + " 1H"
    if IPTV.title.upper().endswith(" 2H"):
        IPTV.xbmc = IPTV.xbmc.replace(" 2H","")  + " 2H"
    if IPTV.title.upper().endswith(" 3H"):
        IPTV.xbmc = IPTV.xbmc.replace(" 3H","")  + " 3H"
    if IPTV.title.upper().endswith(" 6H"):
        IPTV.xbmc = IPTV.xbmc.replace(" 6H","")  + " 6H"

    if IPTV.title.upper().strip()=="1": #Patch for HD 1
        IPTV.xbmc = "HD 1"


    # all stream not in otmanshowiptv playlist
    if not IPTV.path.upper().startswith("HTTP://ELECTROWAZAN"):
        IPTV.xbmc="[COLOR green] "+IPTV.xbmc+" [/COLOR]"

    # print " < RenameChannelName: ",IPTV.xbmc
    return IPTV

def RenameGroup(IPTV,favorite):
    # print "RenameGroup",(IPTV.group,lang)
    lang=IPTV.lang.upper()
    debug("RenameGroup "+(IPTV.group+" "+lang), LOGWARNING)

    
    # IPTV.group=IPTV.group.replace(" AR","").replace(" FR","").replace(" CA","")

    IPTV.group=IPTV.group.encode('utf8')


    if "MBC" in IPTV.title.upper():
        IPTV.group = "2-MBC GROUP"
    elif "ROTANA" in IPTV.title.upper():
        IPTV.group = "2-ARABIC"
    elif "MAROC" in IPTV.title.upper() or "MAROC" in IPTV.group.upper():
        IPTV.group = "1-MAROC"
        IPTV.title=IPTV.title.upper().replace(".MAROC","")

    elif ("BEIN SPORTS" in IPTV.title.upper()):
        IPTV.group = "SPORTS BEIN" + " "+ lang

    elif ("BEIN" in IPTV.title.upper()):
        IPTV.group = "6-BEIN GROUP"

    elif ("SFR SPORT" in IPTV.xbmc.upper() or "CANAL+ SPORT" in IPTV.xbmc.upper() or ("SPORT" in IPTV.xbmc.upper())):
        if IsFavoriteLang(lang):
            IPTV.group="5-SPORTS" + " "+ lang
        else:
            IPTV.group="ZE SPORTS" + " "+ lang

    elif ("MOVIE" in IPTV.title.upper()):
        IPTV.group = "MOVIES" + " "+ lang

    elif ("ON-DEMAND" in IPTV.title.upper()):
        IPTV.group = "ON-DEMAND"  + " "+ lang           
        IPTV.title = IPTV.title.upper().replace("-"," ")

    elif "OSN" in IPTV.title.upper().strip():
        IPTV.group="OSN GROUP"      

    elif "CANALPLAY" in IPTV.title.upper().strip():
        IPTV.group="CANALPLAY/VOD"  + " "+ lang
        IPTV.tvIcon="https://pbs.twimg.com/profile_images/672405725491122178/kQLz1EsE_400x400.jpg"
        IPTV.tvg=IPTV.title.replace("-","").replace("fr","").replace("vip","")
        if IPTV.title.upper().startswith("VIP-"):
            IPTV.xbmc = "[COLOR green] " + IPTV.tvg + " [/COLOR]"
        else:
            IPTV.xbmc = IPTV.tvg

    elif "MEGA-BOX" in IPTV.title.upper().strip():
        IPTV.group="CANALPLAY/VOD"  + " "+ lang
        IPTV.tvIcon="http://megaboxhdapp.com/wp-content/uploads/2015/08/Megabox-HD-Icon.png"
        IPTV.tvg=IPTV.title.replace("-"," ").replace("fr","")
        IPTV.xbmc = IPTV.tvg

    if ("A LA CARTE" in IPTV.xbmc.upper()) :
        IPTV.group="CANALPLAY/VOD" + " "+ lang

    if ("MBC" in IPTV.xbmc.upper()) and ("ZE UNKNOWN" in IPTV.group):
        IPTV.group="2-ARABIC" 


    if ("musi" in IPTV.group.lower()) or ("MUSIC" in IPTV.xbmc.upper()) or ("MUSIQ" in IPTV.xbmc.upper()):
        IPTV.group="MUSIC" + " "+ lang

    if ("jeunesse" in IPTV.group.lower()):
        IPTV.group="KIDS"  + " "+ lang    

    if ("new" == IPTV.group.lower()) or ("info" in IPTV.group.lower()):
        IPTV.group="4-NEWS"  + " "+ lang   

    if ("adulte" in IPTV.group.lower()):
        IPTV.group="ze unknown" 
    if IPTV.group  == '':
       IPTV.group = "ze unknown"

    if (("|AR|"  in IPTV.group.upper()) or ("|FR|" in IPTV.group.upper())  ):
        if ( not  IPTV.group.upper().startswith("4-")):
            IPTV.group="4-"+IPTV.group



    # print "IPTV.group",IPTV.group
    return IPTV

def OpenFile(M3UPlaylist):
    inf="can't open file" 

    if os.path.isfile(M3UPlaylist):
        inf = open(M3UPlaylist,'r')
    else:
        try:
            path, filename = os.path.split(M3UPlaylist)
            try:                
                filename = filename.upper().replace(" ","").replace("?","").replace("!","").replace(".M3U","") + ".m3u"
                urllib.urlretrieve(M3UPlaylist , OutStreamDir+filename)
                inf = open(OutStreamDir+filename,'r')
                print "file name ",filename
            except:   
                raise         
                urllib.urlretrieve(M3UPlaylist , "M3UPlaylist.m3u.tmp")
                inf = open("M3UPlaylist.m3u.tmp",'r')

            
        except IOError as e:
            print "ERROR: M3UPlaylist: get file I/O error({0}): {1}".format(e.errno, e.strerror)
            #logger.info("ERROR: M3UPlaylist: get file : I/O error({0}): {1}".format(e.errno, e.strerror))
            return inf

    return inf

def GetM3U_data(M3UPlaylist):
    import re
    # print ("start GetM3U_data: playlist: ",M3UPlaylist)
    #logger.info("start GetM3U_data:  playlist: %s ", M3UPlaylist)

    # initialize playlist variables before reading file
    playlist=[]
    if not os.path.exists(OutStreamDir):
                os.makedirs(OutStreamDir)

    inf = OpenFile(M3UPlaylist)

    #title,tvg,tvIcon,radio,group, xbmc, path)
    song=IPTV(None,None,None,None,None,None,None,None,None,None,None,None,None,None)

    for line in inf:
        # print "===>>> line",line
        
        line=line.strip()
        if line and not line.startswith('#EXTM3U'):
            lang=""
            tvg_shift=""
            
            ##EXTINF:-1 tvg-id="2M" tvg-name="2M" tvg-logo="2M.png" group-title="Maroc"2M
            if line.startswith('#EXTINF:'):
                # print "line:", line

            
                # line = str(line.strip())            
                line=MyFile.supprime_accent(line)
                try: 
                    title = re.search(r'(?<=tvg-id=").*?(?=")', line).group(0).strip()                  
                except:
                    
                    try:
                        rest,title = line.rsplit(',',1)  
                        lang,cname = title.rsplit(':',1) 
                        lang=lang.upper().strip()
                        

                        #title = re.search(r'(?<=tvg-id=").*?(?=")', line).group(0)              
                    except:
                        # raise
                        try:                                  
                            rest,title = line.rsplit(',',1)
                        except:
                            try:
                                rest,title = line.rsplit('#EXTINF:-1',1)
                            except:
                                title=line.replace("#extinf:-1",'').split()
           
                

                try: 
                    tvg = re.search(r'(?<=tvg-name=").*?(?=")', line).group(0).strip()                  
                except:
                    tvg =''
                try: 
                    tvIcon = re.search(r'(?<=tvg-logo=").*?(?=")', line).group(0).strip()   
                except:
                    tvIcon =''
                
              
                try: 
                    radio = re.search(r'(?<=radio=").*?(?=")', line).group(0).strip()   
                except:
                    radio =''
                
                try: 
                    group = re.search(r'(?<=group-title=").*?(?=")', line).group(0).strip()   
                except:
                    group =''

                xbmc=title.replace("HD","").strip().upper().strip()   

                if "audio-track" in line.lower():                
                    try: 
                        lang = re.search(r'(?<=audio-track=").*?(?=")', line).group(0).strip()   
                    except:
                        lang =''  
                else:            
                    try:
                        print title
                        lang,tmp = title.rsplit(':',1) 
                        lang=lang.upper().strip()
                        if lang=="":
                            lang="AR"
                    except:
                        lang="AR"
                        pass
            
                song=IPTV(title.decode("utf-8"),tvg,tvg_shift,tvIcon,radio,group.upper(),xbmc,None,None,None,None,None,lang,None)
                
            else:
                song.path=line
                playlist.append(song)
                # reset the song variable so it doesn't use the same EXTINF more than once
                song=IPTV(None,None,None,None,None,None,None,None,None,None,None,None,None,None)

    inf.close()

    # for IPTVT in playlist:
    #     print (IPTVT.title, IPTVT.lang, IPTVT.xbmc, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path)

        # self.title = title
        # self.tvg = tvg
        # self.tvIcon = tvIcon
        # self.radio = radio
        # self.group = group
        # self.xbmc = xbmc
        # self.path = path
        # self.calias = calias
        # self.state = state        
        # self.SiteEPG = SiteEPG
        # self.site_id = site_id
        # self.lang = lang
      
    return playlist

def IsFavoriteLang(lang):
    # print "IsFavoriteLang",(lang)

    if lang=="AR" or lang=="FR" or lang=="" or lang=="MYHD" or lang=="BEIN":
        return True


    return False

def IsFavorite(IPTV):
    
    if IsFavoriteLang(IPTV.lang) or "SPORT" in IPTV.title.upper() or "MUSIC" in IPTV.title.upper() or "BEIN" in IPTV.title.upper():
        return True

    return False

def GeneratePlaylistOutputs(Playlist,PlaylistFile,sort=True):
    # print ">>>>> start MiseEnForme", PlaylistFile,
    # updater.utils.notify("GeneratePlaylistOutputs")
    import operator 
         

    # 
    if sort==True:
        PlaylistForma = sorted(Playlist, key=getKeyTvg)
        PlaylistForma = sorted(PlaylistForma, key=getKey)
    else:
        PlaylistForma=Playlist

 
    Cleanplaylist = ''
    CleanplaylistUnkn = ''
    EpgXml =''
    EpgXmlMissing=""
    global_header = "#EXTM3U\n"

    Cleanplaylist += global_header
    CleanplaylistUnkn += global_header
    

    DupLess = []
    DupLessPath = []
    DupLessEPG = []
    for IPTVT in PlaylistForma:
        # print "IPTV",(IPTVT.title, IPTVT.tvg, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path, IPTVT.SiteEPG, IPTVT.lang)
          
        if IPTVT.path not in DupLessPath:
            DupLessPath.append(IPTVT.path)
            # print "GeneratePlaylistOutputs: IPTV",(IPTVT.title, IPTVT.group, IPTVT.tvg)
            try:
                try:
                    # IPTVT.tvg=IPTVT.tvg.encode('utf-8')
                    print "\nIPTVT", IPTVT.title, IPTVT.xbmc, IPTVT.group, IPTVT.tvg, IPTVT.tvg_shift         
                except:
                    # print "\n****PTVT.tvg", IPTVT.tvg.encode('utf-8')
                    # raise
                    IPTVT.tvg=IPTVT.title
                    pass
        

                channel_header = '#EXTINF:-1 tvg-id="%s" tvg-name="%s" tvg-shift="%s" "audio-track="%s"  tvg-logo="%s" radio="%s"  group-title="%s",%s\n' \
                        % (IPTVT.title, IPTVT.tvg, IPTVT.tvg_shift, IPTVT.lang, IPTVT.tvIcon, IPTVT.radio, IPTVT.group.upper() , IPTVT.xbmc)
                # print channel_header

                Cleanplaylist += channel_header
                Cleanplaylist += IPTVT.path + '\n'+'\n'
            except UnicodeDecodeError as err:
                print "\n*************** error: ",err, "\n", IPTVT.path                
                pass
            except:
                raise

              
    f = open(PlaylistFile, "w")
    f.write(Cleanplaylist)
    f.close()

        
    return

def UpdateChannel(IPTV,Jsondatabase):
    # utils.notify(IPTV.title)
    IPTVFound = 0
    favorite = False
    IPTV.tvg_shift=''
    group = ""
    radio = ""

    if ("/movie/" not in IPTV.path.lower()):

        
        if IPTV.group=="FRANCE" or ("|FR|" in IPTV.group):
            IPTV.lang="FR"
            IPTV.favorite=True

        elif ("|AR|" in IPTV.group.upper().strip()) or (IPTV.group=="TIME SHEFT") or (IPTV.group.upper()=="MBC GROUP") or  (IPTV.group.upper()=="ROTANA") or  (IPTV.group.upper()=="ART")  or  (IPTV.group.upper()=="DRAMA") :
            IPTV.lang="AR"
            IPTV.favorite=True


        if  IPTV.favorite==True:             
            IPTVFound = 0  
            # updater.##utils.notify(IPTV.title,100)

            for chaine in Jsondatabase:
                # print 'chaine["tvgIPTV"]', chaine["tvgIPTV"]
                # print "====================="
                # print "*", MyFile.purge(IPTV.title,IPTV.lang)
                for i in chaine["calias"]:   
                    ###utils.notify("=====================",100)                                   
                    ##utils.notify(MyFile.purge(i.encode('utf-8'),""))       
                    # print " >>> ", MyFile.purge(i.encode('utf-8'),"")      
                    if MyFile.purge(IPTV.title,IPTV.lang)==MyFile.purge(i.encode('utf-8'),""):
                        ##utils.notify("********",100)      
                        ##utils.notify(MyFile.purge(IPTV.title,IPTV.lang))  
                 

                        
                        IPTVFound=True
                        break
                if IPTVFound == 1: 
                    # print '** chaine["tvgIPTV"]', chaine["tvgIPTV"].encode('utf-8')

                    IPTV.xbmc=chaine["Title"]
                    IPTV.group = chaine["group"][0]
                    if (IPTV.tvIcon=="") or ("p_313wa33n1" in IPTV.tvIcon):
                        IPTV.tvIcon = chaine["tvIcon"] 
                    if chaine["tvgIPTV"] != "":
                        IPTV.tvg=chaine["tvgIPTV"]
                    else:
                        IPTV.tvg=IPTV.title
                    break

                if IPTVFound == 0:
                    # print "not found", 
                    IPTV.xbmc= IPTV.xbmc.strip()
                    IPTV.group==IPTV.lang.upper()   


            if IPTV.radio == '':
                if radio == 'RADIO':
                    IPTV.radio = "true"
                else:
                    IPTV.radio = "false"

            if IPTV.xbmc.endswith(' 1H'):                            
                IPTV.tvg_shift='-1'
            elif IPTV.xbmc.endswith(' 3H'):
                IPTV.tvg_shift='-3'
            elif IPTV.xbmc.endswith(' 6H'):
                IPTV.tvg_shift='-6'

        # else:
        #     print "not fav", IPTV.title, IPTV.group


        if IPTV.xbmc.endswith(' 1H'):                            
            IPTV.tvg_shift='-1'
        elif IPTV.xbmc.endswith(' 3H'):
            IPTV.tvg_shift='-3'
        elif IPTV.xbmc.endswith(' 6H'):
            IPTV.tvg_shift='-6'

        # print "already exist with data: ", IPTV.title
        # add defintion indication to channel name
        IPTV=RenameChannelName(IPTV)
        IPTV=RenameGroup(IPTV,favorite)  

    # else:
    #     # print IPTV.title, "is a VOD"
    #     break 
        

    return IPTV

def ParseDataBase(DBJson,playlist):

    # print "\n >>>>>>>>>>>> start ParseDataBase ... <<<<", datetime.datetime.now().time()

    utils.notify(" ParseDataBase ")
    import json
    IPTVFound = 0



    playlistTrie = ''
    Cleanplaylist = ''
    CleanplaylistUnkn = ''
    CleanplaylistKO = ''

    IPTV_DATA = []
    IPTV_DATAKO = []
    IPTV_UNKNOWN = []


    # 'name':("logo",'other')
    VODDB={}

    with open(DBJson) as data_file: 
        Jsondatabase = json.load(data_file,encoding="utf-8" )


    DupLessPath = []
    for IPTV in playlist:
        # utils.notify(IPTV.title)

        if IPTV.title != None: #Title not empty
            imageurl = ""  
            # print "IPTV.title", IPTV.title, MyFile.purge(IPTV.title,'') 
            IPTV.path=IPTV.path.replace("|User-Agent=Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/48.0.2564.116 Chrome/48.0.2564.116 Safari/537.36","")
        
            # print "\nTitle= ",IPTV.title ,"lang= ", IPTV.lang, "Isfavorite= ", IsFavoriteLang(IPTV.lang) 
            favorite=IsFavorite(IPTV)
            if (IPTV.path not in DupLessPath) and (favorite or IPTV.group!=""):  # first occurence   
                try:
                    IPTV.title=IPTV.title.encode('utf8')

                    DupLessPath.append(IPTV.path)
                    IPTV=UpdateChannel(IPTV,Jsondatabase)
                    IPTV_DATA.append(IPTV)
                except:
                    pass


            else:
                IPTV=RenameGroup(IPTV,favorite)   
                IPTV_DATAKO.append(IPTV)
            



    return IPTV_DATA, IPTV_DATAKO

def updateVODPrefix(OtmanIPTVfile):

    line_firstfr=""
    line_lastfr=""
    changedfile=""

    inf = open(OtmanIPTVfile,'r')

    for line in inf:
        # print line
        if line.strip().upper().endswith('_FR') and line_firstfr=="":
            line_firstfr=line
        if line.strip().upper().endswith('_FR'):
            line_lastfr=line

    change=False
    inf = open(OtmanIPTVfile,'r')
    for line in inf:
        if line==line_firstfr:
            change=True
            
        if line==line_lastfr:
            change=False
        if change==True and line.strip().upper().endswith('_FR')==False and line.strip().upper().endswith('.MP4')==False:
            line=line.strip()+"_FR"
            # raise
        changedfile += line+ '\n'



    print "first FR", line_firstfr
    print "Last FR", line_lastfr

    f = open(OtmanIPTVfile, "w")
    f.write(changedfile)
    f.close()

   
    return

def GetLinkFromFile(url):
    import re, os , urllib
    inf="can't open file" 
    link=""

    path, filename = os.path.split(url)
             
        
    filename = re.sub('[^0-9a-zA-Z]+', '_', filename)
    urllib.urlretrieve(url , TmpDir+filename)
    inf = open(TmpDir+filename,'r')
    # print "file name ",filename
    for line in inf:
        line=line.strip()
        if not line.startswith('#') and line:
            # print " not started with # ", line
            link=line             
    inf.close()    
    return link

def GetRemotePlaylist(link):
    import re, os,filecmp    
    from shutil import copyfile
    # utils.notify(str(link))

    playlist=[]
    Changed=False

    path, filename = os.path.split(link)
    filename = re.sub('[^0-9a-zA-Z]+', '_', filename)
    linkfile=TmpDir+filename+".m3u"
    linkfileOld=linkfile+".old"

    DownloadFile(link , linkfile)


    if os.path.isfile(linkfileOld):
        Changed=not(filecmp.cmp(linkfile, linkfileOld))
    else:
        Changed=True

    if Changed==True:
        copyfile(linkfile, linkfileOld)
        utils.notify("changed "+filename)
        playlist += GetM3U_data(linkfile)

    return playlist, Changed

def UpdatePlayList(actualPlaylistFile,Reset=False):
    import re, urllib, time
    import os.path

    #tmp variable
    listelec=[]
    listpro=[]
    listtest=[]

    changedelec=False
    changedpro=False
    changed=False
    changedtest=False

    actualPlaylist=[]
    OtmanIPTVPlaylist=[]
    NewPlaylist=[]
    VOD=[]

    if not Reset and os.path.isfile(actualPlaylistFile):
        utils.notify("update Playlist only changes")
        actualPlaylist += GetM3U_data(actualPlaylistFile)


    if XBMC==True:
        if globalvar.ADDON.getSetting('electrowazan9').upper()=="TRUE":
            WazanUser=globalvar.ADDON.getSetting('WazanUser')
            WazanPass=globalvar.ADDON.getSetting('WazanPass')
            utils.notify(str(WazanUser))

            link="http://Electrowazan9.com:80/get.php?username=%s&password=%s&type=m3u_plus&output=ts"%(WazanUser,WazanPass)
            listelec,changedelec =GetRemotePlaylist(link)
            OtmanIPTVPlaylist += listelec

        if globalvar.ADDON.getSetting('iptvpro').upper()=="TRUE":
            IptvproUser=globalvar.ADDON.getSetting('IptvproUser')
            IptvproPass=globalvar.ADDON.getSetting('IptvproPass')

            utils.notify(str(IptvproUser))

            link="http://iptvpro.premium-itv.com:8789/get.php?username=%s&password=%s&type=m3u_plus&output=ts"%(IptvproUser,IptvproPass)
            listpro,changedpro=GetRemotePlaylist(link)
            OtmanIPTVPlaylist += listpro


        if globalvar.ADDON.getSetting('test').upper()=="TRUE":
            # url="https://www.dropbox.com/s/8bop85mg37i0tex/test.m3u?dl=1"
            url="https://www.dropbox.com/s/7ep0xdc1jenvlf5/UPDATETV-Test.txt?dl=1"
            # url=TestLink
            link=GetLinkFromFile(url)
            # link="https://www.dropbox.com/s/6x34j0u2pnkwkin/test.m3u?dl=1"
            listtest,changedtest=GetRemotePlaylist(link)
            OtmanIPTVPlaylist += listtest

        if changedtest or changedpro or changedelec:
            changed=True

    else:
        link=OtmanIPTV
        listtest,changed= GetRemotePlaylist(link)
        OtmanIPTVPlaylist +=listtest


    


    for IPTVo in OtmanIPTVPlaylist:
        # print "IPTVo",IPTVo.title
        exist=False
        if "/movie/" in IPTVo.path:
            # print "movie IPTVo.title", IPTVo.title
            VOD.append(IPTVo)
            # break 
        else:
            for IPTVa in actualPlaylist:
                if IPTVa.path==IPTVo.path:
                    exist=True
                    NewPlaylist.append(IPTVa)
            if exist==False:
                # print ">>> New:" ,IPTVo.title
                NewPlaylist.append(IPTVo)


    return NewPlaylist, VOD, changed

def main(PlaylistFile,Reset=False,create_iptv="true",create_vod="true"):
    import MyApi 
    # print ("\n *****start M3U Playlist creating at: "), 
    starttime=datetime.datetime.now()

    IPTV_DATA=[] 
    IPTV_DATAKO=[]
    IptvUpdater=False
    

    # CopyVODToOut(VODFile)


    NewPlaylist, VOD, IptvUpdater=UpdatePlayList(PlaylistFile,Reset)


    if create_iptv=="true" and IptvUpdater==True:
        epg.main()

        IPTV_DATA, IPTV_DATAKO=ParseDataBase(DBJson,NewPlaylist)
               
        GeneratePlaylistOutputs(IPTV_DATA,PlaylistFileTmp+".ok")     
        shutil.move(PlaylistFileTmp+".ok",PlaylistFile)
        GeneratePlaylistOutputs(IPTV_DATAKO,PlaylistFileTmp+".ko")     
        shutil.move(PlaylistFileTmp+".ko",PlaylistFileUnknown)
    else:
        utils.notify(" IPTV not updated ")
        


    if create_vod=="true" and IptvUpdater==True:
        GeneratePlaylistOutputs(VOD,PlaylistFileTmp)     
        shutil.move(PlaylistFileTmp,globalvar.VODFile)

 
    endtime=datetime.datetime.now()

    # print "*** >>>>>>>>>> end M3U Playlist creating in: <<<<<<<<<<<< ** *", endtime-starttime
    return IPTV_DATA, IPTV_DATAKO,IptvUpdater


if __name__ == '__main__':
    main(OtmanIPTV,PlaylistFile)

