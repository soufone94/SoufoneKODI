# -*- coding: utf-8 -*-
try:
	import xbmc
	from globalvar_xbmc import *
except:
	from globalvar_pc import *

