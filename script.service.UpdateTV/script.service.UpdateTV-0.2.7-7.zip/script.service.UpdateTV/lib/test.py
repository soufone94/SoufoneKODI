# -*- coding: utf-8 -*-

def DownloadFile(OtmanIPTV , OtmanIPTVfile):
    import time, urllib
    import cfscrape

    scraper = cfscrape.create_scraper()  # returns a CloudflareScraper instance
    # Or: scraper = cfscrape.CloudflareScraper()  # CloudflareScraper inherits from requests.Session
    Cleanplaylist=scraper.get(OtmanIPTV).content  # => "<!DOCTYPE html><html><head>..."

    f = open(OtmanIPTVfile, "w")
    f.write(Cleanplaylist.strip())
    f.close()


    # try: # some connection issue
    #     urllib.urlretrieve(OtmanIPTV , OtmanIPTVfile)
    # except:
    #     # print "\nconnection issue, retray in 2S ... "
    #     time.sleep(2)
    #     urllib.urlretrieve(OtmanIPTV , OtmanIPTVfile)
        
    return 

OtmanIPTV="http://electrowazan9.com:80/get.php?username=soufone2&password=R3px9OfXWs&type=m3u_plus&output=ts"
OtmanIPTVfile="c:\Users\soufian\AppData\Roaming\Kodi\cache/tmp.m3u"
import datetime

def RemoveTypeFromFilm(group,title):
    import re

    pattern=''
    consonants = "bcdfghjklmnpqrstvwxyz".upper()

    group=group.upper().replace('FILMS','').strip().replace("ANIMATION","EF")

    if len(group.split())>1:
        
        for i in group.upper().split():
            pattern += i[0]        
    else:
        count = 0
        for x in group:
            if count==0:
                count += 1
                pattern+=x
            else:
                if count >0:
                    if x in consonants:
                        count += 1
                        pattern+=x
                    if count==2:
                        break     
   

    print "pattern", pattern
    title=title.upper().replace(pattern.upper()+".","").strip()


    return title



# group-title="FILMS ACTION",AC. Free State of Jones (2016)
# group-title="FILMS COMEDIE",CM. Belles familles (2015)
# group-title="FILMS DRAME",DR. Jeune & Jolie (2013)
# group-title="FILMS ANIMATION",EF. Avril et le monde truqué (2015)
# group-title="FILMS HORREUR",HR.Animal (2014)

group="FILMS RÉCEMMENT AJOUTÉS"
title="ra.The.Veil.2017"


group="FILMS ANIMATION"
title="EF. Free State of Jones (2016)"

print RemoveTypeFromFilm(group,title)
