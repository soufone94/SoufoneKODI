# -*- coding: utf-8 -*-
import os
os.chdir(os.getcwd())


from lib.globalvar import *
import lib.m3u as M3U
import lib.utils_pc as utils
import lib.MyFile as MyFile

def Job():

	# create needed directory 
	MyFile.CreateOutputs(workspace)

	NewIPTV,OldIPTV,NeedUpdate=M3U.main(Reset=True,create_iptv="true",create_vod="true")

	if TEST==True:
		if (OldIPTV)<20:
			utils.notify("\n\nOld:")
			for IPTVT in OldIPTV:
				utils.notify(IPTVT.title, IPTVT.new, IPTVT.lang, IPTVT.xbmc, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path)

		if (NewIPTV)<20:
			utils.notify("\nNewIPTV:")
			for IPTVT in NewIPTV:
				utils.notify(IPTVT.title, IPTVT.new, IPTVT.lang, IPTVT.xbmc, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path)
			

	utils.notify ("END")
	#clean older files
	return 

if __name__ == "__main__":

    # if len(sys.argv) > 1 and sys.argv[1] == "purgeM3U":        
    #     purge.PurgeM3U()
    # elif len(sys.argv) > 1 and sys.argv[1] == "purgeVOD":        
    #     purge.PurgeVOD()
    # elif len(sys.argv) > 1 and sys.argv[1] == "PurgeOutputs":        
    #     purge.PurgeOutputs()

    # else:    
    #     Job()
    Job()


