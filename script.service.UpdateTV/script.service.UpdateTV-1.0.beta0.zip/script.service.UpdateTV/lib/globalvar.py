# -*- coding: utf-8 -*-


TEST=False
ForceChanged=True
DEBUGLEVEL="LOGDEBUG"
# DEBUGLEVEL="ERROR"
OutDebug=False

try:
	import xbmc
	XBMC=True
	from globalvar_xbmc import *
except:
	from globalvar_pc import *
	XBMC=False
	TEST=True


if XBMC==True:
    if ADDON.getSetting('iptvpro').upper()=="TRUE":
        IptvproUser=ADDON.getSetting('IptvproUser')
        IptvproPass=ADDON.getSetting('IptvproPass')

    if ADDON.getSetting('test').upper()=="TRUE":
        TEST=True
    else:
    	TEST=False

if TEST==True:
	iptvproLink="https://www.dropbox.com/s/lyg2kobn62mk9k4/LinkIptvpro.m3u?dl=1"
else:
	iptvproLink="http://iptvpro.premium-itv.com:8789/get.php?username=%s&password=%s&type=m3u_plus&output=ts"%(IptvproUser,IptvproPass)

print "TEST", TEST
print "iptvproLink", iptvproLink

resources = workspace+'/resources'

OutStreamDir = output + '/streams/'
logs = output + '/logs/'
OutPlaylist = output + '/playlist.m3u'
OutVOD = output + '/VOD.m3u'
DBJson = resources + "/MyChannels.json"

print "workspace",workspace
print "output", output
print "TmpDir", TmpDir