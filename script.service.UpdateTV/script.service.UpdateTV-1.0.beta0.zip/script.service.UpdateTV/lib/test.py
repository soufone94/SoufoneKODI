# -*- coding: utf-8 -*-

import xml.etree.ElementTree as ET
# import globalvar
import os, urllib

string="MY MBC1 HD"
cname="MBC1"

