# -*- coding: utf-8 -*-

from MyApi import *

#Create output directories
def CreateOutputs(workspace):
    # workspace="c:\Users\soufi_000\Dropbox\Public\XBMC\LIVE_TV/"
    # print "> CreateOutputs", workspace

    CreateIfNotExiste(output)
    CreateIfNotExiste(logos)
    CreateIfNotExiste(logs)
    CreateIfNotExiste(OutStreamDir)
    CreateIfNotExiste(outputXMLTV)
    CreateIfNotExiste(localSiteIni_tmp)
    CreateIfNotExiste(xmlSiteDir)
    CreateIfNotExiste(outputWebgrabber)
    

def RemoveEmptyLine(file):
    import shutil
    with open(file) as infile, open(file+'.tmp', 'w') as outfile:
        for line in infile:
            if not line.strip(): continue  # skip the empty line
            outfile.write(line)  # non-empty line. Write it to output
    shutil.move(file+'.tmp',file)

def lreplace(pattern, sub, string):
    """
    Replaces 'pattern' in 'string' with 'sub' if 'pattern' starts 'string'.
    """
    return re.sub('^%s' % pattern, sub, string)

def copytree(src, dst, symlinks=False, ignore=None):
    if not os.path.exists(dst):
        os.makedirs(dst)
    for item in os.listdir(src):
        s = os.path.join(src, item)
        d = os.path.join(dst, item)
        if os.path.isdir(s):
            copytree(s, d, symlinks, ignore)
        else:
            if not os.path.exists(d) or os.stat(s).st_mtime - os.stat(d).st_mtime > 1:
                shutil.copy2(s, d)
             
def purge(name,lang):
    # remove all space, -, _ before comapr channel name
    # print "entry purge",name,lang
        # remove all space, -, _ before comapr channel name
    import unicodedata, re
    purgedname=name.upper().replace(lang+" :","").replace("|"+lang+"|","").strip()

    if lang=="FR":
        purgedname=purgedname.replace(".F","")


    # if "BEIN" in purgedname:
    #     regexBein='(^.*)BEIN ?([A-Z]*) ?([0-9]*) ?([A-Z]*)'

    #     lang, type, num, quality=re.findall(regexBein, purgedname )[0]
    #     purgedname= "BEIN "+type.replace("WAZAN","SPORTS") + num
       
    
    purgedname = purgedname.replace("HD","")
    purgedname = purgedname.replace("SD","")
    purgedname = purgedname.replace("TV","")
    purgedname = purgedname.replace("-LOW","")
    purgedname = purgedname.replace("LOW","")
    purgedname = purgedname.replace("-FULL","")

    # remove 4K in name: bein
    purgedname = purgedname.replace("*4k*6MB","")
    purgedname = purgedname.replace("*"," ")

    # time shift

    purgedname = purgedname.replace(" 1H","")
    purgedname = purgedname.replace(" 2H","")
    purgedname = purgedname.replace(" 3H","")
    purgedname = purgedname.replace(" 6H","")




              

    purgedname = purgedname.replace("&","ET")
    
    purgedname = purgedname.replace("VIP-OSN-","")
    purgedname = purgedname.replace("LO_OSN_","")
    purgedname = purgedname.replace("AR-OSN-","")    
    purgedname = purgedname.replace("OSN_","")  
    purgedname = purgedname.replace("OSN-","")
    purgedname = purgedname.replace("MY","")
    purgedname=lreplace('VIP-','',purgedname)

    if not "FRANCE24" in purgedname:
        purgedname=lreplace('FR-','',purgedname)    
        purgedname=lreplace('AR-','',purgedname)


    purgedname = purgedname.replace(":","")
    purgedname = purgedname.replace("-","")
    purgedname = purgedname.replace("?","")
    purgedname = purgedname.replace("_","")
    purgedname = purgedname.replace(" ","")
    purgedname = purgedname.replace("+","PLUS")
    purgedname = purgedname.replace("(","")
    purgedname = purgedname.replace(")","")
    purgedname = purgedname.replace("/","")
    purgedname = purgedname.replace(".","")
    purgedname = purgedname.replace(".","") 
    purgedname = purgedname.replace("_","")  

    # print "name, purgedname", name, purgedname

    return purgedname

def purgeBeta(string):
    # remove all space, -, _ before comapr channel name
    # print "entry purge"
        # remove all space, -, _ before comapr channel name
    import unicodedata, re

    purgedname=supprime_accent(string)
    purgedname = purgedname.upper().strip()

    tabBein=[
        'SPORTS',
        'SPORT',
        'FR-',
        'AR-',
        'LOCAL-',
        'VIP-',
        'B-',
        'VIP-',
        'B-',
        'L-',
        '+',
        ]

    tab=[
        ' 1H',
        ' 2H',
        ' 3H',
        ' 6H',
        'HD',
        'SD',
        'TV',
        '-LOW',
        'LOW-',
        'VIP-',
        'B-',
        '*4k*6MB',
        '*',
        'VIP-OSN-',
        'LO_OSN_',
        'AR-OSN-',
        'OSN_',
        'LO_OSN_',
        ':',
        '-',
        '?',
        '_',
        '(',
        ')',
        '/',
        '.',

        '_',
        '(',
        ')',
        ]



    purgedname = purgedname.replace("+","plus")
    purgedname = purgedname.replace("&","ET")

    if "BEIN" in purgedname:        
        for ch in tabBein:
            if ch in purgedname:
                purgedname=purgedname.replace(ch,"")

   
    for ch in tab:
        if ch in purgedname:
            purgedname=purgedname.replace(ch,"")

    return purgedname


def CreateIfNotExiste(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)

#Create output directories
# def CreateOutputs(workspace):
#     # workspace="c:\Users\soufi_000\Dropbox\Public\XBMC\LIVE_TV/"

#     CreateIfNotExiste(output)
#     # CreateIfNotExiste(logos)
#     CreateIfNotExiste(logs)
#     CreateIfNotExiste(OutStreamDir)
    

def supprime_accent(ligne):
    # ligne = ligne.lower()
    accent = ['é','É', 'è', 'ê', 'à', 'ù', 'û', 'ç', 'ô','Ô' 'î', 'ï', 'â']
    sans_accent = ['e', 'e','e', 'e', 'a', 'u', 'u', 'c', 'o', 'o', 'i', 'i', 'a']
     
    for c, s in zip(accent, sans_accent):
        ligne = ligne.replace(c, s)

 
    return ligne


def GetLocalOrRemoteFile(srcfile,dstDir):

    print "srcfile",srcfile
    if os.path.isfile(srcfile):
        path, filename = os.path.split(srcfile)
        destfile= os.path.join(dstDir, filename)
        shutil.copy(srcfile, destfile)        
    else:
        try: 
            path, filename = os.path.split(srcfile)
            filename = filename.upper().replace(" ","").replace("?","").replace("!","").replace("=","_").replace("&","_").replace(".M3U","") + ".m3u"
            destfile= os.path.join(dstDir, filename)      
            urllib.urlretrieve(srcfile , destfile)
        except:   
            raise         
            print "can't get remote file" 
    return

def pretty_print(infile,outfile,ResetGrabber=False):
    print ">> pretty_print: ",infile,outfile
    from lxml import etree

    #discard strings which are entirely white spaces
    myparser = etree.XMLParser(remove_blank_text=True, encoding="utf-8")

    root = etree.parse(infile,myparser)

    #from Birei's answer 
    for elem in root.iter('*'):
        if elem.text is not None:
            elem.text = elem.text.strip()
        if elem.tail is not None:
            elem.tail = elem.tail.strip()



    #write the xml file with pretty print and xml encoding
    root.write(infile, pretty_print=True, encoding="utf-8", xml_declaration=True)
    # root.write(infile, pretty_print=True,  xml_declaration=True)
    SortDataBase(infile,outfile)

    # raise

    if ResetGrabber==True:
        with open(infile,"r") as input:
            with open(outfile,"wb") as output: 
                for line in input:                   
                    if not ("<Grab" in line):    
                        # print "line",line         
                        output.write(line)


    return


def pretty_printWebGrabConfig(infile,outfile,ResetGrabber=False):
    print "pretty_printWebGrabConfig", infile,outfile
    from lxml import etree

    #discard strings which are entirely white spaces
    myparser = etree.XMLParser(remove_blank_text=True, encoding="utf-8")

    root = etree.parse(infile,myparser)

    #write the xml file with pretty print and xml encoding
    root.write(outfile, pretty_print=True, encoding="utf-8", xml_declaration=True)



    return

def SortDataBase(input,output):

    tree = ET.parse(input)

    # this element holds the phonebook entries
    container = tree.find("channels")

    data = []
    for elem in container:
        key = elem.findtext("cname").upper()
        data.append((key, elem))

    data.sort()

    # insert the last item from each tuple
    container[:] = [item[-1] for item in data]

    tree.write(output)
    return

def SortDataBase(input,output):

    tree = ET.parse(input)

    # this element holds the phonebook entries
    container = tree.find("channels")

    data = []
    for elem in container:
        key = elem.findtext("cname").upper()
        data.append((key, elem))

    data.sort()

    # insert the last item from each tuple
    container[:] = [item[-1] for item in data]

    tree.write(output)
    return


def DownloadCloudflare(url,outfile):
    print "DownloadCloudflare: ", url,outfile


    try:
        import cfscrape
    except:
        install("cfscrape")
        import cfscrape

    scraper = cfscrape.create_scraper()

    cfurl = scraper.get(url).content
    # outfile = url.split('/')[-1]

    with open(outfile, 'wb') as f:
        f.write(cfurl)
