#!/usr/bin/python
# -*- coding: utf-8 -*-




def notify(message, duration=5000, image="ADDON_ICON", level="LOGDEBUG", sound=True):
    """
    Display a Kodi notification and log the message.

    :type message: str
    :param message: the message to be displayed (and logged).
    :type duration: int
    :param duration: the duration the notification is displayed in milliseconds (defaults to 5000)
    :type image: str
    :param image: the path to the image to be displayed on the notification (defaults to ``icon.png``)
    :type level: int
    :param level: (Optional) the log level (supported values are found at xbmc.LOG...)
    :type sound: bool
    :param sound: (Optional) Whether or not to play a sound with the notification. (defaults to ``True``)
    """
    if message:
        print message


