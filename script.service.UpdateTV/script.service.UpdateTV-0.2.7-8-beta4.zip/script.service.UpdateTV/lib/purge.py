# -*- coding: utf-8 -*-
# encoding: utf-8

from __future__ import unicode_literals

import globalvar, utils

def RemoveDir(folder):
    import shutil
    import os
    from os import listdir
    from os.path import isfile, join

    filesToRemove = [join(folder, f) for f in listdir(folder) if isfile(join(folder, f))]
    filesToRemove = listdir(folder) 
    import os
    from glob import glob
    filesToRemove = [y for x in os.walk(folder) for y in glob(os.path.join(x[0], '*.strm'))]
    for f in filesToRemove:
        # utils.notify(f) 
        # raise
        # os.remove(f.encode('utf-8')) 
        os.remove(f) 
    shutil.rmtree(folder)
    return

def PurgeFiles(TmpDir,OutDir, pattern):
    utils.notify(">> PurgeFiles: "+pattern)
    utils.notify("TmpDir: ")
    utils.notify(TmpDir)
    utils.notify("OutDir: ")
    utils.notify(OutDir)

    import os
    from os import listdir
    from os.path import isfile, join
    filesToRemove = [join(TmpDir, f) for f in listdir(TmpDir) if isfile(join(TmpDir, f))]
    filesToRemove += [join(OutDir, f) for f in listdir(OutDir) if isfile(join(OutDir, f))]

    for f in filesToRemove:
        utils.notify("f: "+f)
        if pattern in f and isfile(f):     
            utils.notify(f)     
            os.remove(f)

    utils.notify("<< PurgeFiles:")
    return 

def PurgeOutputs(TmpDir,OutDir):
    utils.notify(">> PurgeOutputs:")
    utils.notify("TmpDir: ")
    utils.notify(TmpDir)
    utils.notify("OutDir: ")
    utils.notify(OutDir)

    import os
    from os import listdir
    from os.path import isfile, join
    filesToRemove = [join(TmpDir, f) for f in listdir(TmpDir) if isfile(join(TmpDir, f))]
    filesToRemove += [join(OutDir, f) for f in listdir(OutDir) if isfile(join(OutDir, f))]

    for f in filesToRemove:
        if "m3u" in f and isfile(f):     
            utils.notify(f)     
            os.remove(f)

    utils.notify("<< PurgeOutputs:")
    return 

def PurgeM3U():
    PurgeFiles(TmpDir,OutDir, "m3u")
    return

def PurgeVOD():
    PurgeFiles(globalvar.TmpDir,globalvar.OutDir, ".strm")
    return

def PurgeOutputs():
    from os.path import isfile, join
    # RemoveDir(join(globalvar.TmpDir, RemoteFilms))
    RemoveDir(globalvar.OutDir)

    return

