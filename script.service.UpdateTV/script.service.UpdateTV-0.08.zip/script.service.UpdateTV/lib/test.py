# -*- coding: utf-8 -*-

import xml.etree.ElementTree as ET
# from MyApi import *
# import MyFile
# import globalvar

# from reset_exclusions import *
# from utils import *
# from viewer import *

# # import xbmcgui


class Updater(object):


    STATUS_SUCCESS = 1
    STATUS_FAILURE = 2
    STATUS_ABORTED = 3  

    # progress = xbmcgui.DialogProgress()
    # monitor = xbmc.Monitor()
    # silent = True
    # exit_status = STATUS_SUCCESS
    # user=globalvar.ADDON.getSetting('user')
    # password=globalvar.ADDON.getSetting('pass')

    def __init__(self):
        print "init"
        # debug("{0!s} version {1!s} loaded.".format(ADDON.getAddonInfo("name").decode("utf-8"),
        #                                            ADDON.getAddonInfo("version").decode("utf-8")))


    def notify(self,text,time = 3000):
        # time = 3000  #in miliseconds 
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('TV Updater',text, time, os.path.join( globalvar.ADDON_DIR, "icon.png")))

    def CreateIfNotExiste(self,directory):
        if not os.path.exists(directory):
            os.makedirs(directory)

    def CopyVODToLocal(self,OutDir):
        
        # if sys.platform.startswith('win'):
        #     # notify("file function with unicodes")
        #     notify("Win start Copy Remote VOD to ")
        # else:
        #     # notify("file function with utf-8 encoded strings")
        #     notify("Android start Copy Remote VOD to ")
        # notify(OutDir)

        

        import os
        import urllib

        import os.path
        import filecmp

        

        # urllib.urlretrieve (VODurl, VODFile)

        if os.path.isfile(globalvar.VODFile+'.back'):
            Changed=not(filecmp.cmp(globalvar.VODFile, globalvar.VODFile+'.back'))
        else:
            Changed=True

        if Changed==True:

            inf =open(globalvar.VODFile,'r')  

         
            title=""
            path=""
            for line in inf:
                moviefile=""
                
                try:
                    line=line.strip()
                    if sys.platform.startswith('win'):
                        line=line.decode("utf-8")

                    # print "line", line
                    if line.upper().startswith("HTTP"):
                        path=line
                    elif line and not line.startswith('#EXTM3U'):
                        try: 
                            title = re.search(r'(?<=tvg-id=").*?(?=")', line).group(0).strip()                  
                        except:                    
                            rest,title = line.rsplit(',',1)     
                    

                    if (title !="") and (path!=""):
                        lang=""
                        moviefile=""
                        if title.upper().endswith('_FR'):
                            title=title.replace("_",".")
                            moviefile=OutDir+"/films/fr/"+title.upper().replace("_FR","")+".strm"
                        # elif title.upper().endswith('_AR'):
                        elif "_AR" in title.upper():                               
                            title=title.replace("_",".")                         
                            moviefile=OutDir+"/films/ar/"+title.upper().replace("_AR","")+".strm"

                        if moviefile is not "":
                            foo = open(moviefile, 'w')
                            foo.write(path)
                            foo.close()

                        title=""
                        path=""
                
                except:
                    # raise
                    pass

            self.notify("END Copy ")
        else: #not changed
            print "TVUpdate: No DB update needed " 
            # notify("No DB update needed ")

        return 

    def UpdateVOD(self):
        # self.notify("Start updater ... ")



        self.CreateIfNotExiste(globalvar.OutDir)
        self.CreateIfNotExiste(globalvar.OutDir+'/films/fr/')
        self.CreateIfNotExiste(globalvar.OutDir+'/films/ar/')


        self.CopyVODToLocal(globalvar.OutDir)


        # self.notify("END updater ... ")


        return 

    def AddSource(self, video,name,path):

        source = ET.SubElement(video, 'source')

        childPath = ET.Element("path", pathversion="1")
        childPath.text=path

        childName = ET.Element("name")
        childName.text=name

        childAllowsharing = ET.Element("allowsharing")
        childAllowsharing.text="true"

        source.append(childName)
        source.append(childPath)
        source.append(childAllowsharing)


        return 

    def UpdateSourceFile(self,sourcespath,name,path):  

        AleadyExist=False

        sourcesDATA = ET.parse(sourcespath, parser=ET.XMLParser(encoding="utf-8" ))


        rootVideos=sourcesDATA.find('video')

        for source in rootVideos.findall("source"):
                if source.find('path').text==path:
                    AleadyExist=True

        if AleadyExist==False:
            self.AddSource(rootVideos,name,path)
            sourcesDATA.write(sourcespath)
            self.notify("Please restart KODI")
            
            ok = xbmcgui.Dialog().ok("TV Updater","Please restart KODI")

        return
    
    def UpdateSimpleIPTVSettings(self,m3ufile):  

        AleadyExist=False
        Settingspath="c:\Users\soufian\AppData\Roaming\Kodi\userdata/addon_data\pvr.iptvsimple\settings.xml"

        SettingsDATA = ET.parse(Settingspath, parser=ET.XMLParser(encoding="utf-8" ))


        rootsettings=SettingsDATA.findall('setting')
        for s in rootsettings:
            if s.get('id')=="m3uPath":
                s.attrib['value']=m3ufile
                SettingsDATA.write(Settingspath)
                break




        return


    def clean_all(self):
        """
        Clean up any watched videos in the Kodi library, satisfying any conditions set via the addon settings.

        :rtype: (str, int)
        :return: A single-line (localized) summary of the cleaning results to be used for a notification, plus a status.
        """
        debug("Starting cleaning routine.")

        if get_setting(clean_when_idle) and xbmc.Player().isPlaying():
            debug("Kodi is currently playing a file. Skipping cleaning.", xbmc.LOGWARNING)
            return None, self.exit_status

        results = {}
        cleaning_results, cleaned_files = [], []
        if not get_setting(clean_when_low_disk_space) or (get_setting(clean_when_low_disk_space) and disk_space_low()):
            if not self.silent:
                self.progress.create(ADDON_NAME, *map(translate, (32619, 32615, 32615)))
                self.progress.update(0)
                self.monitor.waitForAbort(2)
            for video_type in [self.MOVIES, self.MUSIC_VIDEOS, self.TVSHOWS]:
                if not self.__is_canceled():
                    cleaned_files, count, status = self.clean(video_type)
                    if count > 0:
                        cleaning_results.extend(cleaned_files)
                        results[video_type] = count
            if not self.silent:
                self.progress.close()

        # Check if we need to perform any post-cleaning operations
        if cleaning_results:
            # Write cleaned file names to the log
            Log().prepend(cleaning_results)

            # Finally clean the library to account for any deleted videos.
            if get_setting(clean_kodi_library):
                self.monitor.waitForAbort(2)  # Sleep 2 seconds to make sure file I/O is done.

                if xbmc.getCondVisibility("Library.IsScanningVideo"):
                    debug("The video library is being updated. Skipping library cleanup.", xbmc.LOGWARNING)
                else:
                    xbmc.executebuiltin("XBMC.CleanLibrary(video, false)")

        return self.summarize(results), self.exit_status

 

class IPTV():
    def __init__(self, title,tvg,tvg_shift,tvIcon,radio,group,xbmc, path,calias,state,SiteEPG,site_id,lang):
        self.title = title
        self.tvg = tvg
        self.tvg_shift = tvg_shift
        self.tvIcon = tvIcon
        self.radio = radio
        self.group = group
        self.xbmc = xbmc
        self.path = path
        self.calias = calias
        self.state = state        
        self.SiteEPG = SiteEPG
        self.site_id = site_id
        self.lang = lang

updater = Updater()

def getKey(IPTV):
    #filter by group
    return IPTV.group

def getKeyTvg(IPTV):
    #filter by tvgname
    return IPTV.xbmc
    # return IPTV.tvg

def CreateUsersPlaylist(patern,users):


    for user in users:
        PlaylistUser=PlaylistFile.replace(".m3u","_"+user+".m3u")  

        infile = open(PlaylistFile).read()
        out = open(PlaylistUser, 'w')
        infile = infile.replace(patern[0], users[user][0])
        infile = infile.replace(patern[1], users[user][1])
        out.write(infile)
        out.close
    return

def RenameChannelName(IPTV):
    if ("/UDP/" in IPTV.path.upper()):
        IPTV.xbmc = "[COLOR red] " + IPTV.xbmc + " [/COLOR]" + " UDP"



    if IPTV.title.upper().startswith("VIP-"):
        IPTV.xbmc = IPTV.xbmc + " VIP"
    if "*4k*6MB" in IPTV.title.upper():
        IPTV.xbmc = IPTV.xbmc + " 4K"
    if ("HD" in IPTV.title.upper()) and ("HD" not in IPTV.xbmc.upper()) :
        IPTV.xbmc = IPTV.xbmc + " HD"

    if ("SD" in IPTV.title.upper()) and ("SD" not in IPTV.xbmc.upper()) :
        IPTV.xbmc = IPTV.xbmc + " SD"
    if IPTV.title.upper().endswith("-low"):
        IPTV.xbmc = IPTV.xbmc + " LOW"

    if IPTV.title.upper().endswith(" 1H"):
        IPTV.xbmc = IPTV.xbmc.replace(" 1H","") + " 1H"
    if IPTV.title.upper().endswith(" 2H"):
        IPTV.xbmc = IPTV.xbmc.replace(" 2H","")  + " 2H"
    if IPTV.title.upper().endswith(" 3H"):
        IPTV.xbmc = IPTV.xbmc.replace(" 3H","")  + " 3H"
    if IPTV.title.upper().endswith(" 6H"):
        IPTV.xbmc = IPTV.xbmc.replace(" 6H","")  + " 6H"

    if IPTV.title.upper().strip()=="1": #Patch for HD 1
        IPTV.xbmc = "HD 1"


    # all stream not in otmanshowiptv playlist
    if not IPTV.path.upper().startswith("HTTP://ELECTROWAZAN7.COM"):
        IPTV.xbmc="[COLOR blue] "+IPTV.xbmc+" [/COLOR]"


    return IPTV

def RenameGroup(IPTV,lang,favorite):
    # print "RenameGroup",(IPTV.group,lang)
    debug("RenameGroup "+(IPTV.group+" "+lang), xbmc.LOGWARNING)

    lang=lang.upper()
    # IPTV.group=IPTV.group.replace(" AR","").replace(" FR","").replace(" CA","")




    if ("BEIN SPORTS" in IPTV.title.upper()):
        IPTV.group = "SPORTS BEIN" + " "+ lang

    elif ("BEIN" in IPTV.title.upper()):
        IPTV.group = "6-BEIN GROUP"

    if ("SFR SPORT" in IPTV.xbmc.upper() or "CANAL+ SPORT" in IPTV.xbmc.upper() or ("SPORT" in IPTV.xbmc.upper())):
        if IsFavoriteLang(lang):
            IPTV.group="5-SPORTS" + " "+ lang
        else:
            IPTV.group="ZE SPORTS" + " "+ lang

    elif ("MOVIE" in IPTV.title.upper()):
        IPTV.group = "MOVIES" + " "+ lang

    elif ("ON-DEMAND" in IPTV.title.upper()):
        IPTV.group = "ON-DEMAND"  + " "+ lang           
        IPTV.title = IPTV.title.upper().replace("-"," ")

    elif "OSN" in IPTV.title.upper().strip():
        IPTV.group="OSN GROUP"      

    elif "CANALPLAY" in IPTV.title.upper().strip():
        IPTV.group="CANALPLAY/VOD"  + " "+ lang
        IPTV.tvIcon="https://pbs.twimg.com/profile_images/672405725491122178/kQLz1EsE_400x400.jpg"
        IPTV.tvg=IPTV.title.replace("-","").replace("fr","").replace("vip","")
        if IPTV.title.upper().startswith("VIP-"):
            IPTV.xbmc = "[COLOR green] " + IPTV.tvg + " [/COLOR]"
        else:
            IPTV.xbmc = IPTV.tvg

    elif "MEGA-BOX" in IPTV.title.upper().strip():
        IPTV.group="CANALPLAY/VOD"  + " "+ lang
        IPTV.tvIcon="http://megaboxhdapp.com/wp-content/uploads/2015/08/Megabox-HD-Icon.png"
        IPTV.tvg=IPTV.title.replace("-"," ").replace("fr","")
        IPTV.xbmc = IPTV.tvg

    if ("A LA CARTE" in IPTV.xbmc.upper()) :
        IPTV.group="CANALPLAY/VOD" + " "+ lang

    if ("MBC" in IPTV.xbmc.upper()) and ("ZE UNKNOWN" in IPTV.group):
        IPTV.group="2-ARABIC" 


    if ("musi" in IPTV.group.lower()) or ("MUSIC" in IPTV.xbmc.upper()) or ("MUSIQ" in IPTV.xbmc.upper()):
        IPTV.group="MUSIC" + " "+ lang

    if ("jeunesse" in IPTV.group.lower()):
        IPTV.group="KIDS"  + " "+ lang    

    if ("new" == IPTV.group.lower()) or ("info" in IPTV.group.lower()):
        IPTV.group="4-NEWS"  + " "+ lang   

    if ("adulte" in IPTV.group.lower()):
        IPTV.group="ze unknown" 
    if IPTV.group  == '':
       IPTV.group = "ze unknown"



    # print "IPTV.group",IPTV.group
    return IPTV

def OpenFile(M3UPlaylist):
    inf="can't open file" 

    if os.path.isfile(M3UPlaylist):
        inf = open(M3UPlaylist,'r')
    else:
        try:
            path, filename = os.path.split(M3UPlaylist)
            try:                
                filename = filename.upper().replace(" ","").replace("?","").replace("!","").replace(".M3U","") + ".m3u"
                urllib.urlretrieve(M3UPlaylist , OutStreamDir+filename)
                inf = open(OutStreamDir+filename,'r')
                print "file name ",filename
            except:   
                raise         
                urllib.urlretrieve(M3UPlaylist , "M3UPlaylist.m3u.tmp")
                inf = open("M3UPlaylist.m3u.tmp",'r')

            
        except IOError as e:
            print "ERROR: M3UPlaylist: get file I/O error({0}): {1}".format(e.errno, e.strerror)
            #logger.info("ERROR: M3UPlaylist: get file : I/O error({0}): {1}".format(e.errno, e.strerror))
            return inf

    return inf

def GetM3U_data(M3UPlaylist):
    import re
    print ("start GetM3U_data: playlist: ",M3UPlaylist)
    #logger.info("start GetM3U_data:  playlist: %s ", M3UPlaylist)

    # initialize playlist variables before reading file
    playlist=[]
    if not os.path.exists(OutStreamDir):
                os.makedirs(OutStreamDir)

    inf = OpenFile(M3UPlaylist)

    #title,tvg,tvIcon,radio,group, xbmc, path)
    song=IPTV(None,None,None,None,None,None,None,None,None,None,None,None,None)

    for line in inf:
        # print "===>>> line",line
        
        line=line.strip()
        if line and not line.startswith('#EXTM3U'):
            lang=""
            tvg_shift=""
            
            ##EXTINF:-1 tvg-id="2M" tvg-name="2M" tvg-logo="2M.png" group-title="Maroc"2M
            if line.startswith('#EXTINF:'):
                # print "line:", line

            
                # line = str(line.strip())            
                line=MyFile.supprime_accent(line)
                try: 
                    title = re.search(r'(?<=tvg-id=").*?(?=")', line).group(0).strip()                  
                except:
                    
                    try:
                        rest,title = line.rsplit(',',1)  
                        lang,cname = title.rsplit(':',1) 
                        lang=lang.upper().strip()
                        

                        #title = re.search(r'(?<=tvg-id=").*?(?=")', line).group(0)              
                    except:
                        # raise
                        try:                                  
                            rest,title = line.rsplit(',',1)
                        except:
                            try:
                                rest,title = line.rsplit('#EXTINF:-1',1)
                            except:
                                title=line.replace("#extinf:-1",'').split()
           
                

                try: 
                    tvg = re.search(r'(?<=tvg-name=").*?(?=")', line).group(0).strip()                  
                except:
                    tvg =''
                try: 
                    tvIcon = re.search(r'(?<=tvg-logo=").*?(?=")', line).group(0).strip()   
                except:
                    tvIcon =''
                
              
                try: 
                    radio = re.search(r'(?<=radio=").*?(?=")', line).group(0).strip()   
                except:
                    radio =''
                
                try: 
                    group = re.search(r'(?<=group-title=").*?(?=")', line).group(0).strip()   
                except:
                    group =''

                xbmc=title.replace("HD","").strip().upper().strip()   

                if "audio-track" in line.lower():                
                    try: 
                        lang = re.search(r'(?<=audio-track=").*?(?=")', line).group(0).strip()   
                    except:
                        lang =''  
                else:            
                    try:
                        print title
                        lang,tmp = title.rsplit(':',1) 
                        lang=lang.upper().strip()
                        if lang=="":
                            lang="AR"
                    except:
                        lang="AR"
                        pass
            
                song=IPTV(title,tvg,tvg_shift,tvIcon,radio,group.upper(),xbmc,None,None,None,None,None,lang)
                
            else:
                song.path=line
                playlist.append(song)
                # reset the song variable so it doesn't use the same EXTINF more than once
                song=IPTV(None,None,None,None,None,None,None,None,None,None,None,None,None)

    inf.close()

    # for IPTVT in playlist:
    #     print (IPTVT.title, IPTVT.lang, IPTVT.xbmc, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path)

        # self.title = title
        # self.tvg = tvg
        # self.tvIcon = tvIcon
        # self.radio = radio
        # self.group = group
        # self.xbmc = xbmc
        # self.path = path
        # self.calias = calias
        # self.state = state        
        # self.SiteEPG = SiteEPG
        # self.site_id = site_id
        # self.lang = lang
      
    return playlist

def IsFavoriteLang(lang):
    # print "IsFavoriteLang",(lang)

    if lang=="AR" or lang=="FR" or lang=="" or lang=="MYHD" or lang=="BEIN":
        return True


    return False

def IsFavorite(IPTV):
    
    if IsFavoriteLang(IPTV.lang) or "SPORT" in IPTV.title.upper() or "MUSIC" in IPTV.title.upper() or "BEIN" in IPTV.title.upper():
        return True

    return False

def GeneratePlaylistOutputs(Playlist,PlaylistFile,sort=True):
    # print ">>>>> start MiseEnForme", PlaylistFile,
    # updater.notify("GeneratePlaylistOutputs")
    import operator 
         

    # 
    if sort==True:
        PlaylistForma = sorted(Playlist, key=getKeyTvg)
        PlaylistForma = sorted(PlaylistForma, key=getKey)
    else:
        PlaylistForma=Playlist

 
    Cleanplaylist = ''
    CleanplaylistUnkn = ''
    EpgXml =''
    EpgXmlMissing=""
    global_header = "#EXTM3U\n"

    Cleanplaylist += global_header
    CleanplaylistUnkn += global_header
    

    DupLess = []
    DupLessPath = []
    DupLessEPG = []
    for IPTVT in PlaylistForma:
        # print "IPTV",(IPTVT.title, IPTVT.tvg, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path, IPTVT.SiteEPG, IPTVT.lang)
          
        if IPTVT.path not in DupLessPath:
            DupLessPath.append(IPTVT.path)
            # print "GeneratePlaylistOutputs: IPTV",(IPTVT.title, IPTVT.group, IPTVT.tvg)
            try:
                try:
                    # IPTVT.tvg=IPTVT.tvg.encode('utf-8')
                    print "\nIPTVT", IPTVT.title, IPTVT.group, IPTVT.tvg, IPTVT.tvg_shift         
                except:
                    # print "\n****PTVT.tvg", IPTVT.tvg.encode('utf-8')
                    # raise
                    IPTVT.tvg=IPTVT.title
                    pass

                if "/movie/" in IPTVT.path.lower(): 
       
                    try:
                        IPTVT.title.encode('ascii')
                    except:                        
                        lang="AR" 
                        # IPTVT.title=IPTVT.title.decode("utf-8")+"_AR"
                        IPTVT.title=IPTVT.title+"_AR"
                        IPTVT.xbmc=IPTVT.title
        

                channel_header = '#EXTINF:-1 tvg-id="%s" tvg-name="%s" tvg-shift="%s" "audio-track="%s"  tvg-logo="%s" radio="%s"  group-title="%s",%s\n' \
                        % (IPTVT.title, IPTVT.tvg, IPTVT.tvg_shift, IPTVT.lang, IPTVT.tvIcon, IPTVT.radio, IPTVT.group.upper() , IPTVT.xbmc)
                # print channel_header

                Cleanplaylist += channel_header
                Cleanplaylist += IPTVT.path + '\n'+'\n'
            except UnicodeDecodeError as err:
                print "\n*************** error: ",err, "\n", IPTVT.path     

                pass
            except:
                updater.notify(IPTVT.title)  
                pass

                # raise

              
    f = open(PlaylistFile, "w")
    f.write(Cleanplaylist)
    f.close()

        
    return

def ParseDataBase(DBJson,playlist):

    # print "\n >>>>>>>>>>>> start ParseDataBase ... <<<<", datetime.datetime.now().time()

    # updater.notify(" ParseDataBase ")
    import json
    IPTVFound = 0

    group = ""
    radio = ""

    playlistTrie = ''
    Cleanplaylist = ''
    CleanplaylistUnkn = ''
    CleanplaylistKO = ''

    IPTV_DATA = []
    IPTV_DATAKO = []
    IPTV_UNKNOWN = []


    # 'name':("logo",'other')
    VODDB={}

    with open(DBJson) as data_file: 
        Jsondatabase = json.load(data_file,encoding="utf-8" )


    DupLessPath = []
    for IPTV in playlist:
        IPTVFound = 0
        favorite = False
        IPTV.tvg_shift=''

        

        if IPTV.title != None: #Title not empty
            imageurl = ""  
            # print "IPTV.title", IPTV.title, MyFile.purge(IPTV.title,'') 
            IPTV.path=IPTV.path.replace("|User-Agent=Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/48.0.2564.116 Chrome/48.0.2564.116 Safari/537.36","")
        
            # print "\nTitle= ",IPTV.title ,"lang= ", IPTV.lang, "Isfavorite= ", IsFavoriteLang(IPTV.lang) 
            favorite=IsFavorite(IPTV)
            if (IPTV.path not in DupLessPath) and (favorite or IPTV.group!=""):  # first occurence   
                # print "IPTV.title", IPTV.title         
                # print "\n IPTV.title", MyFile.purge(IPTV.title,IPTV.lang)
                if IPTV.group=="":
                    if ("/movie/" not in IPTV.path.lower()):
                        DupLessPath.append(IPTV.path)
                        state, radio = True, "TV"
                        if IPTV.title.upper().endswith("_AR"):
                            IPTV.title=IPTV.title.replace("_AR","")
                        if IPTV.title.upper().endswith("_FR"):
                            IPTV.title=IPTV.title.replace("_FR","")

                    
                        IPTVFound = 0  
                        # updater.notify(IPTV.title,100)

                        for chaine in Jsondatabase:
                            # print 'chaine["tvgIPTV"]', chaine["tvgIPTV"]
                            for i in chaine["calias"]:                  
                                if MyFile.purge(IPTV.title,IPTV.lang)==MyFile.purge(i.encode('utf-8'),""):
                                    
                                    IPTVFound=True
                                    break
                            if IPTVFound == 1: 
                                # print '** chaine["tvgIPTV"]', chaine["tvgIPTV"].encode('utf-8')

                                IPTV.xbmc=chaine["Title"]
                                IPTV.group = chaine["group"][0]
                                IPTV.tvIcon = chaine["tvIcon"] 
                                IPTV.tvg=chaine["tvgIPTV"]
                                break

                            if IPTVFound == 0:
                                # print "not found", 
                                IPTV.xbmc= IPTV.xbmc.strip()
                                IPTV.group==IPTV.lang.upper()   

 
                        if IPTV.radio == '':
                            if radio == 'RADIO':
                                IPTV.radio = "true"
                            else:
                                IPTV.radio = "false"

                        if IPTV.xbmc.endswith(' 1H'):                            
                            IPTV.tvg_shift='-1'
                        elif IPTV.xbmc.endswith(' 3H'):
                            IPTV.tvg_shift='-3'
                        elif IPTV.xbmc.endswith(' 6H'):
                            IPTV.tvg_shift='-6'


                        IPTV=RenameGroup(IPTV,IPTV.lang,favorite)    
                        IPTV_DATA.append(IPTV)

                    else:
                        # print IPTV.title, "is a VOD"
                        break

                if IPTV.xbmc.endswith(' 1H'):                            
                    IPTV.tvg_shift='-1'
                elif IPTV.xbmc.endswith(' 3H'):
                    IPTV.tvg_shift='-3'
                elif IPTV.xbmc.endswith(' 6H'):
                    IPTV.tvg_shift='-6'
                
                # print "already exist with data: ", IPTV.title
                # add defintion indication to channel name
                IPTV=RenameChannelName(IPTV)
                IPTV=RenameGroup(IPTV,IPTV.lang,favorite)    
                IPTV_DATA.append(IPTV)

            else:
                IPTV=RenameGroup(IPTV,IPTV.lang,favorite)   
                IPTV_DATAKO.append(IPTV)
            

    # print " >>>>>>>>>>>> END ParseDataBase ... <<<<", datetime.datetime.now().time()



    return IPTV_DATA, IPTV_DATAKO

def updateVODPrefix(OtmanIPTVfile):

    line_firstfr=""
    line_lastfr=""
    changedfile=""

    inf = open(OtmanIPTVfile,'r')

    for line in inf:
        # print line
        if line.strip().upper().endswith('_FR') and line_firstfr=="":
            line_firstfr=line
        if line.strip().upper().endswith('_FR'):
            line_lastfr=line

    change=False
    inf = open(OtmanIPTVfile,'r')
    for line in inf:
        if line==line_firstfr:
            change=True
            
        if line==line_lastfr:
            change=False
        if change==True and line.strip().upper().endswith('_FR')==False and line.strip().upper().endswith('.MP4')==False:
            line=line.strip()+"_FR"
            # raise
        changedfile += line+ '\n'



    print "first FR", line_firstfr
    print "Last FR", line_lastfr

    f = open(OtmanIPTVfile, "w")
    f.write(changedfile)
    f.close()

   
    return

def UpdatePlayList(OtmanIPTV,actualPlaylistFile,Reset=False):
    # updater.notify("UpdatePlayList")

    import re, urllib, time
    import os.path


    actualPlaylist=[]
    OtmanIPTVPlaylist=[]
    NewPlaylist=[]
    VOD=[]

    if not Reset and os.path.isfile(actualPlaylistFile):
        actualPlaylist += GetM3U_data(actualPlaylistFile)

    path, filename = os.path.split(OtmanIPTV)
    OtmanIPTVfile=TmpDir+"OtmanIPTV.m3u"

    try: # some connection issue
        urllib.urlretrieve(OtmanIPTV , OtmanIPTVfile)
    except:
        # print "\nconnection issue, retray in 2S ... "
        time.sleep(2)
        urllib.urlretrieve(OtmanIPTV , OtmanIPTVfile)

    updateVODPrefix(OtmanIPTVfile)


    OtmanIPTVPlaylist += GetM3U_data(OtmanIPTVfile)
    # OtmanIPTVPlaylist += iptv.GetM3U_data(OtmanIPTVfile)

    for IPTVo in OtmanIPTVPlaylist:
        # print "IPTVo",IPTVo.title
        exist=False
        if "/movie/" in IPTVo.path:
            # print "movie IPTVo.title", IPTVo.title
            VOD.append(IPTVo)
            # break 
        else:
            for IPTVa in actualPlaylist:
                if IPTVa.path==IPTVo.path:
                    exist=True
                    NewPlaylist.append(IPTVa)
            if exist==False:
                # print ">>> New:" ,IPTVo.title
                NewPlaylist.append(IPTVo)


    return NewPlaylist, VOD

def main():

    print ("\n *****start M3U Playlist creating at: \n"), 
    
    import filecmp
    VODFile="c:\Users\soufian\AppData\Roaming\Kodi\userdata/addon_data\script.service.UpdateTV\RemoteFilms/vod.m3u"
    print filecmp.cmp(VODFile, VODFile+'.back')

if __name__ == '__main__':
    main()

