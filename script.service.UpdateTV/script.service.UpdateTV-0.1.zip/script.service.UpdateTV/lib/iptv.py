# -*- coding: utf-8 -*-



# import xml.etree.ElementTree as ET

import xml.etree.ElementTree as ET

from MyApi import *
import MyFile


import MyTmdb

import globalsVar

try:
    import cchardet.version
except ImportError as err:  
    try:
        install("cchardet")
        import cchardet
    except:
        import Mycchardet as cchardet

OtmanIPTV="http://Electrowazan7.com:7777/get.php?username=soufone2&password=R3px9OfXWs&type=m3u&output=ts"
# OtmanIPTV="https://www.dropbox.com/s/8bop85mg37i0tex/test.m3u?dl=1"


class IPTV():
    def __init__(self, title,tvg,tvIcon,radio,group,xbmc, path,calias,state,SiteEPG,site_id,lang):
        self.title = title
        self.tvg = tvg
        self.tvIcon = tvIcon
        self.radio = radio
        self.group = group
        self.xbmc = xbmc
        self.path = path
        self.calias = calias
        self.state = state        
        self.SiteEPG = SiteEPG
        self.site_id = site_id
        self.lang = lang


def getKey(IPTV):
    #filter by group
    return IPTV.group

def getKeyTvg(IPTV):
    #filter by tvgname
    return IPTV.xbmc
    # return IPTV.tvg

def CreateUsersPlaylist(patern,users):


    for user in users:
        PlaylistUser=PlaylistFile.replace(".m3u","_"+user+".m3u")  

        infile = open(PlaylistFile).read()
        out = open(PlaylistUser, 'w')
        infile = infile.replace(patern[0], users[user][0])
        infile = infile.replace(patern[1], users[user][1])
        out.write(infile)
        out.close
    return

def RenameChannelName(IPTV):
    if ("/UDP/" in IPTV.path.upper()):
        IPTV.xbmc = "[COLOR red] " + IPTV.xbmc + " [/COLOR]" + " UDP"



    if IPTV.title.upper().startswith("VIP-"):
        IPTV.xbmc = IPTV.xbmc + " VIP"
    if "*4k*6MB" in IPTV.title.upper():
        IPTV.xbmc = IPTV.xbmc + " 4K"
    if "HD" in IPTV.title.upper():
        IPTV.xbmc = IPTV.xbmc + " HD"
    if "SD" in IPTV.title.upper():
        IPTV.xbmc = IPTV.xbmc + " SD"
    if IPTV.title.upper().endswith("-low"):
        IPTV.xbmc = IPTV.xbmc + " LOW"

    if IPTV.title.upper().endswith(" 1H"):
        IPTV.xbmc = IPTV.xbmc + " 1H"
    if IPTV.title.upper().endswith(" 2H"):
        IPTV.xbmc = IPTV.xbmc + " 2H"
    if IPTV.title.upper().endswith(" 3H"):
        IPTV.xbmc = IPTV.xbmc + " 3H"
    if IPTV.title.upper().endswith(" 6H"):
        IPTV.xbmc = IPTV.xbmc + " 6H"

    if IPTV.title.upper().strip()=="1": #Patch for HD 1
        IPTV.xbmc = "HD 1"


    # all stream not in otmanshowiptv playlist
    if not IPTV.path.upper().startswith("HTTP://ELECTROWAZAN7.COM"):
        IPTV.xbmc="[COLOR blue] "+IPTV.xbmc+" [/COLOR]"


    return IPTV

def RenameGroup(IPTV,lang,favorite):
    # print "RenameGroup",(IPTV.group,lang)

    lang=lang.upper()
    IPTV.group=IPTV.group.replace(" AR","").replace(" FR","").replace(" CA","")

    if IsFavoriteLang(lang):


        if IPTV.group=="ZE UNKNOWN" or IPTV.group=="":

            if ("http://flv.alarab.net" in IPTV.path.lower()):
                IPTV.group = "FILM alarab"

            elif ("BEIN SPORTS" in IPTV.title.upper()):
                IPTV.group = "SPORTS BEIN"
            elif ("SPORT" in IPTV.title.upper()):
                IPTV.group = "ZE SPORTS Other"
            elif ("MOVIE" in IPTV.title.upper()):
                IPTV.group = "MOVIES"
            elif ("ON-DEMAND" in IPTV.title.upper()):
                IPTV.group = "ON-DEMAND"
                IPTV.title = IPTV.title.upper().replace("-"," ")
            elif "OSN" in IPTV.title.upper().strip():
                IPTV.group="OSN GROUP"      

            elif "CANALPLAY" in IPTV.title.upper().strip():
                IPTV.group="CANALPLAY/VOD"
                IPTV.tvIcon="https://pbs.twimg.com/profile_images/672405725491122178/kQLz1EsE_400x400.jpg"
                IPTV.tvg=IPTV.title.replace("-","").replace("fr","").replace("vip","")
                if IPTV.title.upper().startswith("VIP-"):
                    IPTV.xbmc = "[COLOR green] " + IPTV.tvg + " [/COLOR]"
                else:
                    IPTV.xbmc = IPTV.tvg

            elif "MEGA-BOX" in IPTV.title.upper().strip():
                IPTV.group="CANALPLAY/VOD"
                IPTV.tvIcon="http://megaboxhdapp.com/wp-content/uploads/2015/08/Megabox-HD-Icon.png"
                IPTV.tvg=IPTV.title.replace("-"," ").replace("fr","")
                IPTV.xbmc = IPTV.tvg



            elif IPTV.title.upper().strip().startswith("FR-"):
                IPTV.group="ZE FR"
            elif IPTV.title.upper().strip().startswith("AR-"):
                IPTV.group="ZE AR"

        if ("BEIN SPORTS" in IPTV.xbmc.upper() or "SFR SPORT" in IPTV.xbmc.upper() or "CANAL+ SPORT" in IPTV.xbmc.upper() or ("SPORT" in IPTV.xbmc.upper())):
            IPTV.group="5-SPORTS" 

        if ("MBC" in IPTV.xbmc.upper()) and ("ZE UNKNOWN" in IPTV.group):
            IPTV.group="2-ARABIC" 

        if ("A LA CARTE" in IPTV.xbmc.upper()) or ("CANAL PLAY" in IPTV.xbmc.upper()) or ("MEGA BOX" in IPTV.xbmc.upper()) :
            IPTV.group="CHAINES CINEMA/SERIES" 

        if ("musi" in IPTV.group.lower()) or ("MUSIC" in IPTV.xbmc.upper()) or ("MUSIQ" in IPTV.xbmc.upper()):
            IPTV.group="MUSIC"

        # if ("maroc" in IPTV.group.lower()):
        #     IPTV.group="1-MAROC"
        # if ("arabic" in IPTV.group.lower()):
        #     IPTV.group="2-ARABIC"
        # if ("frensh" in IPTV.group.lower()):
        #     IPTV.group="3-FRENCH"
        # if ("maroc" in IPTV.group.lower()):
        #     IPTV.group="1 - MAROC"

        if ("jeunesse" in IPTV.group.lower()):
            IPTV.group="KIDS"     

        if ("new" == IPTV.group.lower()) or ("info" in IPTV.group.lower()):
            IPTV.group="NEWS"    

        if ("adulte" in IPTV.group.lower()):
            IPTV.group="ze unknown" 
        if IPTV.group  == '':
           IPTV.group = "ze unknown"

        if ("arabi" in IPTV.group.lower()) or ("french" in IPTV.group.lower()) or ("maroc" in IPTV.group.lower()):
            IPTV.group=IPTV.group
        else:
            IPTV.group = IPTV.group + " " +lang

    else:
        IPTV.group = "ZE Inter sport Zik" 
        IPTV.xbmc = IPTV.xbmc.replace(lang,"") + " " +lang

    # print IPTV.group
    return IPTV

def OpenFile(M3UPlaylist):
    inf="can't open file" 

    if os.path.isfile(M3UPlaylist):
        inf = open(M3UPlaylist,'r')
    else:
        try:
            path, filename = os.path.split(M3UPlaylist)
            try:                
                filename = filename.upper().replace(" ","").replace("?","").replace("!","").replace(".M3U","") + ".m3u"
                urllib.urlretrieve(M3UPlaylist , OutStreamDir+filename)
                inf = open(OutStreamDir+filename,'r')
                print "file name ",filename
            except:   
                raise         
                urllib.urlretrieve(M3UPlaylist , "M3UPlaylist.m3u.tmp")
                inf = open("M3UPlaylist.m3u.tmp",'r')

            
        except IOError as e:
            print "ERROR: M3UPlaylist: get file I/O error({0}): {1}".format(e.errno, e.strerror)
            #logger.info("ERROR: M3UPlaylist: get file : I/O error({0}): {1}".format(e.errno, e.strerror))
            return inf

    return inf

def GetM3U_data(M3UPlaylist):
    import re
    print ("start GetM3U_data: playlist: ",M3UPlaylist)
    #logger.info("start GetM3U_data:  playlist: %s ", M3UPlaylist)

    # initialize playlist variables before reading file
    playlist=[]
    if not os.path.exists(OutStreamDir):
                os.makedirs(OutStreamDir)

    inf = OpenFile(M3UPlaylist)

    #title,tvg,tvIcon,radio,group, xbmc, path)
    song=IPTV(None,None,None,None,None,None,None,None,None,None,None,None)

    for line in inf:
        # print "===>>> line",line
        
        line=line.strip()
        if line and not line.startswith('#EXTM3U'):
            lang=""
            
            ##EXTINF:-1 tvg-id="2M" tvg-name="2M" tvg-logo="2M.png" group-title="Maroc"2M
            if line.startswith('#EXTINF:'):
                # print "line:", line

            
                # line = str(line.strip())            
                line=MyFile.supprime_accent(line)

                
                try:
                    rest,title = line.rsplit(',',1)  
                    lang,cname = title.rsplit(':',1) 
                    lang=lang.upper().strip()
                    

                    #title = re.search(r'(?<=tvg-id=").*?(?=")', line).group(0)              
                except:
                    # raise
                    try:                                  
                        rest,title = line.rsplit(',',1)
                    except:
                        try:
                            rest,title = line.rsplit('#EXTINF:-1',1)
                        except:
                            title=line.replace("#extinf:-1",'').split()
                    cname=title
                                

                title = re.sub(r"\[.+?\]", "", title)
                title = title.upper().strip() 
                

                try: 
                    tvg = re.search(r'(?<=tvg-name=").*?(?=")', line).group(0).strip()
                except:
                    tvg =''
                try: 
                    tvIcon = re.search(r'(?<=tvg-logo=").*?(?=")', line).group(0)
                except:
                    tvIcon =''
                
                try: 
                    radio = re.search(r'(?<=radio=").*?(?=")', line).group(0)
                except:
                    radio =''
                
                try: 
                    group = re.search(r'(?<=group-title=").*?(?=")', line).group(0)
                except:
                    group =''

                xbmc=cname.replace("HD","").strip().upper()
               
                try:
                    group,lang = group.rsplit(' ',1) 
                    lang=lang.upper().strip()
                except:
                    pass
            
                song=IPTV(title,tvg,tvIcon,radio,group.upper(),xbmc,None,None,None,None,None,lang)
            
            else:
                song.path=line
                playlist.append(song)
                # reset the song variable so it doesn't use the same EXTINF more than once
                song=IPTV(None,None,None,None,None,None,None,None,None,None,None,None)

    inf.close()

    # for IPTVT in playlist:
    #     print (IPTVT.title, IPTVT.lang, IPTVT.xbmc, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path)

        # self.title = title
        # self.tvg = tvg
        # self.tvIcon = tvIcon
        # self.radio = radio
        # self.group = group
        # self.xbmc = xbmc
        # self.path = path
        # self.calias = calias
        # self.state = state        
        # self.SiteEPG = SiteEPG
        # self.site_id = site_id
        # self.lang = lang
      
    return playlist

def GetM3U_dataOld(M3UPlaylist):
    import re
    print ("start GetM3U_data: playlist: ",M3UPlaylist)
    #logger.info("start GetM3U_data:  playlist: %s ", M3UPlaylist)

    # initialize playlist variables before reading file
    playlist=[]
    if not os.path.exists(OutStreamDir):
                os.makedirs(OutStreamDir)

    if os.path.isfile(M3UPlaylist):
        inf = open(M3UPlaylist,'r')
    else:
        try:
            path, filename = os.path.split(M3UPlaylist)
            try:                
                filename = filename.upper().replace(" ","").replace("?","").replace("!","").replace(".M3U","") + ".m3u"
                urllib.urlretrieve(M3UPlaylist , OutStreamDir+filename)
                inf = open(OutStreamDir+filename,'r')
                print "file name ",filename
            except:   
                raise         
                urllib.urlretrieve(M3UPlaylist , "M3UPlaylist.m3u.tmp")
                inf = open("M3UPlaylist.m3u.tmp",'r')

            
        except IOError as e:
            print "ERROR: M3UPlaylist: get file I/O error({0}): {1}".format(e.errno, e.strerror)
            #logger.info("ERROR: M3UPlaylist: get file : I/O error({0}): {1}".format(e.errno, e.strerror))
            return playlist 
 


    #title,tvg,tvIcon,radio,group, xbmc, path)
    song=IPTV(None,None,None,None,None,None,None,None,None,None,None,None)

    for line in inf:
        # print "===>>> line",line
        
        line=line.strip()
        if line and not line.startswith('#EXTM3U'):
            lang=""
            
            ##EXTINF:-1 tvg-id="2M" tvg-name="2M" tvg-logo="2M.png" group-title="Maroc"2M
            if line.startswith('#EXTINF:'):

            
                # line = str(line.strip())            
                line=MyFile.supprime_accent(line)

                
                try:
                    rest,title = line.rsplit(',',1)  
                    lang,cname = title.rsplit(':',1) 
                    lang=lang.upper().strip()
                    

                    #title = re.search(r'(?<=tvg-id=").*?(?=")', line).group(0)              
                except:
                    # raise
                    try:                                  
                        rest,title = line.rsplit(',',1)
                    except:
                        try:
                            rest,title = line.rsplit('#EXTINF:-1',1)
                        except:
                            title=line.replace("#extinf:-1",'').split()
                    cname=title
                                

                title = re.sub(r"\[.+?\]", "", title)
                title = title.upper().strip()            

                try: 
                    tvg = re.search(r'(?<=tvg-name=").*?(?=")', line).group(0).strip()
                except:
                    tvg =''
                try: 
                    tvIcon = re.search(r'(?<=tvg-logo=").*?(?=")', line).group(0)
                except:
                    tvIcon =''
                
                try: 
                    radio = re.search(r'(?<=radio=").*?(?=")', line).group(0)
                except:
                    radio =''
                
                try: 
                    group = re.search(r'(?<=group-title=").*?(?=")', line).group(0)
                except:
                    group =''

                xbmc=cname.replace("HD","").strip().upper()
               
                try:
                    group,lang = group.rsplit(' ',1) 
                    lang=lang.upper().strip()
                except:
                    pass
            
                song=IPTV(title,tvg,tvIcon,radio,group.upper(),xbmc,None,None,None,None,None,lang)
            
            else:
                song.path=line
                playlist.append(song)
                # reset the song variable so it doesn't use the same EXTINF more than once
                song=IPTV(None,None,None,None,None,None,None,None,None,None,None,None)

    inf.close()

    # for IPTVT in playlist:
    #     print (IPTVT.title, IPTVT.lang, IPTVT.xbmc, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path)

        # self.title = title
        # self.tvg = tvg
        # self.tvIcon = tvIcon
        # self.radio = radio
        # self.group = group
        # self.xbmc = xbmc
        # self.path = path
        # self.calias = calias
        # self.state = state        
        # self.SiteEPG = SiteEPG
        # self.site_id = site_id
        # self.lang = lang
      
    return playlist

def IsFavoriteLang(lang):
    # print "IsFavoriteLang",(lang)

    if lang=="AR" or lang=="FR" or lang=="" :
        return True


    return False

def IsFavorite(IPTV):
    
    if IsFavoriteLang(IPTV.lang) or "SPORT" in IPTV.title.upper() or "MUSIC" in IPTV.title.upper():
        return True

    return False

def GeneratePlaylistOutputs(Playlist,PlaylistFile,):
    print ">>>>> start MiseEnForme", PlaylistFile,
    import operator 
          

    PlaylistForma = sorted(Playlist, key=getKeyTvg)
    PlaylistForma = sorted(PlaylistForma, key=getKey)

 
    Cleanplaylist = ''
    CleanplaylistUnkn = ''
    EpgXml =''
    EpgXmlMissing=""
    global_header = "#EXTM3U\n"

    Cleanplaylist += global_header
    CleanplaylistUnkn += global_header
    

    DupLess = []
    DupLessPath = []
    DupLessEPG = []
    for IPTVT in PlaylistForma:
        # print "IPTV",(IPTVT.title, IPTVT.tvg, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path, IPTVT.SiteEPG, IPTVT.lang)
          
        if IPTVT.path not in DupLessPath:
            DupLessPath.append(IPTVT.path)
            # print "GeneratePlaylistOutputs: IPTV",(IPTVT.title, IPTVT.group, IPTVT.lang)

            channel_header = '#EXTINF:-1 tvg-id="%s" tvg-name="%s" tvg-logo="%s" radio="%s"  group-title="%s",%s\n' \
                    % (IPTVT.title, IPTVT.tvg , IPTVT.tvIcon, IPTVT.radio, IPTVT.group.upper() , IPTVT.xbmc)
            # print "channel_header", channel_header
            Cleanplaylist += channel_header
            Cleanplaylist += IPTVT.path + '\n'+'\n'

              
    f = open(PlaylistFile, "w")
    f.write(Cleanplaylist)
    f.close()

        
    return

def ParseDataBase(database,playlist):

    print "\n >>>>>>>>>>>> start ParseDataBase ... <<<<", datetime.datetime.now().time()
    IPTVFound = 0

    group = ""
    radio = ""

    playlistTrie = ''
    Cleanplaylist = ''
    CleanplaylistUnkn = ''
    CleanplaylistKO = ''

    IPTV_DATA = []
    IPTV_DATAKO = []
    IPTV_UNKNOWN = []

    print "database",database
    rootData = ET.parse(database, parser=ET.XMLParser(encoding="utf-8" ))
    rootChannels=rootData.find('channels')

    # 'name':("logo",'other')
    VODDB={}



    DupLessPath = []
    for IPTV in playlist:
        IPTVFound = 0
        favorite = False

        if IPTV.title != None: #Title not empty
            imageurl = ""  
            print "souf1: IPTV.title", IPTV.title, MyFile.purge(IPTV.title,IPTV.lang) 
            IPTV.path=IPTV.path.replace("|User-Agent=Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/48.0.2564.116 Chrome/48.0.2564.116 Safari/537.36","")
        
            # print "IsFavoriteLang(IPTV.lang)",IPTV.title , IPTV.lang, IsFavoriteLang(IPTV.lang) 
            favorite=IsFavorite(IPTV)
            if (IPTV.path not in DupLessPath) and favorite:  # first occurence            
                # print "\n IPTV.title", MyFile.purge(IPTV.title,IPTV.lang)
                if IPTV.group=="":
                    if ("/movie/" not in IPTV.path.lower()):
                        DupLessPath.append(IPTV.path)
                        state, radio = True, "TV"
                    
                        IPTVFound = 0  
                        for channel in rootChannels.findall('channel'):  
                            IPTV.state = "OK"  


                            # parse database  
                            # print "\nIPTV.title",IPTV.title
                            for calias in channel.findall('calias'): 
                                # if calias.text != None:
                                #     print "     calias.text ",MyFile.purge(calias.text.encode('utf-8'),"")
                                if calias.text != None and (MyFile.purge(IPTV.title,IPTV.lang) == MyFile.purge(calias.text.encode('utf-8'),"")):                                
                                    IPTVFound = 1
                                    break
                 
                            if IPTVFound == 1: 
                                # print "found"
                                
                                IPTV.xbmc=(channel.find('cname').text.encode('utf-8'))
                                assignedcategory = channel.find('assignedcategory')
                                IPTV.group = assignedcategory.find('category').text.upper() 
                                # IPTV.group=IPTV.group+" "+IPTVT.lang.upper()
                                try:
                                    imageurl = channel.find('imageurl').text  
                                except:
                                    pass   
                                    # raise
      
                                print "\n goup NULL, found IPTV.title", IPTV.title, " >>> group",IPTV.group + " "+ IPTV.lang 
                                # print "IPTV.imageurl", imageurl
                          
                                break


                          # IPTV not founded in database => create playlist using IPTV info             
                    
                        if IPTVFound == 0:
                            # print "not found", 
                            IPTV.xbmc= IPTV.xbmc.strip()
                            IPTV.group==IPTV.lang.upper()                            

                        # IPTV.tvIcon = RemoteLogoDir+IPTV.xbmc.replace(" ","_")+".png"
                        if imageurl=="":
                            imageurl=MyImage.GetImage(IPTV.xbmc)   
                            IPTV.title=IPTV.title +"*"               
                            

                        IPTV.tvIcon = imageurl

                        # add defintion indication to channel name
                        IPTV=RenameChannelName(IPTV)

                        if IPTV.radio == '':
                            if radio == 'RADIO':
                                IPTV.radio = "true"
                            else:
                                IPTV.radio = "false"


                        IPTV=RenameGroup(IPTV,IPTV.lang,favorite)    
                        IPTV_DATA.append(IPTV)

                    else:
                        # print IPTV.title, "is a VOD"
                        break
                else:
                    # print "already exist with data: ", IPTV.title
                    IPTV=RenameGroup(IPTV,IPTV.lang,favorite)    
                    IPTV_DATA.append(IPTV)

            else:
                IPTV=RenameGroup(IPTV,IPTV.lang,favorite)   
                IPTV_DATAKO.append(IPTV)
            

    print " >>>>>>>>>>>> END ParseDataBase ... <<<<", datetime.datetime.now().time()


    return IPTV_DATA, IPTV_DATAKO

def UpdatePlayList(OtmanIPTV,actualPlaylistFile,Reset=False):
    import re, urllib, time
    import os.path


    actualPlaylist=[]
    OtmanIPTVPlaylist=[]
    NewPlaylist=[]
    VOD=[]

    if not Reset and os.path.isfile(actualPlaylistFile):
        actualPlaylist += GetM3U_data(actualPlaylistFile)

    path, filename = os.path.split(OtmanIPTV)
    OtmanIPTVfile=TmpDir+"OtmanIPTV.m3u"

    try: # some connection issue
        urllib.urlretrieve(OtmanIPTV , OtmanIPTVfile)
    except:
        print "connection issue, retray in 2S ... "
        time.sleep(2)

    OtmanIPTVPlaylist += GetM3U_data(OtmanIPTVfile)
    # OtmanIPTVPlaylist += iptv.GetM3U_data(OtmanIPTVfile)

    for IPTVo in OtmanIPTVPlaylist:
        # print "IPTVo",IPTVo.title
        exist=False
        if "/movie/" in IPTVo.path:
            VOD.append(IPTVo)
            # break 
        else:
            for IPTVa in actualPlaylist:
                if IPTVa.path==IPTVo.path:
                    exist=True
                    NewPlaylist.append(IPTVa)
            if exist==False:
                # print ">>> New:" ,IPTVo.title
                NewPlaylist.append(IPTVo)


    return NewPlaylist, VOD

def ParsJason(Jsonlocal):
    import urllib   
    import json
    from pprint import pprint

    with open(Jsonlocal) as data_file:    
        data = json.load(data_file)

    pprint(data)  
    print "======================="

    for i in data:
        print "======================="
        try:
            print "i", i
            print "data[i]", i["Title"].encode("utf-8")
        except:
            print "exception"
            raise

        print "======================="
 

    return

def UpdateJason(VODPlaylistFile):
    import urllib   
    import json
    from pprint import pprint
    import os.path

    VODFRs=[]  
    VODARs=[]
    actualPlaylist=[] 

    actualPlaylist += GetM3U_data(VODPlaylistFile)

    if os.path.isfile(JsonlocalEN):
        with open(JsonlocalEN) as data_file:    
            dataFR = json.load(data_file)
    else:
        dataFR=[]


    if os.path.isfile(JsonlocalAR):
        with open(JsonlocalAR) as data_file:    
            dataAR = json.load(data_file)
    else:
        dataAR=[]

    for IPTVa in actualPlaylist:
        exist=False
        encoding = cchardet.detect(IPTVa.title)['encoding']
        # print "encoding", encoding
        if encoding=="ASCII":
            langue="FR"
            data=dataFR
        else:
            langue="AR"
            data=dataAR



        for i in data:
            if IPTVa.path==i["link"].encode("utf-8"):
                exist=True
                # print "data[i] already exist", i["Title"].encode("utf-8")
                if langue=="FR":
                    VODFRs.append(i)
                else:
                    VODARs.append(i)
                break
        if exist==False:
            print ">>> New:" ,IPTVa.title            
            infoLabels=MyTmdb.GetInfo(IPTVa.title, IPTVa.path,langue)
            if langue=="FR":
                VODFRs.append(infoLabels)
            else:
                VODARs.append(infoLabels)
            

    newVODFRs = sorted(VODFRs, key=lambda k: k['Year'], reverse=True) 
    newVODARs = sorted(VODARs, key=lambda k: k['Year'], reverse=True) 

    import json
    with open(JsonlocalEN, 'w') as fout:
        json.dump(newVODFRs, fout, indent=4)
    import json
    with open(JsonlocalAR, 'w') as fout:
        json.dump(newVODARs, fout, indent=4)



    return

def VODJson(VODFile,JsonlocalAR,JsonlocalEN):
    VOD=[]  
    VODsAR=[]
    VODsEN=[]


    VOD += GetM3U_data(VODFile)

    for IPTVT in VOD:
        # print "***", IPTVT
        # print "MYIPTV", (IPTVT.title, IPTVT.tvg, IPTVT.SiteEPG, IPTVT.site_id, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path)
        # shows.append( [channel,IPTVT.path, IPTVT.title , IPTVT.tvIcon,'shows'] )
        # print "MYIPTV", IPTVT.title
        # if IPTVT.group=="VOD AR":

        encoding = cchardet.detect(IPTVT.title)['encoding']
        # print "encoding", encoding
        if encoding=="ASCII":
            langue="FR"
        else:
            langue="AR"
        try:
            infoLabels=MyTmdb.GetInfo(IPTVT.title, IPTVT.path,langue)

            if langue=="AR":                
                VODsAR.append(infoLabels)
            else:                
                VODsEN.append(infoLabels)
        except:
            raise
            print "exception list_vod!!!! >>>>>>> ",IPTVT.title
            pass

    # print VODs
    newVODsAR = sorted(VODsAR, key=lambda k: k['Year'], reverse=True) 
    newVODsEN = sorted(VODsEN, key=lambda k: k['Year'], reverse=True) 
    # print newVODs    
  
    import json
    with open(JsonlocalAR, 'w') as fout:
        json.dump(newVODsAR, fout, indent=4)
    with open(JsonlocalEN, 'w') as fout:
        json.dump(newVODsEN, fout, indent=4)

    return

def main(OtmanIPTV,PlaylistFile):
    import MyApi 
    print (" *****start M3U Playlist creating at: "), 
    starttime=datetime.datetime.now()

    NewPlaylist, VOD=UpdatePlayList(OtmanIPTV,PlaylistFile,Reset=False)
    
    VODsAR=[]
    VODsEN=[]


    IPTV_DATA, IPTV_DATAKO=ParseDataBase(ChannelDataBase,NewPlaylist)
    # PrintM3UPlaylist(IPTV_DATA)
    GeneratePlaylistOutputs(IPTV_DATA,PlaylistFileTmp)     
    shutil.move(PlaylistFileTmp,PlaylistFile)
    GeneratePlaylistOutputs(IPTV_DATAKO,PlaylistFileTmp)     
    shutil.move(PlaylistFileTmp,PlaylistFileUnknown)

    GeneratePlaylistOutputs(VOD,PlaylistFileTmp)     
    shutil.move(PlaylistFileTmp,VODFile)


    # create users playlist
    patern=['soufone2','R3px9OfXWs']
    users={
        "khattab": ('soufone','zPNIC2sPNT'),
        "Tiznit": ('soufone0','QXiy5FMtI2')
        }
    CreateUsersPlaylist(patern,users)

    endtime=datetime.datetime.now()

    print "*** >>>>>>>>>> end M3U Playlist creating in: <<<<<<<<<<<< ** *", endtime-starttime
    return IPTV_DATA, IPTV_DATAKO


if __name__ == '__main__':
    main(OtmanIPTV,PlaylistFile)

