# -*- coding: utf-8 -*-

def detect(strng):

	result={'confidence': 1.0, 'encoding': u'ASCII'}
    
	return result
