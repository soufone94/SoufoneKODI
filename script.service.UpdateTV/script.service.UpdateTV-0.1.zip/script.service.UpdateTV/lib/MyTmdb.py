# -*- coding: utf-8 -*-



# class IPTV():
#     def __init__(self, title,tvg,tvIcon,radio,group,xbmc, path,calias,state,SiteEPG,site_id):
#         self.title = title
#         self.tvg = tvg
#         self.tvIcon = tvIcon
#         self.radio = radio
#         self.group = group
#         self.xbmc = xbmc
#         self.path = path
#         self.calias = calias
#         self.state = state        
#         self.SiteEPG = SiteEPG
#         self.site_id = site_id

try:
    from bs4 import BeautifulSoup
except:
    print "souf1 can't import bs4"
    from BeautifulSoup import BeautifulSoup
from schism_net import OPEN_URL
from common import  random_agent

from MyApi import *

# https://pypi.python.org/pypi/tmdb3/

tmdb3Exist=False
try:
    import tmdb3
    tmdb3Exist=True
except ImportError as err:
    print "souf1 err", err

except:
    install("tmdb3")
    import tmdb3
    tmdb3Exist=True

if tmdb3Exist:
    from tmdb3 import set_key
    set_key(KEY)

    from tmdb3 import set_cache
    set_cache('null')
    # set_cache(filename='/full/path/to/cache') # the 'file' engine is assumed
    # set_cache(filename='tmdb3.cache') # relative paths are put in /tmp
    # set_cache(engine='file', filename='~/.tmdb3cache')


def VODFormatName(film):
    # print "vod format", film
    import re
    saison=""
    if len(film.rsplit(None, 1))>1:
        film=film.rsplit(None, 1)[-0]+" "+film.rsplit(None, 1)[-1].replace("S","")

    # try:
    #     saison = re.search(r"S(?P<saison>\d+)?", film).group('saison')
    #     print "saison", saison
    # except:
    #     pass

    # try:
    #     # film= re.sub(" S[0-9]",' PART ',film)+ saison
        
    #     film= re.sub(" S[0-9]",' ',film)+ saison
    # except:
    #     pass

    return film


def nameformat(VODname):

    s=""
    for c in VODname:
        s=s+hex(ord(c)).replace("0x","%")
        VODname=s
    VODname=str(VODname).replace(" ","%20") #.encode('utf-8')

    return VODname



KEY = 'd2e44b2a5548806311f950bd87e15e7f'
VODname="Kung Fu Yoga"
VODname="MBC1"
# VODname="الرسالة"



# VODname=nameformat(VODname)




# +++ ELCENIMA 

def getDataElcinema(infoLink):
    # print ">> getDataElcinema", infoLink
    # infoLink="http://www.elcinema.com/work/1011627/"
    import urllib2
    date=""
    Plote=""
    img=""

    req = urllib2.Request(infoLink)
    # print "req",req
    req.add_header('User-agent', 'Mozilla 5.10')
    html=urllib2.urlopen(req).read()

    # soup = BeautifulSoup(html, 'html.parser')

    headers = {'User-Agent': random_agent()}
    html = OPEN_URL(infoLink)
    soup = BeautifulSoup(html.content)


    spans=soup.find_all("span", {"class": "left"})
    for i in spans[1].contents:
        date=i.encode('utf-8').replace('(','').replace(')','').replace("\xc2\xa0", " ").strip()

    

    # As=soup.find_all("a")
    # for i in As:
    #     try:
    #         print "i", i
    #         if "/release_year/" in str(i.get("href").encode('utf-8')):
    #             date=str(i.contents[0])
    #             print "date",date
    #             break
    #     except AttributeError as err:
    #         print "AttributeError: ", err
    #         raise
    #         pass


    ps=soup.find_all("p")     
    for p in ps:
        Plote=p.contents[0].encode('utf-8')
        break


    Is=soup.find_all("img")
    string="http://photo.elcinema.com.s3.amazonaws.com/uploads/"     
    for i in Is:
        if string in i.get("src").encode('utf-8'):
            img=i.get("src").encode('utf-8')
            
            break

    return date,Plote,img



def GetInfo_Elcinema(VODname, path,langue):
    # VODname=VODname.encode('utf-8')
    print " > GetInfo_Elcinema: "
    if langue=="AR":
        VODname=nameformat(VODname)

    langue=""
    image="image"
    date=""
    Plote=""
    infoLabels={ 
        "Title": VODname,
        "Plot":Plote,
        "Aired":"date",
        "Duration": "duration",
        "Year":date,
        "trailers":"trailers", 
        "link":path, 
        "image":image
        } 
    
    # print "encode VODname ",VODname
    import re  
    import urllib2

    urlbase="http://www.elcinema.com/ar/search/?q="


    VODFiche=urlbase+VODname.replace(" ","%20").decode('utf-8')
    try:
        # print "VODFiche", VODFiche


        req = urllib2.Request(VODFiche)
        # print "req",req
        req.add_header('User-agent', 'Mozilla 5.10')
        html=urllib2.urlopen(req).read()
        
        # print "html",html


        soup = BeautifulSoup(html, 'html.parser')

        As=soup.find_all("a")
        for i in As:
            # print i
            try:
                # print 'i.get("href")', i.get("href")
                if ("/work/" in i.get("href")) and ("search" not in i.get("href")):
                    infoLink="http://www.elcinema.com"+str(i.get("href").encode('utf-8'))
                    date,Plote,image=getDataElcinema(infoLink)    
                    # print "date,Plote,image", date,Plote,image           
                    break

            except TypeError as err:            
                # print ">>>>>>>> Error0: GetVOD_Pster:  ",VODname ,'=> ', VODFiche, "=> HTTPError:", err
                # raise
                pass 

            except: 
                print "error 301"
                raise
                pass
            # print "link", p.find("a").get("href").encode('utf-8')

        # print "infoLink", infoLink


    except urllib2.HTTPError as err:
        if err.code == 500:
            print ">>>>>>>> Error 500: GetVOD_Pster:  ",VODname ,'=> ', VODFiche, "=> HTTPError:", err.code 
            # raise     
        else:
            print  ">>>>>>>> Error: GetVOD_Pster:  ",VODname ,'=> ', VODFiche, "=> HTTPError:", err.code 
            raise
            pass
    except:
        ">>>>>>>> Error: GetVOD_Pster: lingne 168"
        raise
        pass

    infoLabels={ 
        "Title": VODname,
        "Plot":Plote,
        "Aired":"date",
        "Duration": "duration",
        "Year":date,
        "trailers":"trailers", 
        "link":path, 
        "image":image
        } 

    # print "img",img

    # return infoLabels
    return image,date,Plote
# --- ELCENIMA 

def GetInfo(VODname, path, langue="FR"):
    # VODname="الرسالة"
    print "GetInfo", VODname



    Title=VODname
    Plote="Plot"
    date="date"
    genres="genre"
    languages=""
    countries=""
    image="image"

    VODnameNew=VODFormatName(VODname)
    print " > new name", VODname

    if tmdb3Exist:
            try:
                from tmdb3 import get_locale, set_locale
                set_locale(langue, langue)

                from tmdb3 import searchMovie
                from tmdb3 import searchMovieWithYear

                if len(searchMovie(VODname))>0:
                    res=searchMovie(VODname)
                elif len(list(searchMovieWithYear(VODnameNew)))>0:
                    res=list(searchMovieWithYear(VODnameNew))
                else:
                    res=list(searchMovieWithYear(VODname))


                # res = searchMovie(VODname)
                # res = searchMovieWithYear(VODname)
                print " > len(res)",len(res)
                if len(res)>0:
                # if 1==1:
                    # VODid=res[0].id
                    # print "title", res[0].title 
                    # print "overview", res[0].overview 
                    # print "releasedate  ", res[0].releasedate   
                    # print "poster   ", res[0].poster.geturl()   
                    # print "genres   ", res[0].genres    
                    # print "studios   ", res[0].studios   
                    # print "languages    ", res[0].languages     
                    # print "countries    ", res[0].countries     

                    # from tmdb3 import Movie
                    # movie = Movie(VODid)
                    # try: 
                    #     print "youtube_trailers", movie.youtube_trailers[0].geturl()
                    # except:
                    #     print "youtube_trailers: can't get traillers"

                    Title=res[0].title
                    Plote=res[0].overview.encode("utf-8") 
                    date=str(res[0].releasedate).encode('utf-8').strip()

                    try:        
                        genre=str(res[0].genres)
                    except:
                        genre=""
                        pass

                    for c in res[0].countries:
                        countries=countries + str(c).replace(">","").replace("<","")+", "

                    for l in res[0].languages:
                        # print "l",l
                        languages=languages + str(l).replace(">","").replace("<","").replace("Language","") +", "


                    if (res[0].poster):
                        image=res[0].poster.geturl() 
                    else:
                        print "image=res[0].poster.geturl()  fald"
                        # raise
                        # image,date,Plote=GetInfo_Elcinema(VODname, path,langue)  


                else:
                    image,date,Plote=GetInfo_Elcinema(VODname, path,langue)    

            except KeyError as e: 
                print "ERROR GetInfo: KeyError ",e
                image,date,Plote=GetInfo_Elcinema(VODname, path,langue)  
                # raise
                pass 

            except:
                print " ERROR GetInfo: lgne 272", VODname
                image,date,Plote=GetInfo_Elcinema(VODname, path,langue)  
                # raise
                pass
    else:
        image,date,Plote=GetInfo_Elcinema(VODname, path,langue) 
            # print "languages",languages


        # countries=str(res[0].countries) 


    # print "image", image

    infoLabels={ 
        "Title": Title ,
        "Plot":Plote,
        "Aired":"date",
        "Duration": "duration",
        "Year":date,
        "trailers":"trailers", 
        "link":path, 
        "image":image,
        "genres":genres,
        "languages":languages,
        "countries": countries
        } 
 
    print "     >> date",date
    return infoLabels

# print GetInfo(VODname, "path")

# from tmdb3 import searchMovieWithYear
# # list(searchMovieWithYear('Star Wars (1977)'))
# print (searchMovieWithYear(VODname))

# from tmdb3 import Movie
# p = Movie(VODid).poster

# print "Title", Movie(VODid).originaltitle
# print "Pster", p.geturl()



# print movie.apple_trailers[0].geturl()

#######################################

# def GetInfo_ElcinemaOld(VODname, path,langue):
#     # VODname=VODname.encode('utf-8')
#     # print " > GetInfo_Elcinema: "
#     if langue=="AR":
#         VODname=nameformat(VODname)

#     langue=""
#     image="image"
#     date=""
#     Plote=""
#     infoLabels={ 
#         "Title": VODname,
#         "Plot":Plote,
#         "Aired":"date",
#         "Duration": "duration",
#         "Year":date,
#         "trailers":"trailers", 
#         "link":path, 
#         "image":image
#         } 
    
#     # print "encode VODname ",VODname
#     import re  
#     import urllib2

#     urlbase="http://www.elcinema.com/ar/search/?q="


#     VODFiche=urlbase+VODname.replace(" ","%20").decode('utf-8')
#     try:
#         # print "VODFiche", VODFiche


#         req = urllib2.Request(VODFiche)
#         # print "req",req
#         req.add_header('User-agent', 'Mozilla 5.10')
#         html=urllib2.urlopen(req).read()
        
#         # print "html",html

#         from bs4 import BeautifulSoup
#         soup = BeautifulSoup(html, 'html.parser')

#         divs=soup.find_all("div", {"class": "thumbnail-wrapper"})

#         try:
#             image=str(divs[0].find("img").get("src").encode('utf-8')) 


#             As=divs[0].find_all("a")
#             for i in As:
#                 if "/work/" in str(i.get("href").encode('utf-8')):
#                     infoLink="http://www.elcinema.com"+str(i.get("href").encode('utf-8'))
#                     date,Plote=getDataElcinema(infoLink)
#                     break 
#         except:
#             raise
#             pass

#         # print "infoLink", infoLink


#     except urllib2.HTTPError as err:
#         if err.code == 500:
#             print ">>>>>>>> Error: GetVOD_Pster:  ",VODname ,'=> ', VODFiche, "=> HTTPError:", err.code 
#             raise     
#         else:
#             print  ">>>>>>>> Error: GetVOD_Pster:  ",VODname ,'=> ', VODFiche, "=> HTTPError:", err.code 
#             raise
#             pass
#     except:
#         ">>>>>>>> Error: GetVOD_Pster: lingne 168"
#         raise
#         pass

#     infoLabels={ 
#         "Title": VODname,
#         "Plot":Plote,
#         "Aired":"date",
#         "Duration": "duration",
#         "Year":date,
#         "trailers":"trailers", 
#         "link":path, 
#         "image":image
#         } 

#     # print "img",img

#     # return infoLabels
#     return image,date,Plote

# def getDataElcinemaOld(infoLink):
#     # print ">> getDataElcinema", infoLink
#     import urllib2
#     date=""
#     Plote=""

#     req = urllib2.Request(infoLink)
#     # print "req",req
#     req.add_header('User-agent', 'Mozilla 5.10')
#     html=urllib2.urlopen(req).read()

#     # print "html",html

#     from bs4 import BeautifulSoup
#     soup = BeautifulSoup(html, 'html.parser')

#     As=soup.find_all("a")
#     for i in As:
#         try:
#             if "/release_year/" in str(i.get("href").encode('utf-8')):
#                 date=str(i.contents[0])
#                 break
#         except AttributeError as err:
#             # print "AttributeError: ", err
#             # raise
#             pass
#         except:
#             raise
#             pass

#     ps=soup.find_all("p")     
#     for p in ps:
#         Plote=p.contents[0].encode('utf-8')
#         break

#     # print "********* Plote",Plote
#     return date,Plote
