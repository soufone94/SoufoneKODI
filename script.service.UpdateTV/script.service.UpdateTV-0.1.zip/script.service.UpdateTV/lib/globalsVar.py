# -*- coding: utf-8 -*-


import os

import tempfile, ntpath

debug=1 # info
# debug=2 # warrning
# debug=3 # ERROR


GitHubLogoBase="https://raw.githubusercontent.com/soufone94/logos/master/logo/"


TmpDir=tempfile.gettempdir() # prints the current temporary directory

# get workspace from parent directory 
workspace = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir))
resources = workspace+'/resources'
output = workspace + '/output'
OutStreamDir = output + '/streams/'


print "workspace",workspace
print "output", output
print "TmpDir", TmpDir

# Input
StreamList = resources + '/list-m3u.py'
ChannelDataBase = resources+'/MyChannels.xml'

# WebGrabber 
import platform
if platform.system()=='Windows':
	import getpass
	RessourceMergeIni=resources+'/WebGrab/Merge/merge-xmltv.ini'
	WebGrabDir="c:/Users/"+getpass.getuser()+"/AppData/Local/WebGrab+Plus"
	WebGrabMergeIniNew="c:/Users/"+getpass.getuser()+"/AppData/Local/WebGrab+Plus/siteini.user/merge-xmltv.ini"
	logoGitHubLocal="c:/Users/"+getpass.getuser()+"/Documents\GitHub\IPTV\logo/"

else:
	RessourceMergeIni=resources+'/WebGrab/Merge/merge-xmltv.ini'
	WebGrabDir="/home/soufian/.wg++"
	WebGrabMergeIniNew="/home/soufian/.wg++/siteini.user/merge-xmltv.ini"

WebGrabConfigTemplate=workspace+"/resources/WebGrab/WebGrab++.config-template.xml"
WebGrabSiteIniUser=workspace+"/resources/WebGrab/siteini.user"
xmlSiteDir=workspace+"/resources/WebGrab/WebGrabSite/"
xmlSiteFaforite=workspace+"/resources/WebGrab/FavoritesXML.txt"



outputWebgrabber=output + "/webgrab"
WebGrabConfigInstal=WebGrabDir+'/WebGrab++.config.xml'
WebGrabConfig=outputWebgrabber+"/WebGrab++.config.xml"
WebGrabConfig_tmp=TmpDir +'/'+ntpath.basename(WebGrabConfig)
remoteSiteIni="http://www.webgrabplus.com/sites/default/files/download/ini/SiteIniPack_current.zip"
localSiteIni_tmp=TmpDir+'/siteini'




#output 
PlaylistFile= output + "/playlist.m3u"
VODFile= output + "/VOD.m3u"
MyGuide=output + "/guide.xmltv"
outputXMLTV=output + "/xmltv"
PlaylistFileUnknown= output + "/playlist_Unknown.m3u"

JsonlocalAR=output+"/result-AR.json"
JsonlocalEN=output+"/result-EN.json"

#logs
localStreamDir=workspace+"/resources/streams/local/"
logs = output + '/logs'
logfile = logs + '/log.txt'
logos = output + '/logos/'

#tmp file
ChannelDataBaseTmp=TmpDir+'/MyChannels.xml'
MyGuideTmp=TmpDir +'/'+ntpath.basename(MyGuide)
PlaylistFileTmp=TmpDir +'/'+ntpath.basename(PlaylistFile)





# PlaylistFile= output + "/playlist-beta.m3u"
grabberfile= output + "/logs/EPGgrab.xml"
NewChannelLog=output + "/logs/NewChannelLog.log"













# RemoteLogoDir="https://dl.dropboxusercontent.com/u/80638885/XBMC/LIVE_TV/output/logos/"




# #FTV
# FTVresources=workspace+'/resources/ftv/'
# addonINI = output + '/addons.ini'

# #Shahid
# Shahid_channelsLink = "https://raw.githubusercontent.com/Shani-08/ShaniXBMCWork/master/plugin.video.shahidmbcnet/resources/community/Channels.xml"

# ShahidDB =  workspace +"/resources/shahid/Ref/ChannelsSouf.xml"
# XMLoutfile = output + '/SoufUrls.xml'

# #Radio
# radioMaM3U = workspace + "/output/radioma.m3u"
# radioMA_xml_Remote = "http://radioma.ma/radiomaxbmc/radios.xml"
# # radioMA_xml_local = resources+'/radios.xml'

# #Stream
# global_header = '#EXTM3U/n'
# StreamList = resources + '/list-m3u.py'
# # Outputs.StreamList= resources + '/list-m3u.py'


# MyPlaylistUnknown = output + '/playlist_Unknown.m3u'
# MyPlaylistKO = output + '/playlist-KO.m3u'

# #radioma
# radioMA_xml_Remote = "http://radioma.ma/radiomaxbmc/radios.xml"
# radioMA_xml_local = output + '/radioma/radioma.xml'
# radioMaM3U = output + '/radioma/radioma.m3u'

# # grabber Var
# ResetGrabber=True
# grab_template=workspace+"/resources/WebGrab/template.xml"
# grab_out=workspace+"/resources/WebGrab/out.xml"
# WebGrabConfigout=workspace+"/resources/WebGrab/WebGrab++.config-TOP.xml"

