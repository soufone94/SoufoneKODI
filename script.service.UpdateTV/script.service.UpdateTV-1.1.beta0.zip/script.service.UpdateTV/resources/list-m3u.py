# mon guide: http://bit.ly/2uz3TR1
# mon quide .gz: http://bit.ly/2hFCZ7t
#EPGurl="http://iptv-epg.com/d7d-mq2i3s.xml"

# playlist: http://bit.ly/2qanRlH	#soufone2
# playlist Tiznit: http://bit.ly/2q8T2v1	#soufone ae:a7:0b:71:01:06
# Playlist khattab: http://bit.ly/2qhnKRU	#soufone1 24:4b:03:4c:6f:e4
# playlist unknown: http://bit.ly/2oBSPSu

# # 6/12/2017
# http://iptvpro.premium-itv.com:8789/get.php?username=soufTiz&password=Dbvau3JRws&type=m3u_plus&output=ts
# http://iptvpro.premium-itv.com:8789/get.php?username=soufkh&password=TruozWk4Y1&type=m3u_plus&output=ts
# http://iptvpro.premium-itv.com:8789/get.php?username=Souftigmmi&password=8zevdgZc2g&type=m3u_plus&output=ts

# http://electrowazan9.com/get.php?username=soufone2&password=R3px9OfXWs&type=m3u&output=ts


Tiznit http://bit.ly/2D8l8QZ

#OtmanIPTV="http://Electrowazan7.com:7777/get.php?username=soufone2&password=R3px9OfXWs&type=m3u&output=ts"
#khattab OtmanIPTV="http://Electrowazan7.com:7777/get.php?username=soufone&password=zPNIC2sPNT&type=m3u&output=ts"

    # # create users playlist
    # patern=['soufone2','R3px9OfXWs']
    # users={
    #     "khattab": ('soufone','zPNIC2sPNT'),
    #     "Tiznit": ('soufone0','QXiy5FMtI2')
    #     }

#bourzi bc:14:85:65:f1:e3

#mac m8: 2c:8a:72:b4:e3:71
#mac bee: 1a:f5:36:66:67:da
#mac oneplus 94:65:2d:80:83:dc

#=> plugin.video.live.streamspro:
# http://racacaxtv.ga/allfrtv/allfrtvkodi.php?cat=VG91dGVz&amp;country=France&amp;epg=
# http://tinyurl.com/zzj2bg3

#EPG
#http://iptv-epg.com/d7d-mq2i3s.xml
#http://iptv-epg.com/1b55-mq2i3s.m3u

#### TEST ########
# https://www.dropbox.com/s/0a78603iqu43wvv/test.m3u?dl=1
https://www.dropbox.com/s/8bop85mg37i0tex/test.m3u?dl=1
#http://otmanshowiptv.com:7777/get.php?username=soufone2&password=R3px9OfXWs&type=m3u&output=ts 		
