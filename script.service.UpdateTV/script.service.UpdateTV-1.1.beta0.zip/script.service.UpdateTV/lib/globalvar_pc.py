# -*- coding: utf-8 -*-

XBMC=False



import os

import tempfile, ntpath

# debug=0
debug=1 # info
# debug=2 # warrning
# debug=3 # ERROR
LOGWARNING=2

OutDebug=False



# get workspace from parent directory 
workspace = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir))
output = workspace + '/output'
TmpDir=tempfile.gettempdir() # prints the current temporary directory

