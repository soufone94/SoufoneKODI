#!/usr/bin/python
# -*- coding: utf-8 -*-

from globalvar import DEBUGLEVEL


# def notify(message, duration=5000, image="ADDON_ICON", level="LOGDEBUG", sound=True):
def notify(*message, **kwargs ):
    """
    Display a Kodi notification and log the message.

    :type message: str
    :param message: the message to be displayed (and logged).
    :type duration: int
    :param duration: the duration the notification is displayed in milliseconds (defaults to 5000)
    :type image: str
    :param image: the path to the image to be displayed on the notification (defaults to ``icon.png``)
    :type level: int
    :param level: (Optional) the log level (supported values are found at xbmc.LOG...)
    :type sound: bool
    :param sound: (Optional) Whether or not to play a sound with the notification. (defaults to ``True``)
    """
    saved_args = locals()
    # print saved_args
    if DEBUGLEVEL=="LOGDEBUG":
        if saved_args["message"]:
            print saved_args["message"]

def debug(message,debuglevel):
    # debug=1 # info
    # debug=2 # warrning
    # debug=3 # ERROR
    
    if debuglevel>debug:
        print "debug: ",debuglevel, message

    return

# notify("comment ça va?","ça va bien",duration=5000, image="ADDON_ICON", level="LOGDEBUG", sound=True)
# notify("comment ça va?","ça va bien")

