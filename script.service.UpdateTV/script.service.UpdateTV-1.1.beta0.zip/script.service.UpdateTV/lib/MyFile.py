# -*- coding: utf-8 -*-

import globalvar
import os

#Create output directories
def CreateOutputs(workspace):
    # workspace="c:\Users\soufi_000\Dropbox\Public\XBMC\LIVE_TV/"
    print "> CreateOutputs", workspace

    CreateIfNotExiste(globalvar.output)
    CreateIfNotExiste(globalvar.logs)
    CreateIfNotExiste(globalvar.OutStreamDir)

def CreateIfNotExiste(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)

def lreplace(pattern, sub, string):
    import re
    """
    Replaces 'pattern' in 'string' with 'sub' if 'pattern' starts 'string'.
    """
    return re.sub('^%s' % pattern, sub, string)


def purge(name,lang):
    # remove all space, -, _ before comapr channel name
    # print "entry purge",name,lang
        # remove all space, -, _ before comapr channel name
    import unicodedata, re
    purgedname=name.upper().replace(lang+" :","").replace("|"+lang+"|","").strip()

    if lang=="FR":
        purgedname=purgedname.replace(".F","")


    # if "BEIN" in purgedname:
    #     regexBein='(^.*)BEIN ?([A-Z]*) ?([0-9]*) ?([A-Z]*)'

    #     lang, type, num, quality=re.findall(regexBein, purgedname )[0]
    #     purgedname= "BEIN "+type.replace("WAZAN","SPORTS") + num
       
    
    purgedname = purgedname.replace("HD","")
    purgedname = purgedname.replace("SD","")
    purgedname = purgedname.replace("TV","")
    purgedname = purgedname.replace("-LOW","")
    purgedname = purgedname.replace("LOW","")
    purgedname = purgedname.replace("-FULL","")

    # remove 4K in name: bein
    purgedname = purgedname.replace("*4k*6MB","")
    purgedname = purgedname.replace("*"," ")

    # time shift

    purgedname = purgedname.replace(" 1H","")
    purgedname = purgedname.replace(" 2H","")
    purgedname = purgedname.replace(" 3H","")
    purgedname = purgedname.replace(" 6H","")




              

    purgedname = purgedname.replace("&","ET")
    
    purgedname = purgedname.replace("VIP-OSN-","")
    purgedname = purgedname.replace("LO_OSN_","")
    purgedname = purgedname.replace("AR-OSN-","")    
    purgedname = purgedname.replace("OSN_","")  
    purgedname = purgedname.replace("OSN-","")
    purgedname = purgedname.replace("MY","")
    purgedname=lreplace('VIP-','',purgedname)

    if not "FRANCE24" in purgedname:
        purgedname=lreplace('FR-','',purgedname)    
        purgedname=lreplace('AR-','',purgedname)


    purgedname = purgedname.replace(":","")
    purgedname = purgedname.replace("-","")
    purgedname = purgedname.replace("?","")
    purgedname = purgedname.replace("_","")
    purgedname = purgedname.replace(" ","")
    purgedname = purgedname.replace("+","PLUS")
    purgedname = purgedname.replace("(","")
    purgedname = purgedname.replace(")","")
    purgedname = purgedname.replace("/","")
    purgedname = purgedname.replace(".","")
    purgedname = purgedname.replace(".","") 
    purgedname = purgedname.replace("_","")  

    # print "name, purgedname", name, purgedname

    return purgedname