# -*- coding: utf-8 -*-

import globalvar, utils

def PurgeOutputs(TmpDir,OutDir):
    utils.notify(">> PurgeOutputs:")
    utils.notify("TmpDir: ")
    utils.notify(TmpDir)
    utils.notify("OutDir: ")
    utils.notify(OutDir)

    import os
    from os import listdir
    from os.path import isfile, join
    filesToRemove = [join(TmpDir, f) for f in listdir(TmpDir) if isfile(join(TmpDir, f))]
    filesToRemove += [join(OutDir, f) for f in listdir(OutDir) if isfile(join(OutDir, f))]

    for f in filesToRemove:
        if "m3u" in f and isfile(f):     
            utils.notify(f)     
            os.remove(f)

    utils.notify("<< PurgeOutputs:")
    return 

def main():

    PurgeOutputs(globalvar.TmpDir,globalvar.OutDir)

    return

if __name__ == '__main__':
    main()