#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys  

reload(sys)  
sys.setdefaultencoding('utf8')


import lib.purge as purge

def Job(Reset=True):
    import lib.globalvar as globalvar
    import lib.iptv as iptv
    import lib.utils as utils

    from lib.iptv import Updater
    updater = Updater()

    import json
    import xml.etree.ElementTree as ET

    from lib.reset_exclusions import *
    from lib.utils import *
    from lib.viewer import *

    import os
    from shutil import copyfile
    os.chdir(os.getcwd())

    create_iptv=globalvar.ADDON.getSetting('create_iptv')
    create_vod=globalvar.ADDON.getSetting('create_vod')
    advancedsettings=globalvar.ADDON.getSetting('advancedsettings')

    if not os.path.exists(globalvar.CACHE_DIR):
        os.makedirs(globalvar.CACHE_DIR, mode=0777)
        updater = Updater()

  
    utils.notify("start ")

    utils.notify("create_iptv "+create_iptv)
    utils.notify("create_vod "+create_vod)
    utils.notify(globalvar.OutDir)

    IptvUpdater=False
    lenNew=0

    ##################  update system ########
    updater.CreateOutputs()

    if advancedsettings=="true":
        if not os.path.isfile(globalvar.AdvancedXML):          
            copyfile(globalvar.MyAdvanceXML, globalvar.AdvancedXML)


    ######################  update TV ######################################

    if create_iptv=="true" or create_vod=="true":  
        utils.notify("satrt TV update ... ")  
        NewPlaylist,playlistKO,IptvUpdater,lenNew=iptv.main(globalvar.PlaylistFile,Reset,create_iptv,create_vod)  

    if create_iptv=="true" and IptvUpdater==True: 
        utils.notify("IPTVSimple stings updating ... ")    
        updater.UpdateSimpleIPTVSettings(globalvar.PlaylistFile)



    ######################  update VOD ######################################

    if create_vod=="true" and IptvUpdater==True:        
        utils.notify("start VOD update ... ")
        # if os.path.isfile(globalvar.VODFile):        
        #     copyfile(globalvar.VODFile, globalvar.VODFile+'.back')
            
        updater.UpdateVOD()
        
        # Create Media Source
        updater.UpdateSourceFile(globalvar.SourcesXML, "RemoteFilmAR",globalvar.OutDir+'/films/ar/')
        updater.UpdateSourceFile(globalvar.SourcesXML, "RemoteFilmFR",globalvar.OutDir+'/films/fr/')
        updater.UpdateSourceFile(globalvar.SourcesXML, "RemoteFilmEN",globalvar.OutDir+'/films/en/')
        updater.UpdateSourceFile(globalvar.SourcesXML, "RemoteSeries",globalvar.OutDir+'/series/')

        # Update and Clean Library
        utils.notify("UpdateLibrary ")
        xbmc.executebuiltin("xbmc.UpdateLibrary(video)")
        utils.notify("CleanLibrary ")
        xbmc.executebuiltin("xbmc.CleanLibrary(video)")

        

    utils.notify("end Job ")

    return 

if __name__ == "__main__":

    if len(sys.argv) > 1 and sys.argv[1] == "purge":        
        purge.main()

    else:    
        Job()





    




