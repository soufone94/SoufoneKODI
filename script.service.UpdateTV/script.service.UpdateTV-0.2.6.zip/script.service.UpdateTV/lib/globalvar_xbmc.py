# -*- coding: utf-8 -*-

XBMC=True

import xbmc
import xbmcaddon

import os

LOGWARNING=xbmc.LOGWARNING


ADDON_NAME = 'script.service.UpdateTV'
ADDON = xbmcaddon.Addon(ADDON_NAME)
SETTINGS = ADDON
LANGUAGE = ADDON.getLocalizedString
ADDON_DIR = ADDON.getAddonInfo("path")
ADDON_DATA = xbmc.translatePath(ADDON.getAddonInfo('profile'))
VERSION = ADDON.getAddonInfo("version")
RESOURCES = os.path.join(ADDON_DIR, "resources")
CHANNELS_DIR = os.path.join(RESOURCES, "lib", "channels")
MEDIA = os.path.join(RESOURCES, "media")
ADDON_DATA = xbmc.translatePath(
    "special://profile/addon_data/%s/" % ADDON_NAME)
FAVOURITES_FILE = os.path.join(ADDON_DATA, "favourites.json")

SourcesXML=xbmc.translatePath("special://profile/sources.xml")
AdvancedXML=xbmc.translatePath("special://profile/advancedsettings.xml")
MyAdvanceXML=os.path.join(RESOURCES, "advancedsettings.xml")

#out dir
OutStreamDir = os.path.join(ADDON_DATA, "streams") 
CACHE_DIR = os.path.join(ADDON_DATA, "RemoteFilms")
PlaylistFile= os.path.join(CACHE_DIR, "playlist.m3u")
PlaylistFileUnknown= os.path.join(CACHE_DIR, "playlist_Unknown.m3u") 
VODFile=os.path.join(CACHE_DIR, "vod.m3u")
OutDir=CACHE_DIR

# ressours files 
DBJson=RESOURCES+'/MyChannels.json'
sourcesRef=RESOURCES+'/sources.xml'
SettingsRef=RESOURCES+'/settingsIPTV.xml'

# temp dir

TmpDir= xbmc.translatePath("special://temp/")
import tempfile, ntpath
# TmpDir=tempfile.gettempdir() # prints the current temporary directory
PlaylistFileTmp=TmpDir +'/'+ntpath.basename(PlaylistFile)



LOGLEVEL = 1  # From to 3
DEVMODE = True

VIEWID = '503'

LANG = 'fr'
QLTY = 'hd'

dirCheckList = (CACHE_DIR,)
channels = dict()
ordered_channels = []
hidden_channels = []
hidden_channelsName = []






