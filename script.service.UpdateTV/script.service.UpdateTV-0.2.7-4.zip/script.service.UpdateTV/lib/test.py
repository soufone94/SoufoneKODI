# -*- coding: utf-8 -*-

def DownloadFile(OtmanIPTV , OtmanIPTVfile):
    import time, urllib
    import cfscrape

    scraper = cfscrape.create_scraper()  # returns a CloudflareScraper instance
    # Or: scraper = cfscrape.CloudflareScraper()  # CloudflareScraper inherits from requests.Session
    Cleanplaylist=scraper.get(OtmanIPTV).content  # => "<!DOCTYPE html><html><head>..."

    f = open(OtmanIPTVfile, "w")
    f.write(Cleanplaylist.strip())
    f.close()


    # try: # some connection issue
    #     urllib.urlretrieve(OtmanIPTV , OtmanIPTVfile)
    # except:
    #     # print "\nconnection issue, retray in 2S ... "
    #     time.sleep(2)
    #     urllib.urlretrieve(OtmanIPTV , OtmanIPTVfile)
        
    return 

OtmanIPTV="http://electrowazan9.com:80/get.php?username=soufone2&password=R3px9OfXWs&type=m3u_plus&output=ts"
OtmanIPTVfile="c:\Users\soufian\AppData\Roaming\Kodi\cache/tmp.m3u"

def GetLinkFromFile(url):
    import re, os , urllib
    inf="can't open file" 
    link=""

    path, filename = os.path.split(url)
             
        
    filename = re.sub('[0-9a-zA-Z]+', '_', filename)
    urllib.urlretrieve(url , filename)
    inf = open(filename,'r')
    print "file name ",filename
    for line in inf:
        line=line.strip()
        if not line.startswith('#') and line:
            print " not started with # ", line
            link=line             
    inf.close()    
    return link

def IsSerie(string):
    import re

    string=string.upper()
    
    regexEpesode1='([0-9a-zA-Z]?[0-9]X[0-9]?.)'
    regexEpesode2='S[0-9].*EP[0-9].*'
    regexEpesode3='S[0-9].*E[0-9].*'

    try:
        episode=re.findall(regexEpesode1, string)[0]
    except IndexError:
        try:
            # string=string.replace(' ','')
            episode=re.findall(regexEpesode2, string)[0]
        except IndexError:
            episode=re.findall(regexEpesode3, string)[0]
    except:
        episode="none"


    

    return  episode

def SerieName(string):
    print string
    import re

    import re
    string = re.sub('[^0-9a-zA-Z]+', ' ', string)
    string = re.sub('[0-9]+', ' ', string)
    string = re.sub(' E ', ' ', string)
    string = re.sub(' S ', ' ', string)
    # string = string.upper().replace('SAISON',"").replace(' S',"") .replace(' E',"")    

    return  string

def GetLang(string,group,Provider="iptvpro"):
    import re
    lang=""

    regexIptvPro='\|(.*?)\|'
    regexElec='.*?:'

    if Provider=="Electrowazan":
        if "FRANCE" in group.upper():
            return "FR"
        elif ("MAROC" in group.upper()):
            return "AR"

        try:
            return re.findall(regexElec, string.replace(" ",""))[0].replace(":","")
        except:
            # raise
            return "AR"
            # pass

    if Provider=="iptvpro":
        try:
            return re.findall(regexIptvPro, string)[0]
        except:
            pass

        if lang=="":
            if "|AR" in group:
                lang="AR"
            if "|FR" in group:
                lang="FR"

    return lang


string=" ESPAGNE "
print string.strip()