#!/usr/bin/python
# -*- coding: utf-8 -*-

from lib.settings import *
# from lib.utils import notify
import lib.utils as utils
from xbmc import log

from lib.iptv import Updater
import default
# updater = Updater()
updater = Updater()
monitor = xbmc.Monitor()

def autostart():
    """
    Starts the cleaning service.
    """
    utils.notify("autostart")
    

    service_sleep = 4  # Lower than 4 causes too much stress on resource limited systems such as RPi
    ticker = 0
    delayed_completed = False

    while not monitor.abortRequested():
        # utils.notify("while")
        if get_setting(service_enabled):
            scan_interval_ticker = get_setting(scan_interval) * 60 / service_sleep
            delayed_start_ticker = get_setting(delayed_start) * 60 / service_sleep

            if delayed_completed and ticker >= scan_interval_ticker:
                utils.notify("delayed_completed")
                results, _ = updater.clean_all()
                notify(results)
                ticker = 0
            elif not delayed_completed and ticker >= delayed_start_ticker:
                delayed_completed = True
                default.Job()
                # updater.UpdateVOD()
                ticker = 0

            monitor.waitForAbort(service_sleep)
            ticker += 1
        else:
            monitor.waitForAbort(service_sleep)

    log("Abort requested. Terminating.")
    utils.notify("autostart end")
    return


if __name__ == "__main__":
    utils.notify("autostart")
    autostart()
    utils.notify("autostart end")
