#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys  

reload(sys)  
sys.setdefaultencoding('utf8')

import lib.globalvar as globalvar
import lib.iptv as iptv
import lib.utils as utils

from lib.iptv import Updater
updater = Updater()

import json
import xml.etree.ElementTree as ET

from lib.reset_exclusions import *
from lib.utils import *
from lib.viewer import *

import os
from shutil import copyfile
os.chdir(os.getcwd())

create_iptv=globalvar.ADDON.getSetting('create_iptv')
create_vod=globalvar.ADDON.getSetting('create_vod')

# from lib.MyApi import *
# import lib.MyFile as MyFile
# import lib.iptv as iptv
# # import lib.MyDropbox as MyDropbox

# import json

if not os.path.exists(globalvar.CACHE_DIR):
    os.makedirs(globalvar.CACHE_DIR, mode=0777)



# VODurl  ="https://www.dropbox.com/s/cjb9uc8wgfmp4xf/VOD.m3u?dl=1"


def Job():
    updater = Updater()

  
    utils.notify("start ")

    utils.notify("create_iptv "+create_iptv)
    utils.notify("create_vod "+create_vod)


    if not os.path.isfile(globalvar.AdvancedXML):          
        copyfile(globalvar.MyAdvanceXML, globalvar.AdvancedXML)


    if create_iptv=="true" or create_vod=="true": 
        NewPlaylist=iptv.main(globalvar.PlaylistFile,create_iptv,create_vod)  


    if create_vod=="true":
        # if os.path.isfile(globalvar.VODFile):        
        #     copyfile(globalvar.VODFile, globalvar.VODFile+'.back')
            
        updater.UpdateVOD()
        
        updater.UpdateSourceFile(globalvar.SourcesXML, "RemoteFilmAR",globalvar.OutDir+'/films/ar/')
        updater.UpdateSourceFile(globalvar.SourcesXML, "RemoteFilmFR",globalvar.OutDir+'/films/fr/')
        updater.UpdateSourceFile(globalvar.SourcesXML, "RemoteFilmEN",globalvar.OutDir+'/films/en/')
        updater.UpdateSourceFile(globalvar.SourcesXML, "RemoteSeries",globalvar.OutDir+'/series/')

        utils.notify("UpdateLibrary ")
        xbmc.executebuiltin("xbmc.UpdateLibrary(video)")
        utils.notify("CleanLibrary ")
        xbmc.executebuiltin("xbmc.CleanLibrary(video)")

        
    if create_iptv=="true":     
        updater.UpdateSimpleIPTVSettings(globalvar.PlaylistFile)

        DIALOG = xbmcgui.Dialog()
        response = DIALOG.yesno('Updater TV', 'IPTV playlist updated', yeslabel='reboot now', nolabel='plus tard')
        if response:
            xbmc.restart()
            # xbmc.RestartApp()



    utils.notify("end ")

    return 

if __name__ == "__main__":
    
    Job()





    




