# -*- coding: utf-8 -*-



# import xml.etree.ElementTree as ET

import xml.etree.ElementTree as ET

from MyApi import *
import MyFile 
from grabber import *

def Resetimageurl(database,Newdatabase):

    print " >>  Resetimageurl ... <<<<", database
    import os.path,filecmp, urllib, shutil
 

    rootData = ET.parse(database, parser=ET.XMLParser(encoding="utf-8" ))
    rootChannels=rootData.find('channels')

    for channel in rootChannels.findall('channel'): 
        try:
            channel.remove(channel.find('imageurl'))
        except:
            print "---------------------"
            print "except", channel.find("cname").text
            print "++++++++++++++++++++++"
            pass

    rootData.write(Newdatabase)
        
    return 

def AddImageurl(database,Newdatabase,logoGitHubLocal):

    print " >>  AddImageurl ... <<<<", database
    import os.path,filecmp, urllib, shutil
    from os.path import basename
 

    rootData = ET.parse(database, parser=ET.XMLParser(encoding="utf-8" ))
    rootChannels=rootData.find('channels')

    read_files = glob.glob(logoGitHubLocal+"/*.png")
    # print read_files

    # testfile='c:\\Users\\soufian\\Documents\\GitHub\\IPTV\\logo/test\\2M.png'
    # if testfile in  read_files:
    #     print "bingo"
    # else:
    #     "pffffffff"

    for channel in rootChannels.findall('channel'): 
        for calias in channel.findall('calias'):     
            if (calias.text):
                for f in read_files:
                    iname=basename(os.path.splitext(f)[0])
                    # print "==========="
                    # print calias.text.encode("utf-8")
                    # print iname.encode("utf-8")

                    if MyFile.purge(calias.text.encode("utf-8"))==MyFile.purge(iname.encode("utf-8")):
                        # print "calias==iname"
                        imageNew=channel.find('cname').text.replace(" ","_").lower()
                        try:
                            if imageNew != iname:
                                shutil.move(f,f.replace(iname,imageNew))
                            imageurl = ET.SubElement(channel, 'imageurl')
                            imageurl.text=GitHubLogoBase+iname+".png"   
                                              
                            break
                        except:
                            print "except >> ","newimage: ",imageNew, "iname: ",iname
                            pass
             


                


        

    rootData.write(Newdatabase)

    MyFile.pretty_printWebGrabConfig(Newdatabase,Newdatabase+".tmp")
    shutil.move(Newdatabase+".tmp", Newdatabase)
        
    return 

def DownlowdImage(database,logoGitHubLocal):

    print " >>  DownlowdImage ... <<<<", database,logoGitHubLocal
    import os.path,filecmp, urllib, shutil
 

    rootData = ET.parse(database, parser=ET.XMLParser(encoding="utf-8" ))
    rootChannels=rootData.find('channels')

    for channel in rootChannels.findall('channel'): 
        
        imageurl = channel.find('imageurl').text  
        cname=channel.find('cname').text 
        image=logoGitHubLocal+cname.replace(" ","_")+".png"
        if not os.path.isfile(image):
            if imageurl:
                try:
                    Download(imageurl, image)
                except:
                    # print "except", imageurl, image
                    pass
    return 

def Download(url, dest):
    # print "Download :",(url, dest)
    import ssl
    from urllib2 import urlopen, URLError, HTTPError


    req = urllib2.Request(url, headers={ 'X-Mashape-Key': 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX' })
    gcontext = ssl.SSLContext(ssl.PROTOCOL_TLSv1)  # Only for gangstars
    f  = urlopen(req, context=gcontext)

    # Open the url
    try:
        # print "downloading " + url
        # Open our local file for writing
        with open(dest, "wb") as local_file:
            local_file.write(f.read())

    #handle errors
    except HTTPError, e:
        print "HTTP Error:", e.code, url
    except URLError, e:
        print "URL Error:", e.reason, url


    return

def ReplaceJPGtoPNG(dir):
    print ">> ReplaceJPGtoPNG: ",dir
    import glob,shutil

    read_files = glob.glob(dir+"/*")
    print "read_files",read_files
    
    for f in read_files:
        shutil.move(f,f.replace(".jpg",".png").lower())
     

def main(workspace,icon=True,DoShahid=False, Dowsat4=False):
    from MyApi import *
    print (" *****start logos creating at: ")#, datetime.datetime.now().time()

    
    


    # DownlowdImage(ChannelDataBase,logoGitHubLocal)
    ReplaceJPGtoPNG(logoGitHubLocal)

    Resetimageurl(ChannelDataBase,ChannelDataBase.replace(".xml","-imageLess.xml"))

    AddImageurl(ChannelDataBase.replace(".xml","-imageLess.xml"),ChannelDataBase.replace(".xml","-imageNew.xml"),logoGitHubLocal)

    return 


if __name__ == '__main__':
    main(workspace)

