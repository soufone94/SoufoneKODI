# -*- coding: utf-8 -*-

# class Outputs():
#     def __init__(self, StreamList):
#         self.StreamList = StreamList

from globalsVar import *  
import os,sys, getopt, urllib, urllib2, glob, logging, shutil 
import datetime,time

# def install(package):
#     print "PIP install:",package
#     import pip
#     pip.main(['install', package])



import urllib2, urllib 
import os,  re, shutil
import logging,sys, traceback

import sys
import xml.etree.ElementTree as ET


import getpass
import glob

from datetime import timedelta, datetime
import datetime,time
from time import sleep

def install(package):
    print "PIP install:",package
    import pip
    pip.main(['install', package])

class Mycchardet():
	def detect(strng):

		return "ASCII"

# try:
#     import bs4
# except:
#     install("BeatifulSoup4")
#     import bs4

# try:
#     import lxml.etree

# except:
#     install("lxml")
#     import lxml.etree

# try:
#     import livestreamer
# except:
#     install("livestreamer")
#     import livestreamer
    


# logger = logging.getLogger('myapp')
# hdlr = logging.FileHandler(os.getcwd()+'/logs/log.log')
# formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
# hdlr.setFormatter(formatter)
# logger.addHandler(hdlr) 
# logger.setLevel(logging.DEBUG)

def loggerinit():

    logger = logging.getLogger('myapp')
    hdlr = logging.FileHandler(os.getcwd()+'/log.log')
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
    hdlr.setFormatter(formatter)
    logger.addHandler(hdlr) 
    logger.setLevel(logging.DEBUG)


