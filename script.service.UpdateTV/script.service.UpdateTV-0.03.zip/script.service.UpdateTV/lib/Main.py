# -*- coding: utf-8 -*-
import os
os.chdir(os.getcwd())

from lib.MyApi import *
import lib.MyFile as MyFile
import lib.grabber as grabber
import lib.newapi as newapi
import lib.iptv as iptv
# import json

# import lib.shahid as shahid

    
print "Start MyTV build... "



# create needed directory 
MyFile.CreateOutputs(workspace)
# shutil.copy(ChannelDataBase,ChannelDataBaseTmp)

# download OtmanIPTV to newplaylist
# copy old OtmanIPTV (previos newplaylist) to oldplaylist
# OtmanIPTV="http://otmanshowiptv.com:7777/get.php?username=soufone2&password=R3px9OfXWs&type=m3u&output=ts"
OtmanIPTV="https://www.dropbox.com/s/8bop85mg37i0tex/test.m3u?dl=1"
OtmanIPTV="http://Electrowazan7.com:7777/get.php?username=soufone2&password=R3px9OfXWs&type=m3u&output=ts"

LastOtmanIPTV=OutStreamDir+"LastOtmanIPTV.m3u"
NewOtmanIPTV=OutStreamDir+"NewOtmanIPTV.m3u"


fNewLink=OutStreamDir+"NewLink.m3u"
fObsoleteLink=OutStreamDir+"ObsoleteLink.m3u"

def main():

	IPTVChanged=newapi.getOtmanIPTV(OtmanIPTV,LastOtmanIPTV,NewOtmanIPTV)
	print "IPTVChanged ",IPTVChanged

	M3UNewData, M3UObsolete=newapi.UpdateIPTVplaylist(IPTVChanged,OtmanIPTV,LastOtmanIPTV,NewOtmanIPTV,fNewLink,fObsoleteLink)

	raise

	if debug:
		print "============== New M3UNewData ================"
		iptv.PrintM3UPlaylist(M3UNewData)

	# for IPTVT in M3UNewData:
	# 	print (IPTVT.title, IPTVT.tvg, IPTVT.SiteEPG, IPTVT.site_id, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path)

	print "\n\n****************** webgaber *******************"
	print "WebGrabConfig",WebGrabConfig
	# # create GrabConfig list 
	# remove obsolete from WebGrabConfig
	# WebGrabConfigNew=WebGrabConfig+'-New.xml'
	WebGrabConfigNew=WebGrabConfig

	# update WebGrab Pack install 
	updateVersion=False
	updateVersion=grabber.updateWebgrabberPack(WebGrabDir, remoteSiteIni, localSiteIni_tmp)

	if os.path.isfile(WebGrabConfig):
		print "main: start update ", WebGrabConfig
		if IPTVChanged: 
			shutil.copy(WebGrabConfig,WebGrabConfig+'.back')
			newapi.webgaberRemoveObsoleteChannel(M3UObsolete,WebGrabConfig,WebGrabConfig)

			# add new
			# get site and ini for M3UNewData
			WebGrabConfigNew=WebGrabConfig+'-obsoleteLess.xml'
			newapi.webgaberAddNewChannel(M3UNewData,WebGrabConfig,WebGrabConfigNew,xmlSiteDir)
			print "shutil.copy",WebGrabConfigNew,WebGrabConfigInstal
			shutil.move(WebGrabConfigNew,WebGrabConfig)	
			shutil.copy(WebGrabConfig,WebGrabConfigInstal)	


	else:
		print "has to do full grabb"
		grabber.main(workspace)
		
	# raise # check /tmp/Mychanneles	
	grabber.run_WebGrab(workspace)


		# merge playlistTmp+PlaylistNew= playlist
		# merge GrabConfigTmp + GrabConfiNew =GrabConfig

	# log.write(str(datetime.datetime.now().time())+"	============= END build ========== \n\n\n" )
	# log.close() # Ferme le fichier
	print "END"
	#clean older files


