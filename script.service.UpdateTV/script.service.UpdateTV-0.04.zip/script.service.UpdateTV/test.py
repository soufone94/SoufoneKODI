# -*- coding: utf-8 -*-

str1="10 CLOVERFIELD LANE"
str2="يوم سعادة 365"

str1.encode('utf-8')
str2.encode('utf-8')