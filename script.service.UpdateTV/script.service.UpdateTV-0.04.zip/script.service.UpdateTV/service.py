#!/usr/bin/python
# -*- coding: utf-8 -*-

from settings import *
from utils import notify
from xbmc import log

from iptv import Updater
import default
# updater = Updater()
updater = Updater()
monitor = xbmc.Monitor()

def autostart():
    """
    Starts the cleaning service.
    """
    updater.notify("autostart")
    

    service_sleep = 4  # Lower than 4 causes too much stress on resource limited systems such as RPi
    ticker = 0
    delayed_completed = False

    while not monitor.abortRequested():
        # updater.notify("while")
        if get_setting(service_enabled):
            scan_interval_ticker = get_setting(scan_interval) * 60 / service_sleep
            delayed_start_ticker = get_setting(delayed_start) * 60 / service_sleep

            if delayed_completed and ticker >= scan_interval_ticker:
                updater.notify("delayed_completed")
                results, _ = updater.clean_all()
                notify(results)
                ticker = 0
            elif not delayed_completed and ticker >= delayed_start_ticker:
                delayed_completed = True
                default.Job()
                # updater.UpdateVOD()
                ticker = 0

            monitor.waitForAbort(service_sleep)
            ticker += 1
        else:
            monitor.waitForAbort(service_sleep)

    log("Abort requested. Terminating.")
    updater.notify("autostart end")
    return


if __name__ == "__main__":
    updater.notify("autostart")
    autostart()
    updater.notify("autostart end")
