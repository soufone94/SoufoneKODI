# -*- coding: utf-8 -*-

import urllib2, logging, os

import sys
import xml.etree.ElementTree as ET
import os, re, shutil
import urllib, urllib2

import getpass
import datetime
import glob

from datetime import timedelta, datetime
from time import sleep

from GlobalEnv import *

def supprime_accent(ligne):
        return ligne
        ligne=ligne.lower()
        # print "******* supprime_accent ligne", ligne
        """ supprime les accents du texte source """
        
        # ligne= ligne.decode('latin1').encode('utf8')
        try:
            ligne =ligne.encode('ASCII','replace') 
        except: 
            # raise  
            ligne= ligne.decode('iso-8859-1').encode('utf8')     
            # ligne =ligne.decode('iso-8859-1')             
            # ligne =ligne.encode('ASCII','replace')
            print "ligne", ligne

        accents = { 'a': ['à', 'ã', 'á', 'â'],
                    'e': ['é', 'è', 'ê', 'ë','é'],
                    'i': ['î', 'ï'],
                    'u': ['ù', 'ü', 'û'],
                    'et': ['&'],
                    'o': ['ô', 'ö','Ô'] }
        for (char, accented_chars) in accents.iteritems():
            for accented_char in accented_chars:
                ligne = ligne.replace(accented_char, char)
        # print "supprime_accent ligne",ligne
        return ligne

def loggerinit():

    logger = logging.getLogger('myapp')
    hdlr = logging.FileHandler(os.getcwd()+'/log.log')
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
    hdlr.setFormatter(formatter)
    logger.addHandler(hdlr) 
    logger.setLevel(logging.DEBUG)

def SetupWorkSpace():
    import shutil
    
    logfile = os.getcwd()+'\log.log'
    logfileback = os.getcwd()+'\log.log'+'.back'
    StreamDir = os.getcwd()+'\stream'
    StreamDirOld = os.getcwd()+'\stream_old'

    try:
        shutil.move(logfile, logfileback)
    except:
        print "log file doesn't exist, no need to backup", logfile
        #logger.info("ERROR: SetupWorkSpace: log file doesn't exist, no need to backup %s",logfile)
        raise
    
    source = os.listdir(StreamDir)
    
    for files in source:
        dst_file = StreamDirOld + '/'+files
        if os.path.exists(dst_file):
            os.remove(dst_file)
        try:
            shutil.move(StreamDir + '/' +files,dst_file)
        except:
            print "can't copy ", files
            #logger.info("ERROR: SetupWorkSpace: can't copy stream file ", files)
            raise

    return 

def indent(elem, level=0):
  i = "\n" + level*"  "
  if len(elem):
    if not elem.text or not elem.text.strip():
      elem.text = i + "  "
    if not elem.tail or not elem.tail.strip():
      elem.tail = i
    for elem in elem:
      indent(elem, level+1)
    if not elem.tail or not elem.tail.strip():
      elem.tail = i
  else:
    if level and (not elem.tail or not elem.tail.strip()):
      elem.tail = i

def purge(name):
    # remove all space, -, _ before comapr channel name
    #print "entry purge"
        # remove all space, -, _ before comapr channel name
    import unicodedata

    purgedname=name
    try:
        purgedname =purgedname.encode('ASCII','replace') 
    except:        
        purgedname =purgedname.decode('iso-8859-1','replace') 
        purgedname =purgedname.encode('ASCII','replace')
            
    purgedname = purgedname.replace("-","").strip()
    purgedname = purgedname.replace("?","")
    purgedname = purgedname.replace("&","et")
    purgedname = purgedname.upper()
    purgedname = purgedname.replace("_","")
    purgedname = purgedname.replace(" ","")
    purgedname = purgedname.replace("+","plus")
    purgedname = purgedname.replace("(","")
    purgedname = purgedname.replace(")","")
    purgedname = purgedname.replace("HD","")
    purgedname = purgedname.replace("SD","")
    purgedname = purgedname.replace("/","")
    purgedname = purgedname.replace(".FR","")

    # print "name",purgedname  
    return purgedname

def RenameGroup(group):

    if ("musi" in group.lower()):
        group="MUSIQUES"
    if ("sport" in group.lower()):
        group="SPORTS"  
    if ("jeunesse" in group.lower()):
        group="KIDS"    
    if ("info" in group.lower()):
        group="NEWS"   
    if ("adulte" in group.lower()):
        group="ze unknown" 
    if group  == '':
       group = "ze unknown"
    return group

def CheckLink(url, Title, TestConnection=False):
    #print "CheckLink: enter", url
    # return True, "RADIO or TV"
    
    import socket
    timeout=3

    # return True, "Connection OFF"

    # import urlresolver

    # stream_url = urlresolver.resolve(url)

    # if stream_url:
    #     xbmcplugin.setResolvedUrl(plugin_handle, True, 
    #                               xbmcgui.ListItem(path=stream_url))
    # else:
    #     xbmcplugin.setResolvedUrl(plugin_handle, False, 
    #                               xbmcgui.ListItem())
    
    if TestConnection == False:
        #print " force TestConnection sate to True"
        return True, "Connection OFF"

    if '$' in url: # or '?' in url:
        ##logger.info("ERROR: CheckLink:  %s : / not supported Format %s",Title,url)
        return False, "not supported Format"

    if  url.startswith('http:'):
        import urllib2, urllib
        
        if "pvr" in url:
            return True, "TV"

        else:
       
            try:
                try:
                    res = urllib2.urlopen(url,timeout=timeout)
                    http_message = res.info()
                    full = http_message.type # 'text/plain'
                    main = http_message.maintype # 'text'
                    #print "full", full
                except:
                    #print "Unexpected urllib2 error:", sys.exc_info()[0]
                    if ":@" in url:
                        full ="video"
                    else:
                        full ="failed"


                if ("audio" in full):
                    return True, "RADIO"

                elif ("video" in full) or ("plain" in full) or ("mpeg" in full) or ("mpegurl" in full) or ("octet-stream" in full):  
                    return True, "TV"
                
                else:                
                    ##logger.info("CheckLink: >>> %s : / URL: %s",Title, url)
                    ##logger.info("CheckLink: >>> %s : / full: %s",Title, full)
                    ##print "CheckLink: >>> %s : / URL:",Title, url
                    ##print "CheckLink: >>> %s : / full:",Title, full
                    
                    return False, "Type Faild"
            except IOError, e:
                return False, e 
            except:
                ##logger.info("ERROR CheckLink: >>> %s : / except: URL: %s",Title, url)
                #print "ERROR CheckLink: >>> except: URL:", url
                return False, "Type execption"
                raise

    # elif url.startswith('rtmp:/'):        
    #     from livestreamer import Livestreamer, StreamError, PluginError, NoPluginError
    #     quality = 'best'

    #     # Create the Livestreamer session
    #     livestreamer = Livestreamer()

    #     # Enable logging
    #     livestreamer.set_loglevel("info")
    #     livestreamer.set_logoutput(sys.stdout)
        
    #             # Attempt to fetch streams
    #     try:
    #         livestreamer.set_option("rtmp-timeout", timeout)
    #         streams = livestreamer.streams(url)

    #     except NoPluginError:
    #         ##logger.info(" ERROR: CheckLink:  %s : / uLivestreamer is unable to handle the URL %s ",Title, url)
    #         #print("Livestreamer is unable to handle the URL '{0}'".format(url))
    #         return False, "rtmp False 1"
    #     except PluginError as err:
    #         ##logger.info(" ERROR: CheckLink:  %s : / Unknown issue URL %s ", Title,url)
    #         #print("Unknown issue URL '{0}'".format(url))
    #         return False, "rtmp False 2"
    #     except:
    #         ##logger.info(" ERROR: CheckLink:  %s : / Unknow issue URL %s ",Title, url)
    #         #print ("Unknow issue".format(url))
    #         return False, "rtmp False 3"

    #     if not streams:
    #         ##logger.info(" ERROR: CheckLink: %s : /  No streams found on  URL %s ",Title, url)
    #         #print("No streams found on URL '{0}'".format(url))
    #         return False, "rtmp False 4"

    #     # Look for specified stream
    #     if quality not in streams:
    #         ##logger.info(" ERROR: CheckLink: %s : /  Unable to find  stream on  URL %s ",Title, url)
    #         #print("Unable to find '{0}' stream on URL '{1}'".format(quality, url))
    #         return False, "rtmp False 4"

    #     try:
    #         # We found the stream
    #         stream = streams[quality]
    #         fd = stream.open()
    #         data = fd.read(1024)
    #         fd.close()
            
    #         if data == '':
    #             return False, "rtmp False 5"
    #         else:
    #             return True, "rtmp true 6"
    #     except:
    #         ##logger.info(" ERROR: CheckLink: %s : /  Unknow issue (2) URL %s ",Title, url)
    #         #print ("Unknow issue (2) ".format(url))
    #         return False, "rtmp False 7"
 
    # elif url.startswith('mms') or url.startswith('rtsp'):
    #     return False, "mms False"
    else:
        #print " unsupported protocol ", url
        #logger.info(" ERROR: CheckLink: %s : /  unsupported protocol %s ", Title,url)
        return False, "mms False"
   
def IsFavorite(group):
    if (group == "french") or (group == "maroc") or (group == "drama") or (group == "ent"):
               return True
    else:
               return True

# Retrun true if link is supported
def FormatLink(url):
    if url.startswith('rtmp') or url.startswith('http:') or url.startswith('mms') or url.startswith('rtsp:'):
        return True
    else:
        return False
