# -*- coding: utf-8 -*-

import urllib2, logging, os

import sys
import xml.etree.ElementTree as ET
import os, re, shutil
import urllib, urllib2

import getpass
import datetime
import glob

import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs

from datetime import timedelta, datetime
from time import sleep

endtime = datetime.utcnow() + timedelta(seconds = 3)

# Global Variables
TestConnection = True

workspace = os.getcwd()
workspace = os.path.dirname(os.path.abspath(__file__))
__addon__PVR   = xbmcaddon.Addon(id='service.Mypvrtools')
workspace= xbmc.translatePath( __addon__PVR.getAddonInfo('profile') ) 

#Output 
output = workspace
logs = workspace + '/logs'
FTVOut = output + '/FTV/'
logos = output + '/logos/'
radioma = output + '/radioma/'
shahid = output + '/shahid/'
streamDir = workspace+"/stream/"

MyPlaylist = output + '/playlist.m3u'
MyPlaylistKO = output + '/playlist-KO.m3u'

global_header = '#EXTM3U\n'


#Ressources
Ressources = workspace + '/Ressources'
FTVDir = workspace + '/Modules/FTV/'
WebGrabDir = workspace + '/Modules/WebGrab/'

Shahid_channelsLink = "https://raw.githubusercontent.com/Shani-08/ShaniXBMCWork/master/plugin.video.shahidmbcnet/resources/community/Channels.xml"
ChannelDataBase = 'https://dl.dropboxusercontent.com/u/80638885/XBMC/LIVE_TV/Ressources/channels.xml'

StreamList = "c:/Users/soufi_000/Dropbox/Public/XBMC/LIVE_TV/Ressources/list-m3u.py"


#radioma
radioMA_xml_Remote = "http://radioma.ma/radiomaxbmc/radios.xml"
radioMA_xml_local = output + '/radioma/radioma.xml'
radioMaM3U = output + '/radioma/radioma.m3u'


curentdir = os.getcwd()
radioMaM3U = curentdir + "/output/radioma.m3u"
radioMA_xml_Remote = "http://radioma.ma/radiomaxbmc/radios.xml"
radioMA_xml_local = Ressources+'/radios.xml'

class IPTV():
    def __init__(self, title,tvg,tvIcon,radio,group,xbmc, path,cname2,state,SiteINI,site_id):
        self.title = title
        self.tvg = tvg
        self.tvIcon = tvIcon
        self.radio = radio
        self.group = group
        self.xbmc = xbmc
        self.path = path
        self.cname2 = cname2
        self.state = state        
        self.SiteINI = SiteINI
        self.site_id = site_id

