# -*- coding: cp1252 -*-
# -*- coding: utf-8 -*-


import MyApi
import urllib, urllib2,re,os
import xml.etree.ElementTree as ET

def radioMA_Playlist(radioMA_xml_Remote,radiosXml, LogoDir, ouputfile, TestConnection):
    
    print " >>>>>>>>>> start radioMA_Playlist ... TestConnection state= ", TestConnection
    print "Logodir =", LogoDir
    print "ouputfile ",ouputfile
    
    
    playlistMA = ''
    global_header = '#EXTM3U\n'
    playlistMA += global_header
    
    try:
        urllib.urlretrieve(radioMA_xml_Remote,radiosXml)
    except:
        print "error: Get_Radioma_files can't get: ", radioMA_xml_Remote
        print "error: Get_Radioma_files can't get radio.xml"
        raise
    
    Channels = open(radiosXml,'r')
    
    treeCh = ET.parse(Channels)
    rootCh = treeCh.getroot()
    

    for Station in rootCh.findall('Station'):
        link = ''
        category = "radio MA"
        Name = Station.find('Name').text
        item = Station.find('item')
        link = Station.find('URLStream').text
        icon = Station.find('Icon').text
        channel_id = Name
        state, radio = MyApi.CheckLink(link,Name,TestConnection)
        if Name and state:
            channel_icon = Name.replace(" ","_")
            channel_icon = channel_icon + ".png"
            if TestConnection == True:
                try:
                    f = urllib2.urlopen(urllib2.Request(icon))
                    urllib.urlretrieve(icon, LogoDir + channel_icon)
                except:
                   print (" bad icon link %s", icon)
                   #raise

            #channel_icon = imageurl
            channel_display_name = Name
            group = category 
            #print group

            channel_header = '#EXTINF:-1 tvg-id="%s" tvg-name="%s" tvg-logo="%s" radio="true", group-title="%s",%s\n' \
                             % (channel_id.strip(), channel_display_name.strip(), channel_icon.strip(), group.strip().upper(), channel_display_name.strip())

            playlistMA += channel_header
            playlistMA += link + '\n'+'\n'


    with open(ouputfile, 'w') as f:
        f.write(playlistMA)
        f.close()
        
    return playlistMA
