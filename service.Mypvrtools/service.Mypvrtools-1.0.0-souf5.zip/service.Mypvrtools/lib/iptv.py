# -*- coding: utf-8 -*-

import os,sys, getopt, urllib, urllib2, glob, logging
import datetime,time

import xml.etree.ElementTree as ET

import lib.MyApi as MyApi
import lib.radioma as radioma
import xbmcaddon, xbmc

from common_variables import *



def getKey(IPTV):
    #filter by group
    return IPTV.group

def getKeyTvg(IPTV):
    #filter by tvgname
    return IPTV.title

def Playlist_Formating(playlist):
    print 'start Playlist_Formating:' 
    ##logger.info("start Playlist_Formating: ")
    
    return sorted(playlist, key=getKey)
           
# Parse Channels.xml to get icon, tvguid and group names
def ParseChannelsXmlNew(database,playlist, Connected = True):
    import codecs

    # initialize dataB variables before reading file
    print " >>>>>>>>>>>> soufone: start ParseChannelsXml ... <<<<"#, datetime.datetime.now().time()
    ##logger.info(" >>>>>>>>> start ParseChannelsXml ... <<<<<<<<<<<<<<<<<")
    IPTVFound = 0
    FlagIPTV = 0 # verifier si header est creer

    channel_id = ""
    channel_display_name = ""
    channel_icon = "----SeriesTV----.png"
    group = ""
    radio = ""


    playlistTrie = ''
    Cleanplaylist = ''
    CleanplaylistKO = ''
    IPTV_DATA = []
    IPTV_DATAKO = []
    # data = open(database,'r')   
    # dataCh = ET.parse(data)
    # rootData = dataCh.getroot()
    rootData = ET.parse(database, parser=ET.XMLParser(encoding="iso-8859-1" ))


    DupLessPath = []
    for IPTV in playlist:
        IPTVFound = 0

        

        
        if IPTV.title != None: #Title not empty
            
            if IPTV.path not in DupLessPath: # first occurence
                DupLessPath.append(IPTV.path)
                
                # print ">>>>> IPTV.title", IPTV.title,IPTV.path
                state, radio = MyApi.CheckLink(IPTV.path, IPTV.title, Connected) # Check if link alive and if radio or TV 
                # print "soufone state", IPTV.title, state, radio
                if not state: #link is dead 
                    ###logger.info( "IPTV.title KO %s", IPTV.title)
                    IPTV.xbmc = IPTV.title 
                    IPTV.tvIcon = IPTV.title.replace(" ","_")+".png"
                    IPTV.group = radio #+ IPTV.group
                    IPTV.state = "KO"
                    if IPTV.radio == '':                          
                        IPTV.radio = "false"                          
                            
                    channel_header = '#EXTINF:-1 tvg-id="%s" tvg-name="%s" tvg-logo="%s" radio="%s"  group-title="%s",%s\n' \
                                % (IPTV.title, IPTV.tvg , IPTV.tvIcon, IPTV.radio, IPTV.group.upper(), IPTV.xbmc)
                    CleanplaylistKO += channel_header
                    CleanplaylistKO += IPTV.path + '\n'+'\n'

                    IPTV_DATAKO.append(IPTV)

                else: # link alive
                    #print (IPTV.title, IPTV.tvg, IPTV.tvIcon, IPTV.radio, IPTV.group, IPTV.path)
                    for channel in rootData.findall('channel'):  
                        IPTV.state = "OK"                        
                        
                        # IPTV is valid and not yet founded
                        # parse database                
                        for cname in channel.findall('cname'):  
                            LinkState = False 

                            # cname.text=(cname.text).encode('ascii', 'ignore')
                            # cname.text=unicode(cname.text).encode('utf-8')
                                    
                            #print "radio state", cname.attribute('enabled')

                            if (MyApi.purge(IPTV.title) == MyApi.purge(cname.text)): 
                                IPTVFound = 1
                                IPTV.title = str(cname.text)
                                assignedcategory = channel.find('assignedcategory')
                                IPTV.group = assignedcategory.find('category').text.upper()                                
                                #print "IPTV found", channel_header
                                break

                        # si not found avec cname, search for second cname2 of channel
                        if IPTVFound != 1:                                             
                            for cname2 in channel.findall('cname2'): 
                                try:
                                    # cname2.text=(cname2.text).encode('ascii', 'ignore')
                                    
                                    # create string to compar: sans " ","-","_"
                                    if cname2.text != None:  
                                        if (MyApi.purge(IPTV.title) == MyApi.purge(cname2.text)): 
                                            IPTVFound = 1
                                            IPTV.title = str(cname.text)
                                            assignedcategory = channel.find('assignedcategory')
                                            IPTV.group = assignedcategory.find('category').text.upper()
                                            IPTV.cname2 = cname2.text
                                            break
                                except:
                                    raise
                                    pass

                    # IPTV not founded in database => create playlist using IPTV info             
                    if IPTVFound == 0:
                        IPTVFound = 1
                        IPTV.title = IPTV.title.strip()

                        if ("http://flv.alarab.net" in IPTV.path.lower()):
                            IPTV.group = "FILM alarab"
                        IPTV.group=MyApi.RenameGroup(IPTV.group)

                        # print "title, group", IPTV.title , IPTV.group


                    # after all check and data creation
                    IPTV.tvg = IPTV.title                    
                    if ("/UDP/" in IPTV.path.upper()):
                        IPTV.xbmc = "[COLOR red] " + IPTV.title + " [/COLOR]" + " UDP"
                    else:
                        IPTV.xbmc = IPTV.title

                    IPTV.tvIcon = str(IPTV.title).replace(" ","_")+".png"
                    if IPTV.radio == '':
                        if radio == 'RADIO':
                            IPTV.radio = "true"
                        else:
                            IPTV.radio = "false"

                    channel_header = '#EXTINF:-1 tvg-id="%s" tvg-name="%s" tvg-logo="%s" radio="%s"  group-title="%s",%s\n' \
                                    % (IPTV.title, IPTV.tvg , IPTV.tvIcon, IPTV.radio, IPTV.group.upper(), IPTV.xbmc)
                    Cleanplaylist += channel_header
                    Cleanplaylist += IPTV.path + '\n'+'\n'

                    IPTV_DATA.append(IPTV)

    ##    #return Cleanplaylist
    return IPTV_DATA, IPTV_DATAKO

# Parse Channels.xml to get icon, tvguid and group names
def GetIcon(database,LogoDir):

    # initialize dataB variables before reading file
    print " >>>>>>>>>>>> start GetIcon ... <<<<", datetime.datetime.now().time()

    data = open(database,'r')   
    dataCh = ET.parse(data)
    rootData = dataCh.getroot()

    for channel in rootData.findall('channel'):             
            cname = channel.find('cname').text  
            cname=(cname).encode('ascii', 'ignore')
            cname=unicode(cname).encode('utf-8')

            imageurl = channel.find('imageurl').text 
            #print "cname, url",cname, imageurl
            if cname:
                logoname = cname.replace(" ","_")
                logoname = logoname + ".png"
                logonameFTV = cname + ".png"
                
                if not os.path.exists(LogoDir + logoname) or not os.path.exists(LogoDir + logonameFTV):
                    try:
                        f = urllib2.urlopen(urllib2.Request(imageurl))
                        urllib.urlretrieve(imageurl, LogoDir + logoname)
                        shutil.copyfile(LogoDir + logoname, LogoDir + logonameFTV)
                        #print logoname
                    except:
                        print ">>>>  url ko", logoname, " site: ", imageurl
                        #logger.info(">>>>  url ko> %s : / site: %s",logoname, imageurl)

# Read M3U list from file
def getList(liste):
    print ">> start getList:" , liste
    ##logger.info("start getList:")


    playlist =[]

    if os.path.isfile(liste):
        print "it is a local file"
        inf = open(liste,'r')
    else:
        try:
            print "try"
            path, filename = os.path.split(liste)
            print "file name ",filename
            if not os.path.exists(streamDir):
                os.makedirs(streamDir)
            urllib.urlretrieve(liste , streamDir+filename)
            inf = open(streamDir+filename,'r')
        except IOError as e:
            print "ERROR: getList: get file I/O error({0}): {1}".format(e.errno, e.strerror)
            #logger.info("ERROR: getList: get file : I/O error({0}): {1}".format(e.errno, e.strerror))
            return playlist
            raise    

    try:
        for line in inf:
            line=line.strip()
            if not line.startswith('#') and line:
                print " not started with # ", line
                playlist += GetM3U_data(line)
    except IOError as e:
        print "ERROR: getList: I/O error({0}): {1}".format(e.errno, e.strerror)
        ##logger.info("ERROR: getList: I/O error({0}): {1}".format(e.errno, e.strerror))
        raise
    except:
        print "ERROR: getList: unexpected error: liste=", liste 
        print "ERROR: getList: unexpected error: line=", line
        ##logger.info("ERROR: getList: unexpected error: liste = %s",liste)
        ##logger.info("ERROR: getList: unexpected error: line = %s",line)
        raise

    inf.close()    

    return playlist

def GetM3U_data(M3UPlaylist):
    import re
    print ("soufone start GetM3U_data: playlist: ",M3UPlaylist)
    ##logger.info("start GetM3U_data:  playlist: %s ", M3UPlaylist)

    # initialize playlist variables before reading file
    playlist=[]
    out_path    = streamDir


    if os.path.isfile(M3UPlaylist):
        inf = open(M3UPlaylist,'r')
    else:
        try:
            path, filename = os.path.split(M3UPlaylist)
            try:                
                filename = filename.upper().replace(" ","").replace("?","").replace("!","").replace(".M3U","") + ".m3u"
                urllib.urlretrieve(M3UPlaylist , out_path+filename)
                inf = open(out_path+filename,'r')
                print "soufone file name ",filename
            except:   
                raise         
                urllib.urlretrieve(M3UPlaylist , "M3UPlaylist.m3u.tmp")
                inf = open("M3UPlaylist.m3u.tmp",'r')

            
        except IOError as e:
            print "ERROR: M3UPlaylist: get file I/O error({0}): {1}".format(e.errno, e.strerror)
            ##logger.info("ERROR: M3UPlaylist: get file : I/O error({0}): {1}".format(e.errno, e.strerror))
            return playlist 
 


    #title,tvg,tvIcon,radio,group, xbmc, path)
    song=IPTV(None,None,None,None,None,None,None,None,None,None,None)

    for line in inf:
        line=line.strip()
            
        ##EXTINF:-1 tvg-id="2M" tvg-name="2M" tvg-logo="2M.png" group-title="Maroc"2M
        if line.startswith('#EXTINF:'):
           
            # line = str(line.strip())            
            line=MyApi.supprime_accent(line)
            
            try:
                rest,title = line.rsplit(',',1)              
                #title = re.search(r'(?<=tvg-id=").*?(?=")', line).group(0)              
            except:
                try:                                  
                    rest,title = line.rsplit(',',1)
                except:
                    try:
                        rest,title = line.rsplit('#EXTINF:-1',1)
                    except:
                        title=line.replace("#extinf:-1",'').split()
                               
            title= str(title)
            title = title.replace(',','').replace('-1','').replace('0','').replace(':-',' ').replace(':','')
            title = re.sub(r"\[.+?\]", "", title)

            #print "** title",title

            try: 
                tvg = re.search(r'(?<=tvg-name=").*?(?=")', line).group(0).strip()
            except:
                tvg =''
            try: 
                tvIcon = re.search(r'(?<=tvg-logo=").*?(?=")', line).group(0)
            except:
                tvIcon =''
            
            try: 
                radio = re.search(r'(?<=radio=").*?(?=")', line).group(0)
            except:
                radio =''
            
            try: 
                group = re.search(r'(?<=group-title=").*?(?=")', line).group(0)
            except:
                group =''

            song=IPTV(title,tvg,tvIcon,radio,group.upper(),None,None,None,None,None,None)
            # print "title group",title, group.upper()

                
        elif MyApi.FormatLink(line):
            # pull song path from all other, non-blank lines
            song.path=line
            playlist.append(song)

            # reset the song variable so it doesn't use the same EXTINF more than once
            song=IPTV(None,None,None,None,None,None,None,None,None,None,None)

    inf.close()
    # for IPTVT in playlist:
    #     print (IPTVT.title, IPTVT.tvg, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path)

    #####Clean up directory
    filelist = glob.glob("*.tmp")
    for f in filelist:
        os.remove(f)
        
    return playlist

def MiseEnForme(Playlist,Output):
    print ">>>>> start MiseEnForme", Output
    import operator 

    PlaylistForma = sorted(Playlist, key=getKeyTvg)
    PlaylistForma = sorted(PlaylistForma, key=getKey)
    
    Cleanplaylist = ''
    global_header = '#EXTM3U\n'
    Cleanplaylist += global_header

    DupLess = []
    DupLessPath = []
    for IPTVT in PlaylistForma:
        #print (IPTVT.title, IPTVT.tvg, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path)

        if IPTVT.path not in DupLessPath:
            DupLessPath.append(IPTVT.path)

            channel_header = '#EXTINF:-1 tvg-id="%s" tvg-name="%s" tvg-logo="%s" radio="%s"  group-title="%s",%s\n' \
                            % (IPTVT.title, IPTVT.tvg , IPTVT.tvIcon, IPTVT.radio, IPTVT.group.upper(), IPTVT.xbmc)
            Cleanplaylist += channel_header
            Cleanplaylist += IPTVT.path + '\n'+'\n'
        ##else:
        ###print "already  in list IPTVT.path", IPTVT.path
            
    with open(Output, 'w+') as f:
        f.write(Cleanplaylist)
        f.close()
        
    return

# for now, just pull the IPTV info and print it onscreen
# get the M3U file path from the first command line argument
def main(workspace):
    
    print (" *****start M3U Playlist creating at: ")#, datetime.datetime.now().time()
    ##logger.info(" ***** Hallo, start creating PlayPlist.m3u *****")

    Connected = True
    #workspace=sys.argv[1]
    PlaylistWithData = ''
    PlaylistWithDataKO = ''
    playlist=[]

         

    ##### Setup workspace
    #MyApi.SetupWorkSpace()


   
    # if Connected == True:
    #     ## get radio station from radio MA plugin
    #     # def radioMA_Playlist(radioMA_xml_Remote,radiosXml, LogoDir, ouputfile, TestConnection)
    #     radioma.radioMA_Playlist(radioMA_xml_Remote,radioMA_xml_local, LogoDir, radioMaM3U, Connected)

    print "start iptv action"    
    # Download Icons 
    #GetIcon(ChannelDataBase,LogoDir)

    #### generate playlist from Web or local links       
    # get playlist fined in list.txt
    playlist += getList(StreamList)

    # list_name = "mystream"
    # M3UPlaylist=os.path.join(output,list_name+'.m3u')
    # playlist += GetM3U_data(M3UPlaylist)

    # print "playlist:"
    # for IPTVT in playlist:        
    #      print (IPTVT.title, IPTVT.tvg, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path)



    # create m3u with logo, epg, groupe info
    print "soufone ChannelDataBase", ChannelDataBase
    urllib.urlretrieve(ChannelDataBase , workspace +"/ChannelDataBase.tmp")
    inf = open(workspace +"ChannelDataBase.tmp",'r')
    PlaylistWithData, PlaylistWithDataKO  = ParseChannelsXmlNew(inf,playlist,Connected)


    # Mise en forme dans le fichier de sortie: trie ...
    MiseEnForme(PlaylistWithData,MyPlaylist)
    MiseEnForme(PlaylistWithDataKO,MyPlaylistKO)


    ##for IPTVT in PlaylistWithDataKO:
    ##  print (IPTVT.title, IPTVT.tvg, IPTVT.tvIcon, IPTVT.radio, IPTVT.group, IPTVT.path)

    
    #####Clean up directory
    filelist = glob.glob("*.tmp")
    for f in filelist:
        os.remove(f)
        
    print "end M3U Playlist creating at: "#, datetime.datetime.now().time()


if __name__ == '__main__':
    main()
