#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import xbmc,xbmcgui,xbmcaddon,xbmcplugin,os,shutil,requests,time

addon_id = 'service.Mypvrtools'

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath = xbmc.translatePath(selfAddon.getAddonInfo('profile')).decode('utf-8')
addonfolder = xbmc.translatePath(selfAddon.getAddonInfo('path')).decode('utf-8')
artfolder = os.path.join(addonfolder,'resources','img')
msgok = xbmcgui.Dialog().ok
mensagemprogresso = xbmcgui.DialogProgress()


import urllib2, logging, os


import sys
import xml.etree.ElementTree as ET
import os, re, shutil
import urllib, urllib2

import getpass
import datetime
import glob

from datetime import timedelta, datetime



endtime = datetime.utcnow() + timedelta(seconds = 3)

# Global Variables
TestConnection = True

workspace = os.getcwd()
workspace = os.path.dirname(os.path.abspath(__file__))
__addon__PVR   = xbmcaddon.Addon(id='service.Mypvrtools')
workspace= xbmc.translatePath( __addon__PVR.getAddonInfo('profile') ) 

#Output 
output = os.path.join(datapath,'download_folder')
logs = output + '/logs'
FTVOut = output + '/FTV/'
logos = output + '/logos/'
radioma = output + '/radioma/'
shahid = output + '/shahid/'
streamDir = output+"/stream/"

MyPlaylist = workspace + '/playlist.m3u'
MyPlaylistKO = workspace + '/playlist-KO.m3u'

global_header = '#EXTM3U\n'


#Ressources
Ressources = workspace + '/Ressources'
FTVDir = workspace + '/Modules/FTV/'
WebGrabDir = workspace + '/Modules/WebGrab/'

Shahid_channelsLink = "https://raw.githubusercontent.com/Shani-08/ShaniXBMCWork/master/plugin.video.shahidmbcnet/resources/community/Channels.xml"
ChannelDataBase = 'https://dl.dropboxusercontent.com/u/80638885/XBMC/LIVE_TV/Ressources/channels.xml'

StreamList = "https://dl.dropboxusercontent.com/u/80638885/XBMC/LIVE_TV/Ressources/list-m3u.py"


#radioma
radioMA_xml_Remote = "http://radioma.ma/radiomaxbmc/radios.xml"
radioMA_xml_local = output + '/radioma/radioma.xml'
radioMaM3U = output + '/radioma/radioma.m3u'


curentdir = os.getcwd()
radioMaM3U = curentdir + "/output/radioma.m3u"
radioMA_xml_Remote = "http://radioma.ma/radiomaxbmc/radios.xml"
radioMA_xml_local = Ressources+'/radios.xml'

class IPTV():
    def __init__(self, title,tvg,tvIcon,radio,group,xbmc, path,cname2,state,SiteINI,site_id):
        self.title = title
        self.tvg = tvg
        self.tvIcon = tvIcon
        self.radio = radio
        self.group = group
        self.xbmc = xbmc
        self.path = path
        self.cname2 = cname2
        self.state = state        
        self.SiteINI = SiteINI
        self.site_id = site_id



def copy_file(path):
	print "Copy file to addon_data... " + str(path)
	shutil.copy(path, os.path.join(datapath,'download_folder'))
	print "File has been copied..."

def download_and_extract(name):
	print "starting download... " + str(name)
	start_time = time.time()
	r = requests.get(name, stream=True)
	if r.status_code == 200:
		with open(os.path.join(datapath,'download_folder',name.split('/')[-1]), 'wb') as f:
			r.raw.decode_content = True
			shutil.copyfileobj(r.raw, f) 
		print "download finished..." + name
		print "elapsed time:" + str(time.time() - start_time)
	else:
		print "download failed (error status != 200)..." + name
