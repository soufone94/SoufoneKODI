#!/usr/bin/python
import threading
import requests
import shutil
import os
import time
import gzip
import datetime
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import sys
from lib.common_variables import *
from lib import xmltvmerger,listmerger,MyTV


if not xbmcvfs.exists(os.path.join(datapath,'download_folder')): 
	xbmcvfs.mkdir(os.path.join(datapath,'download_folder'))
	xbmcvfs.File(os.path.join(datapath,'playlist.m3u', 'w'))
	print "soufone: create download_folder", datapath

class service:
	def __init__(self):
		intro = False
		while (not xbmc.abortRequested):

			if not intro:
				print " _____ _____ _____    _____ _____ _____ __    _____"
				print "|  _  |  |  | __  |  |_   _|	 |	 |  |  |   __|"
				print "|   __|  |  |	-|    | | |  |  |  |  |  |__|__   |"
				print "|__|   \___/|__|__|    |_| |_____|_____|_____|_____|"
				print "soufone: Service started..."
				intro = True

			try:
				t1 = datetime.datetime.strptime(xbmcaddon.Addon().getSetting("last_merge_m3u"), "%Y-%m-%d %H:%M:%S.%f")
				t2 = datetime.datetime.now()
				interval = int(xbmcaddon.Addon().getSetting("check_interval_m3u"))
				update = abs(t2 - t1) > datetime.timedelta(hours=interval)

				if update is False: 
					print "soufone: MyPVRTOOLS: update time false"
					raise Exception()
				if not (xbmc.Player().isPlaying() or xbmc.getCondVisibility('Library.IsScanningVideo')):
					# listmerger.m3u_merge()
					print "soufone: before MyTV.main"
					MyTV.main()
					print "soufone: after MyTV.main"
					dialog = xbmcgui.Dialog()
					dialog.ok("MyTV", "fin traitement")
					
					xbmcaddon.Addon().setSetting("last_merge_m3u", datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))
			except:
			# except, e:
				print "soufone: MyPVRTOOLS: update time false ligne 52"
				pass
				# raise

			xbmc.sleep(200)

service()


