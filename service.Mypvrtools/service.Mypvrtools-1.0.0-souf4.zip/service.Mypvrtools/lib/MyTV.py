
import os
from GlobalEnv import *



print "test"
def CreateIfNotExiste(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)
    
#Create output directories
def CreateOutputs(workspace):

    CreateIfNotExiste(output)
    CreateIfNotExiste(FTVOut)
    CreateIfNotExiste(logos)
    CreateIfNotExiste(radioma)
    CreateIfNotExiste(shahid)
    CreateIfNotExiste(logs)
    CreateIfNotExiste(streamDir)
    

def main():
    print "soufone start MyTV processing"
    # run scripts

    CreateOutputs(workspace)

        #Download icons from channels.xml
    #Download playlist and test it
    import iptv
    iptv.main(workspace)

    # ####
    # import Modules.WebGrab.WebGrab as WebGrab
    # WebGrab.run_WebGrab(workspace)
